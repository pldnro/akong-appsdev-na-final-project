﻿namespace winStckChkr
{
    partial class stckChkrInventoryItemRemove
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSelectFromListing = new System.Windows.Forms.Label();
            this.cboxSelectListing = new System.Windows.Forms.ComboBox();
            this.lboxItemList = new System.Windows.Forms.ListBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblSelectFromListing
            // 
            this.lblSelectFromListing.AutoSize = true;
            this.lblSelectFromListing.Location = new System.Drawing.Point(27, 31);
            this.lblSelectFromListing.Name = "lblSelectFromListing";
            this.lblSelectFromListing.Size = new System.Drawing.Size(96, 13);
            this.lblSelectFromListing.TabIndex = 0;
            this.lblSelectFromListing.Text = "Select from Listing:";
            this.lblSelectFromListing.Click += new System.EventHandler(this.lblSelectFromListing_Click);
            // 
            // cboxSelectListing
            // 
            this.cboxSelectListing.FormattingEnabled = true;
            this.cboxSelectListing.Location = new System.Drawing.Point(129, 28);
            this.cboxSelectListing.Name = "cboxSelectListing";
            this.cboxSelectListing.Size = new System.Drawing.Size(216, 21);
            this.cboxSelectListing.TabIndex = 1;
            this.cboxSelectListing.SelectedIndexChanged += new System.EventHandler(this.cboxSelectListing_SelectedIndexChanged);
            // 
            // lboxItemList
            // 
            this.lboxItemList.FormattingEnabled = true;
            this.lboxItemList.Location = new System.Drawing.Point(30, 80);
            this.lboxItemList.Name = "lboxItemList";
            this.lboxItemList.Size = new System.Drawing.Size(315, 147);
            this.lboxItemList.TabIndex = 2;
            this.lboxItemList.SelectedIndexChanged += new System.EventHandler(this.lboxItemList_SelectedIndexChanged);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(292, 242);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(53, 22);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(30, 242);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(130, 22);
            this.btnRefresh.TabIndex = 4;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(12, 414);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(95, 24);
            this.btnPrevious.TabIndex = 5;
            this.btnPrevious.Text = "Previous";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 280);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(189, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "If item does not appear, refresh the list.";
            // 
            // stckChkrInventoryItemRemove
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.lboxItemList);
            this.Controls.Add(this.cboxSelectListing);
            this.Controls.Add(this.lblSelectFromListing);
            this.Name = "stckChkrInventoryItemRemove";
            this.Text = "stckChkrInventoryItemRemove";
            this.Load += new System.EventHandler(this.stckChkrInventoryItemRemove_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSelectFromListing;
        private System.Windows.Forms.ComboBox cboxSelectListing;
        private System.Windows.Forms.ListBox lboxItemList;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Label label2;
    }
}