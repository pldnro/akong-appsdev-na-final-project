﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winStckChkr
{
    public partial class stckChkrInventoryListingCreate : Form
    {
        public stckChkrInventoryListingCreate()
        {
            InitializeComponent();

            //Tab order for the controls on the form
            txtListingName.TabIndex = 0;
            txtListingID.TabIndex = 1;
            nudListingStockQuantity.TabIndex = 2;
            rbtnComingFromSupplierY.TabIndex = 3;
            rbtnComingFromSupplierN.TabIndex = 4;
            cboxSupplierList.TabIndex = 5;
            btnFinish.TabIndex = 6;
            btnCancel.TabIndex = 7;
        }

        private void stckChkrInventoryListingCreate_Load(object sender, EventArgs e)
        {

        }

        // Creating New Listing
        private void gboxCreateNewListing_Enter(object sender, EventArgs e)
        {

        }

        // Listing Name
        private void lblListingName_Click(object sender, EventArgs e)
        {

        }

        private void txtListingName_TextChanged(object sender, EventArgs e)
        {

        }

        // Listing ID
        private void lblListingID_Click(object sender, EventArgs e)
        {

        }

        private void txtListingID_TextChanged(object sender, EventArgs e)
        {

        }

        // Stock Check
        private void gboxStockCheck_Enter(object sender, EventArgs e)
        {

        }

        private void lblListingStockQuantity_Click(object sender, EventArgs e)
        {

        }

        private void nudListingStockQuantity_ValueChanged(object sender, EventArgs e)
        {

        }
       
        // Note
        private void lblHowMnay_Click(object sender, EventArgs e)
        {

        }

        // Does this come from a supplier?
        private void lblComingFromSupplierQ_Click(object sender, EventArgs e)
        {

        }

        // Yes or No --- If no, then skip to Finish and Cancel buttons + Identify the listing as "No Supplier"
        private void rbtnComingFromSupplierY_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbtnComingFromSupplierN_CheckedChanged(object sender, EventArgs e)
        {

        }

        // If Yes, which supplier?
        private void lblSelectSupplierY_Click(object sender, EventArgs e)
        {

        }

        private void cboxSupplierList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        // Buttons - Finish and Cancel
        private void btnFinish_Click(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {

        }
    }
}
