﻿namespace winStckChkr
{
    partial class stckChkrSettingsEndSession_Logout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnYesLogout = new System.Windows.Forms.Button();
            this.btnNoLogout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Are you sure you want to logout?";
            // 
            // btnYesLogout
            // 
            this.btnYesLogout.Location = new System.Drawing.Point(95, 94);
            this.btnYesLogout.Name = "btnYesLogout";
            this.btnYesLogout.Size = new System.Drawing.Size(75, 23);
            this.btnYesLogout.TabIndex = 1;
            this.btnYesLogout.Text = "Yes";
            this.btnYesLogout.UseVisualStyleBackColor = true;
            this.btnYesLogout.Click += new System.EventHandler(this.btnYesLogout_Click);
            // 
            // btnNoLogout
            // 
            this.btnNoLogout.Location = new System.Drawing.Point(176, 94);
            this.btnNoLogout.Name = "btnNoLogout";
            this.btnNoLogout.Size = new System.Drawing.Size(75, 23);
            this.btnNoLogout.TabIndex = 1;
            this.btnNoLogout.Text = "No";
            this.btnNoLogout.UseVisualStyleBackColor = true;
            this.btnNoLogout.Click += new System.EventHandler(this.btnNoLogout_Click);
            // 
            // stckChkrSettingsEndSession_Logout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(263, 129);
            this.Controls.Add(this.btnNoLogout);
            this.Controls.Add(this.btnYesLogout);
            this.Controls.Add(this.label1);
            this.Name = "stckChkrSettingsEndSession_Logout";
            this.Text = "stckChkrSettingsEndSession_Logout";
            this.Load += new System.EventHandler(this.stckChkrSettingsEndSession_Logout_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnYesLogout;
        private System.Windows.Forms.Button btnNoLogout;
    }
}