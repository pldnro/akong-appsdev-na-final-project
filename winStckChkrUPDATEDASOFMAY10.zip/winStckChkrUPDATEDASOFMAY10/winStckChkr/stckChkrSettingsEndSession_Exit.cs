﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winStckChkr
{
    public partial class stckChkrSettingsEndSession_Exit : Form
    {
        public stckChkrSettingsEndSession_Exit()
        {
            InitializeComponent();

            // tab indexes
            btnYesExit.TabIndex = 0;
            btnNoExit.TabIndex = 1;

                // Ensure the user can navigate through the controls using the Tab key.
                btnYesExit.TabStop = true; // Button should be tabbable
                btnNoExit.TabStop = true; // Button should be tabbable
        }

        private void stckChkrSettingsEndSession_Exit_Load(object sender, EventArgs e)
        {

        }

        private void btnYesExit_Click(object sender, EventArgs e)
        {

        }

        private void btnNoExit_Click(object sender, EventArgs e)
        {

        }
    }
}
