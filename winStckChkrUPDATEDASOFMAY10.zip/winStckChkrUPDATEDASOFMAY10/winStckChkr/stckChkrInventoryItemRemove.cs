﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winStckChkr
{
    public partial class stckChkrInventoryItemRemove : Form
    {
        public stckChkrInventoryItemRemove()
        {
            InitializeComponent();
            // order for the controls on the form
            cboxSelectListing.TabIndex = 0;
            lboxItemList.TabIndex = 1;
            btnRefresh.TabIndex = 2;
            btnDelete.TabIndex = 3;
            btnPrevious.TabIndex = 4;
            // Ensure the user can navigate through the controls using the Tab key.
            cboxSelectListing.TabStop = true; // ComboBox should be tabbable
            lboxItemList.TabStop = true; // ListBox should be tabbable
            btnRefresh.TabIndex = 5;
            btnDelete.TabStop = true;
            if (cboxSelectListing.Items.Count > 0)
                cboxSelectListing.SelectedIndex = 0;
            else
                cboxSelectListing.SelectedIndex = -1; // ensure no selection

        }

        // Form Load event handler
        private void stckChkrInventoryItemRemove_Load(object sender, EventArgs e)
        {
            // populate or assume caller populated
            if (cboxSelectListing.Items.Count > 0)
                cboxSelectListing.SelectedIndex = 0;
        }

        // Event handler for the "Select From Listing" label click
        private void lblSelectFromListing_Click(object sender, EventArgs e)
        {

        }

        private void cboxSelectListing_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        // Item List will show all items inside that "listing" and allow the user to select one to remove
        private void lboxItemList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        // Refresh the item list if the user has made changes to the listing
        // and wants to see those changes reflected in the item list
        private void btnRefresh_Click(object sender, EventArgs e)
        {

        }
        
        // Delete the selected item from the listing
        private void btnDelete_Click(object sender, EventArgs e)
        {

        }
        
        // Go back to the Main Menu form
        private void btnPrevious_Click(object sender, EventArgs e)
        {

        }
    }
}
