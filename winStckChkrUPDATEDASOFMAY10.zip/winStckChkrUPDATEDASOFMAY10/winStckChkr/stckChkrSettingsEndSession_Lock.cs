﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winStckChkr
{
    public partial class stckChkrSettingsEndSession_Lock : Form
    {
        public stckChkrSettingsEndSession_Lock()
        {
            InitializeComponent();
        }
    }
}
