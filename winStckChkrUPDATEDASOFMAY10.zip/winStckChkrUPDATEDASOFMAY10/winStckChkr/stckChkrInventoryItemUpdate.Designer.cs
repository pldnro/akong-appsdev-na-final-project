﻿namespace winStckChkr
{
    partial class stckChkrInventoryItemUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.lblAddStockCount = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblAddToListing = new System.Windows.Forms.Label();
            this.cboxAddToListing = new System.Windows.Forms.ComboBox();
            this.txtAddItemID = new System.Windows.Forms.TextBox();
            this.lblAddItemID = new System.Windows.Forms.Label();
            this.txtAddItemName = new System.Windows.Forms.TextBox();
            this.lblAddItemName = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 469);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(93, 27);
            this.button2.TabIndex = 19;
            this.button2.Text = "Return";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(255, 392);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 28);
            this.button1.TabIndex = 18;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(305, 131);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(41, 20);
            this.numericUpDown1.TabIndex = 17;
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // lblAddStockCount
            // 
            this.lblAddStockCount.AutoSize = true;
            this.lblAddStockCount.Location = new System.Drawing.Point(18, 133);
            this.lblAddStockCount.Name = "lblAddStockCount";
            this.lblAddStockCount.Size = new System.Drawing.Size(69, 13);
            this.lblAddStockCount.TabIndex = 16;
            this.lblAddStockCount.Text = "Stock Count:";
            this.lblAddStockCount.Click += new System.EventHandler(this.lblAddStockCount_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(21, 178);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(325, 208);
            this.dataGridView1.TabIndex = 15;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // lblAddToListing
            // 
            this.lblAddToListing.AutoSize = true;
            this.lblAddToListing.Location = new System.Drawing.Point(18, 30);
            this.lblAddToListing.Name = "lblAddToListing";
            this.lblAddToListing.Size = new System.Drawing.Size(96, 13);
            this.lblAddToListing.TabIndex = 14;
            this.lblAddToListing.Text = "Select from Listing:";
            this.lblAddToListing.Click += new System.EventHandler(this.lblAddToListing_Click);
            // 
            // cboxAddToListing
            // 
            this.cboxAddToListing.FormattingEnabled = true;
            this.cboxAddToListing.Location = new System.Drawing.Point(170, 27);
            this.cboxAddToListing.Name = "cboxAddToListing";
            this.cboxAddToListing.Size = new System.Drawing.Size(176, 21);
            this.cboxAddToListing.TabIndex = 13;
            this.cboxAddToListing.SelectedIndexChanged += new System.EventHandler(this.cboxAddToListing_SelectedIndexChanged);
            // 
            // txtAddItemID
            // 
            this.txtAddItemID.Location = new System.Drawing.Point(170, 106);
            this.txtAddItemID.Name = "txtAddItemID";
            this.txtAddItemID.Size = new System.Drawing.Size(176, 20);
            this.txtAddItemID.TabIndex = 11;
            this.txtAddItemID.TextChanged += new System.EventHandler(this.txtAddItemID_TextChanged);
            // 
            // lblAddItemID
            // 
            this.lblAddItemID.AutoSize = true;
            this.lblAddItemID.Location = new System.Drawing.Point(18, 109);
            this.lblAddItemID.Name = "lblAddItemID";
            this.lblAddItemID.Size = new System.Drawing.Size(44, 13);
            this.lblAddItemID.TabIndex = 9;
            this.lblAddItemID.Text = "Item ID:";
            this.lblAddItemID.Click += new System.EventHandler(this.lblAddItemID_Click);
            // 
            // txtAddItemName
            // 
            this.txtAddItemName.Location = new System.Drawing.Point(170, 80);
            this.txtAddItemName.Name = "txtAddItemName";
            this.txtAddItemName.Size = new System.Drawing.Size(176, 20);
            this.txtAddItemName.TabIndex = 12;
            this.txtAddItemName.TextChanged += new System.EventHandler(this.txtAddItemName_TextChanged);
            // 
            // lblAddItemName
            // 
            this.lblAddItemName.AutoSize = true;
            this.lblAddItemName.Location = new System.Drawing.Point(18, 83);
            this.lblAddItemName.Name = "lblAddItemName";
            this.lblAddItemName.Size = new System.Drawing.Size(61, 13);
            this.lblAddItemName.TabIndex = 10;
            this.lblAddItemName.Text = "Item Name:";
            this.lblAddItemName.Click += new System.EventHandler(this.lblAddItemName_Click);
            // 
            // stckChkrInventoryItemUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(367, 508);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.lblAddStockCount);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblAddToListing);
            this.Controls.Add(this.cboxAddToListing);
            this.Controls.Add(this.txtAddItemID);
            this.Controls.Add(this.lblAddItemID);
            this.Controls.Add(this.txtAddItemName);
            this.Controls.Add(this.lblAddItemName);
            this.Name = "stckChkrInventoryItemUpdate";
            this.Text = "stckChkrInventoryItemUpdate";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label lblAddStockCount;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblAddToListing;
        private System.Windows.Forms.ComboBox cboxAddToListing;
        private System.Windows.Forms.TextBox txtAddItemID;
        private System.Windows.Forms.Label lblAddItemID;
        private System.Windows.Forms.TextBox txtAddItemName;
        private System.Windows.Forms.Label lblAddItemName;
    }
}