﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winStckChkr
{
    public partial class stckChkrSettingsEndSession_LogoutAndExit : Form
    {
        public stckChkrSettingsEndSession_LogoutAndExit()
        {
            InitializeComponent();
            //tabidex
            btnLAE_Yes.TabIndex = 0;
            btnLAE_No.TabIndex = 1;

            // Ensure the user can navigate through the controls using the Tab key.
            btnLAE_Yes.TabStop = true; // Button should be tabbable
            btnLAE_No.TabStop = true; // Button should be tabbable
        }

        private void stckChkrSettingsEndSession_LogoutAndExit_Load(object sender, EventArgs e)
        {

        }

        private void btnLAE_Yes_Click(object sender, EventArgs e)
        {

        }

        private void btnLAE_No_Click(object sender, EventArgs e)
        {

        }
    }
}
