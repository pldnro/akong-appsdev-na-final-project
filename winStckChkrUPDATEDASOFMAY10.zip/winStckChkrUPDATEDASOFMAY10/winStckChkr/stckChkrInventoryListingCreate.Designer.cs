﻿namespace winStckChkr
{
    partial class stckChkrInventoryListingCreate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gboxCreateNewListing = new System.Windows.Forms.GroupBox();
            this.txtListingID = new System.Windows.Forms.TextBox();
            this.txtListingName = new System.Windows.Forms.TextBox();
            this.lblListingID = new System.Windows.Forms.Label();
            this.lblListingName = new System.Windows.Forms.Label();
            this.lblNote = new System.Windows.Forms.Label();
            this.gboxStockCheck = new System.Windows.Forms.GroupBox();
            this.cboxSupplierList = new System.Windows.Forms.ComboBox();
            this.lblSelectSupplierY = new System.Windows.Forms.Label();
            this.rbtnComingFromSupplierN = new System.Windows.Forms.RadioButton();
            this.rbtnComingFromSupplierY = new System.Windows.Forms.RadioButton();
            this.lblComingFromSupplierQ = new System.Windows.Forms.Label();
            this.lblHowMnay = new System.Windows.Forms.Label();
            this.lblListingStockQuantity = new System.Windows.Forms.Label();
            this.nudListingStockQuantity = new System.Windows.Forms.NumericUpDown();
            this.btnFinish = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.gboxCreateNewListing.SuspendLayout();
            this.gboxStockCheck.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudListingStockQuantity)).BeginInit();
            this.SuspendLayout();
            // 
            // gboxCreateNewListing
            // 
            this.gboxCreateNewListing.Controls.Add(this.txtListingID);
            this.gboxCreateNewListing.Controls.Add(this.txtListingName);
            this.gboxCreateNewListing.Controls.Add(this.lblListingID);
            this.gboxCreateNewListing.Controls.Add(this.lblListingName);
            this.gboxCreateNewListing.Controls.Add(this.lblNote);
            this.gboxCreateNewListing.Location = new System.Drawing.Point(12, 12);
            this.gboxCreateNewListing.Name = "gboxCreateNewListing";
            this.gboxCreateNewListing.Size = new System.Drawing.Size(321, 110);
            this.gboxCreateNewListing.TabIndex = 2;
            this.gboxCreateNewListing.TabStop = false;
            this.gboxCreateNewListing.Text = "Create New Listing";
            this.gboxCreateNewListing.Enter += new System.EventHandler(this.gboxCreateNewListing_Enter);
            // 
            // txtListingID
            // 
            this.txtListingID.Location = new System.Drawing.Point(122, 51);
            this.txtListingID.Name = "txtListingID";
            this.txtListingID.Size = new System.Drawing.Size(184, 20);
            this.txtListingID.TabIndex = 5;
            this.txtListingID.TextChanged += new System.EventHandler(this.txtListingID_TextChanged);
            // 
            // txtListingName
            // 
            this.txtListingName.Location = new System.Drawing.Point(122, 28);
            this.txtListingName.Name = "txtListingName";
            this.txtListingName.Size = new System.Drawing.Size(184, 20);
            this.txtListingName.TabIndex = 5;
            this.txtListingName.TextChanged += new System.EventHandler(this.txtListingName_TextChanged);
            // 
            // lblListingID
            // 
            this.lblListingID.AutoSize = true;
            this.lblListingID.Location = new System.Drawing.Point(28, 54);
            this.lblListingID.Name = "lblListingID";
            this.lblListingID.Size = new System.Drawing.Size(54, 13);
            this.lblListingID.TabIndex = 4;
            this.lblListingID.Text = "Listing ID:";
            this.lblListingID.Click += new System.EventHandler(this.lblListingID_Click);
            // 
            // lblListingName
            // 
            this.lblListingName.AutoSize = true;
            this.lblListingName.Location = new System.Drawing.Point(28, 31);
            this.lblListingName.Name = "lblListingName";
            this.lblListingName.Size = new System.Drawing.Size(71, 13);
            this.lblListingName.TabIndex = 3;
            this.lblListingName.Text = "Listing Name:";
            this.lblListingName.Click += new System.EventHandler(this.lblListingName_Click);
            // 
            // lblNote
            // 
            this.lblNote.Location = new System.Drawing.Point(17, 81);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(298, 17);
            this.lblNote.TabIndex = 2;
            this.lblNote.Text = "Note: The Listing ID will be your basis in looking for the listing.";
            // 
            // gboxStockCheck
            // 
            this.gboxStockCheck.Controls.Add(this.cboxSupplierList);
            this.gboxStockCheck.Controls.Add(this.lblSelectSupplierY);
            this.gboxStockCheck.Controls.Add(this.rbtnComingFromSupplierN);
            this.gboxStockCheck.Controls.Add(this.rbtnComingFromSupplierY);
            this.gboxStockCheck.Controls.Add(this.lblComingFromSupplierQ);
            this.gboxStockCheck.Controls.Add(this.lblHowMnay);
            this.gboxStockCheck.Controls.Add(this.lblListingStockQuantity);
            this.gboxStockCheck.Controls.Add(this.nudListingStockQuantity);
            this.gboxStockCheck.Location = new System.Drawing.Point(12, 128);
            this.gboxStockCheck.Name = "gboxStockCheck";
            this.gboxStockCheck.Size = new System.Drawing.Size(321, 164);
            this.gboxStockCheck.TabIndex = 3;
            this.gboxStockCheck.TabStop = false;
            this.gboxStockCheck.Text = "Stock Check";
            this.gboxStockCheck.Enter += new System.EventHandler(this.gboxStockCheck_Enter);
            // 
            // cboxSupplierList
            // 
            this.cboxSupplierList.FormattingEnabled = true;
            this.cboxSupplierList.Location = new System.Drawing.Point(199, 116);
            this.cboxSupplierList.Name = "cboxSupplierList";
            this.cboxSupplierList.Size = new System.Drawing.Size(107, 21);
            this.cboxSupplierList.TabIndex = 6;
            this.cboxSupplierList.SelectedIndexChanged += new System.EventHandler(this.cboxSupplierList_SelectedIndexChanged);
            // 
            // lblSelectSupplierY
            // 
            this.lblSelectSupplierY.AutoSize = true;
            this.lblSelectSupplierY.Location = new System.Drawing.Point(6, 119);
            this.lblSelectSupplierY.Name = "lblSelectSupplierY";
            this.lblSelectSupplierY.Size = new System.Drawing.Size(126, 13);
            this.lblSelectSupplierY.TabIndex = 5;
            this.lblSelectSupplierY.Text = "If yes, select the supplier:";
            this.lblSelectSupplierY.Click += new System.EventHandler(this.lblSelectSupplierY_Click);
            // 
            // rbtnComingFromSupplierN
            // 
            this.rbtnComingFromSupplierN.AutoSize = true;
            this.rbtnComingFromSupplierN.Location = new System.Drawing.Point(248, 89);
            this.rbtnComingFromSupplierN.Name = "rbtnComingFromSupplierN";
            this.rbtnComingFromSupplierN.Size = new System.Drawing.Size(39, 17);
            this.rbtnComingFromSupplierN.TabIndex = 4;
            this.rbtnComingFromSupplierN.TabStop = true;
            this.rbtnComingFromSupplierN.Text = "No";
            this.rbtnComingFromSupplierN.UseVisualStyleBackColor = true;
            this.rbtnComingFromSupplierN.CheckedChanged += new System.EventHandler(this.rbtnComingFromSupplierN_CheckedChanged);
            // 
            // rbtnComingFromSupplierY
            // 
            this.rbtnComingFromSupplierY.AutoSize = true;
            this.rbtnComingFromSupplierY.Location = new System.Drawing.Point(199, 89);
            this.rbtnComingFromSupplierY.Name = "rbtnComingFromSupplierY";
            this.rbtnComingFromSupplierY.Size = new System.Drawing.Size(43, 17);
            this.rbtnComingFromSupplierY.TabIndex = 4;
            this.rbtnComingFromSupplierY.TabStop = true;
            this.rbtnComingFromSupplierY.Text = "Yes";
            this.rbtnComingFromSupplierY.UseVisualStyleBackColor = true;
            this.rbtnComingFromSupplierY.CheckedChanged += new System.EventHandler(this.rbtnComingFromSupplierY_CheckedChanged);
            // 
            // lblComingFromSupplierQ
            // 
            this.lblComingFromSupplierQ.AutoSize = true;
            this.lblComingFromSupplierQ.Location = new System.Drawing.Point(6, 91);
            this.lblComingFromSupplierQ.Name = "lblComingFromSupplierQ";
            this.lblComingFromSupplierQ.Size = new System.Drawing.Size(179, 13);
            this.lblComingFromSupplierQ.TabIndex = 3;
            this.lblComingFromSupplierQ.Text = "Does this item come from a supplier?";
            this.lblComingFromSupplierQ.Click += new System.EventHandler(this.lblComingFromSupplierQ_Click);
            // 
            // lblHowMnay
            // 
            this.lblHowMnay.AutoSize = true;
            this.lblHowMnay.Location = new System.Drawing.Point(28, 54);
            this.lblHowMnay.Name = "lblHowMnay";
            this.lblHowMnay.Size = new System.Drawing.Size(195, 13);
            this.lblHowMnay.TabIndex = 2;
            this.lblHowMnay.Text = "*How many stocks does this item have?";
            this.lblHowMnay.Click += new System.EventHandler(this.lblHowMnay_Click);
            // 
            // lblListingStockQuantity
            // 
            this.lblListingStockQuantity.AutoSize = true;
            this.lblListingStockQuantity.Location = new System.Drawing.Point(28, 32);
            this.lblListingStockQuantity.Name = "lblListingStockQuantity";
            this.lblListingStockQuantity.Size = new System.Drawing.Size(79, 13);
            this.lblListingStockQuantity.TabIndex = 1;
            this.lblListingStockQuantity.Text = "Listing in Stock";
            this.lblListingStockQuantity.Click += new System.EventHandler(this.lblListingStockQuantity_Click);
            // 
            // nudListingStockQuantity
            // 
            this.nudListingStockQuantity.Location = new System.Drawing.Point(261, 30);
            this.nudListingStockQuantity.Name = "nudListingStockQuantity";
            this.nudListingStockQuantity.Size = new System.Drawing.Size(45, 20);
            this.nudListingStockQuantity.TabIndex = 0;
            this.nudListingStockQuantity.ValueChanged += new System.EventHandler(this.nudListingStockQuantity_ValueChanged);
            // 
            // btnFinish
            // 
            this.btnFinish.Location = new System.Drawing.Point(165, 324);
            this.btnFinish.Name = "btnFinish";
            this.btnFinish.Size = new System.Drawing.Size(81, 23);
            this.btnFinish.TabIndex = 4;
            this.btnFinish.Text = "Finish";
            this.btnFinish.UseVisualStyleBackColor = true;
            this.btnFinish.Click += new System.EventHandler(this.btnFinish_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(252, 324);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(81, 23);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // stckChkrInventoryListingCreate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(345, 357);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnFinish);
            this.Controls.Add(this.gboxStockCheck);
            this.Controls.Add(this.gboxCreateNewListing);
            this.Name = "stckChkrInventoryListingCreate";
            this.Text = "stckChkrInventoryListingCreate";
            this.Load += new System.EventHandler(this.stckChkrInventoryListingCreate_Load);
            this.gboxCreateNewListing.ResumeLayout(false);
            this.gboxCreateNewListing.PerformLayout();
            this.gboxStockCheck.ResumeLayout(false);
            this.gboxStockCheck.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudListingStockQuantity)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox gboxCreateNewListing;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.GroupBox gboxStockCheck;
        private System.Windows.Forms.NumericUpDown nudListingStockQuantity;
        private System.Windows.Forms.ComboBox cboxSupplierList;
        private System.Windows.Forms.Label lblSelectSupplierY;
        private System.Windows.Forms.RadioButton rbtnComingFromSupplierN;
        private System.Windows.Forms.RadioButton rbtnComingFromSupplierY;
        private System.Windows.Forms.Label lblComingFromSupplierQ;
        private System.Windows.Forms.Label lblHowMnay;
        private System.Windows.Forms.Label lblListingStockQuantity;
        private System.Windows.Forms.Button btnFinish;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblListingID;
        private System.Windows.Forms.Label lblListingName;
        private System.Windows.Forms.TextBox txtListingID;
        private System.Windows.Forms.TextBox txtListingName;
    }
}