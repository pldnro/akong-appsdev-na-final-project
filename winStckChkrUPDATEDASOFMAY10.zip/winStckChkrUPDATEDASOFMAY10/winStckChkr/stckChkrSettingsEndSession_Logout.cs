﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winStckChkr
{
    public partial class stckChkrSettingsEndSession_Logout : Form
    {
        public stckChkrSettingsEndSession_Logout()
        {
            InitializeComponent();
            
            // tab indexes
            btnYesLogout.TabIndex = 0;
            btnNoLogout.TabIndex = 1;
    
                // Ensure the user can navigate through the controls using the Tab key.
                btnYesLogout.TabStop = true; // Button should be tabbable
                btnNoLogout.TabStop = true; // Button should be tabbable
        }

        private void stckChkrSettingsEndSession_Logout_Load(object sender, EventArgs e)
        {

        }

        private void btnYesLogout_Click(object sender, EventArgs e)
        {

        }

        private void btnNoLogout_Click(object sender, EventArgs e)
        {

        }
    }
}
