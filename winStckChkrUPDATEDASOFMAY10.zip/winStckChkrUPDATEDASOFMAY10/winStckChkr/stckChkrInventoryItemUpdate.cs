﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winStckChkr
{
    public partial class stckChkrInventoryItemUpdate : Form
    {
        // Add these declarations at the top of your class
        private ComboBox cboxSelectListing;
        private ComboBox cboxSelectItem;
        private TextBox txtUpdateItemName;
        private TextBox txtUpdateItemID;
        private NumericUpDown numericUpDownUpdateStock;
        private Button btnUpdate;
        private Button btnReturn;

        public stckChkrInventoryItemUpdate()
        {
            InitializeComponent();
            //Tab order for the controls on the form
            cboxSelectListing.TabIndex = 0;
            cboxSelectItem.TabIndex = 1;
            txtUpdateItemName.TabIndex = 2;
            txtUpdateItemID.TabIndex = 3;
            numericUpDownUpdateStock.TabIndex = 4;
            btnUpdate.TabIndex = 5;
            btnReturn.TabIndex = 6;

            // Ensure the user can navigate through the controls using the Tab key.
            cboxSelectListing.TabStop = true; // ComboBox should be tabbable
            cboxSelectItem.TabStop = true; // ComboBox should be tabbable
            txtUpdateItemName.AcceptsTab = false;
            txtUpdateItemID.AcceptsTab = false;
            numericUpDownUpdateStock.TabStop = true; // NumericUpDown should be tabbable
            btnUpdate.TabStop = true; // Button should be tabbable
            btnReturn.TabStop = true; // Button should be tabbable

        }

        // Select from Listing to Update
        private void lblAddToListing_Click(object sender, EventArgs e)
        {

        }

        private void cboxAddToListing_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        // Item Name to Update
        private void lblAddItemName_Click(object sender, EventArgs e)
        {

        }

        private void txtAddItemName_TextChanged(object sender, EventArgs e)
        {

        }

        // Item ID to update
        private void lblAddItemID_Click(object sender, EventArgs e)
        {

        }

        private void txtAddItemID_TextChanged(object sender, EventArgs e)
        {

        }

        // Stock Count to update
        private void lblAddStockCount_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        // show items from a listing selected on combobox,
        // then allow the user to select an item to update
        // in the datagridview box to update item name id and stock count
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        // Update unnamed
        private void button1_Click(object sender, EventArgs e)
        {

        }

        // Return
        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
