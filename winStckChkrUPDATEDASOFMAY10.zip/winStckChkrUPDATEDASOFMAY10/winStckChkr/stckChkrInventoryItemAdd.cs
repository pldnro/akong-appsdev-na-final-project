﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winStckChkr
{
    public partial class stckChkrInventoryItemAdd : Form
    {
        public stckChkrInventoryItemAdd()
        {
            InitializeComponent();

            //Tab order for the controls on the form
            txtAddItemName.TabIndex = 0;
            txtAddItemID.TabIndex = 1;
            numericUpDown1.TabIndex = 2;
            cboxAddToListing.TabIndex = 3;
            btnAdd.TabIndex = 4;
            dataGridView1.TabIndex = 5;
            btnReturn.TabIndex = 6;
    
                // Ensure the user can navigate through the controls using the Tab key.
                txtAddItemName.AcceptsTab = false;
                txtAddItemID.AcceptsTab = false;
                cboxAddToListing.TabStop = true; // ComboBox should be tabbable
                btnAdd.TabStop = true; // Button should be tabbable
                dataGridView1.TabStop = true; // DataGridView should be tabbable
                btnReturn.TabStop = true; // Button should be tabbable
        }

        // Form Load event handler
        private void stckChkrInventoryItemAdd_Load(object sender, EventArgs e)
        {

        }

        // Event handler for the "Add Item Name" label click
        private void lblAddItemName_Click(object sender, EventArgs e)
        {

        }

        private void txtAddItemName_TextChanged(object sender, EventArgs e)
        {

        }
        
        // Event handler for the "Add Item ID" label click
        private void lblAddItemID_Click(object sender, EventArgs e)
        {

        }

        private void txtAddItemID_TextChanged(object sender, EventArgs e)
        {

        }

        // Event handler for the "Add Stock Count" label click
        private void lblAddStockCount_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        // Event handler for the "Add To Listing" label click
        private void lblAddToListing_Click(object sender, EventArgs e)
        {

        }

        // Listing must be found in the database and will be the listing
        // that the user wants to add the item to
        private void cboxAddToListing_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        // Placeholder for btnAdd
        private void btnAdd_Click(object sender, EventArgs e)
        {

        }

        // The database will be loaded to the dataGridView and only DISPLAY the item added.
        // If user wants to make changes to the item added, they will need to navigate to the
        // "Update Item" or "Remove Item" forms to make those changes.
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        // Go back to Main Menu
        private void btnReturn_Click(object sender, EventArgs e)
        {

        }
    }
}
