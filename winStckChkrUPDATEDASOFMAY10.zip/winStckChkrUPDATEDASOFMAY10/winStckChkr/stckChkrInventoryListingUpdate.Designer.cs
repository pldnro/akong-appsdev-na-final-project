﻿namespace winStckChkr
{
    partial class stckChkrInventoryListingUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cboxUpdateSelectListing = new System.Windows.Forms.ComboBox();
            this.lblUpdateSelectListing = new System.Windows.Forms.Label();
            this.lblListingIdentificationUpdated = new System.Windows.Forms.TextBox();
            this.lblListingIDUpdated = new System.Windows.Forms.Label();
            this.txtListingNameUpdated = new System.Windows.Forms.TextBox();
            this.lblListingNameUpdated = new System.Windows.Forms.Label();
            this.gboxStockCheckUpdated = new System.Windows.Forms.GroupBox();
            this.cboxSupplierListUpdated = new System.Windows.Forms.ComboBox();
            this.lblSelectSupplierYUpdated = new System.Windows.Forms.Label();
            this.rbtnComingFromSupplierNUpdated = new System.Windows.Forms.RadioButton();
            this.rbtnComingFromSupplierYUpdated = new System.Windows.Forms.RadioButton();
            this.lblComingFromSupplierQUpdated = new System.Windows.Forms.Label();
            this.lblHowMnay = new System.Windows.Forms.Label();
            this.lblListingStockQuantityUpdated = new System.Windows.Forms.Label();
            this.nudListingStockQuantityUpdated = new System.Windows.Forms.NumericUpDown();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.gboxStockCheckUpdated.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudListingStockQuantityUpdated)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(358, 44);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(430, 348);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // cboxUpdateSelectListing
            // 
            this.cboxUpdateSelectListing.FormattingEnabled = true;
            this.cboxUpdateSelectListing.Location = new System.Drawing.Point(100, 44);
            this.cboxUpdateSelectListing.Name = "cboxUpdateSelectListing";
            this.cboxUpdateSelectListing.Size = new System.Drawing.Size(240, 21);
            this.cboxUpdateSelectListing.TabIndex = 1;
            this.cboxUpdateSelectListing.SelectedIndexChanged += new System.EventHandler(this.cboxUpdateSelectListing_SelectedIndexChanged);
            // 
            // lblUpdateSelectListing
            // 
            this.lblUpdateSelectListing.AutoSize = true;
            this.lblUpdateSelectListing.Location = new System.Drawing.Point(21, 47);
            this.lblUpdateSelectListing.Name = "lblUpdateSelectListing";
            this.lblUpdateSelectListing.Size = new System.Drawing.Size(73, 13);
            this.lblUpdateSelectListing.TabIndex = 2;
            this.lblUpdateSelectListing.Text = "Select Listing:";
            this.lblUpdateSelectListing.Click += new System.EventHandler(this.lblUpdateSelectListing_Click);
            // 
            // lblListingIdentificationUpdated
            // 
            this.lblListingIdentificationUpdated.Location = new System.Drawing.Point(84, 124);
            this.lblListingIdentificationUpdated.Name = "lblListingIdentificationUpdated";
            this.lblListingIdentificationUpdated.Size = new System.Drawing.Size(190, 20);
            this.lblListingIdentificationUpdated.TabIndex = 6;
            this.lblListingIdentificationUpdated.TextChanged += new System.EventHandler(this.lblListingIdentificationUpdated_TextChanged);
            // 
            // lblListingIDUpdated
            // 
            this.lblListingIDUpdated.AutoSize = true;
            this.lblListingIDUpdated.Location = new System.Drawing.Point(16, 127);
            this.lblListingIDUpdated.Name = "lblListingIDUpdated";
            this.lblListingIDUpdated.Size = new System.Drawing.Size(51, 13);
            this.lblListingIDUpdated.TabIndex = 4;
            this.lblListingIDUpdated.Text = "Listing ID";
            this.lblListingIDUpdated.Click += new System.EventHandler(this.lblListingIDUpdated_Click);
            // 
            // txtListingNameUpdated
            // 
            this.txtListingNameUpdated.Location = new System.Drawing.Point(84, 98);
            this.txtListingNameUpdated.Name = "txtListingNameUpdated";
            this.txtListingNameUpdated.Size = new System.Drawing.Size(190, 20);
            this.txtListingNameUpdated.TabIndex = 7;
            this.txtListingNameUpdated.TextChanged += new System.EventHandler(this.txtListingNameUpdated_TextChanged);
            // 
            // lblListingNameUpdated
            // 
            this.lblListingNameUpdated.AutoSize = true;
            this.lblListingNameUpdated.Location = new System.Drawing.Point(16, 101);
            this.lblListingNameUpdated.Name = "lblListingNameUpdated";
            this.lblListingNameUpdated.Size = new System.Drawing.Size(35, 13);
            this.lblListingNameUpdated.TabIndex = 5;
            this.lblListingNameUpdated.Text = "Name";
            this.lblListingNameUpdated.Click += new System.EventHandler(this.lblListingNameUpdated_Click);
            // 
            // gboxStockCheckUpdated
            // 
            this.gboxStockCheckUpdated.Controls.Add(this.cboxSupplierListUpdated);
            this.gboxStockCheckUpdated.Controls.Add(this.lblSelectSupplierYUpdated);
            this.gboxStockCheckUpdated.Controls.Add(this.rbtnComingFromSupplierNUpdated);
            this.gboxStockCheckUpdated.Controls.Add(this.rbtnComingFromSupplierYUpdated);
            this.gboxStockCheckUpdated.Controls.Add(this.lblComingFromSupplierQUpdated);
            this.gboxStockCheckUpdated.Controls.Add(this.lblHowMnay);
            this.gboxStockCheckUpdated.Controls.Add(this.lblListingStockQuantityUpdated);
            this.gboxStockCheckUpdated.Controls.Add(this.nudListingStockQuantityUpdated);
            this.gboxStockCheckUpdated.Location = new System.Drawing.Point(12, 154);
            this.gboxStockCheckUpdated.Name = "gboxStockCheckUpdated";
            this.gboxStockCheckUpdated.Size = new System.Drawing.Size(321, 164);
            this.gboxStockCheckUpdated.TabIndex = 8;
            this.gboxStockCheckUpdated.TabStop = false;
            this.gboxStockCheckUpdated.Text = "Stock Check";
            this.gboxStockCheckUpdated.Enter += new System.EventHandler(this.gboxStockCheckUpdated_Enter);
            // 
            // cboxSupplierListUpdated
            // 
            this.cboxSupplierListUpdated.FormattingEnabled = true;
            this.cboxSupplierListUpdated.Location = new System.Drawing.Point(199, 116);
            this.cboxSupplierListUpdated.Name = "cboxSupplierListUpdated";
            this.cboxSupplierListUpdated.Size = new System.Drawing.Size(107, 21);
            this.cboxSupplierListUpdated.TabIndex = 6;
            this.cboxSupplierListUpdated.SelectedIndexChanged += new System.EventHandler(this.cboxSupplierListUpdated_SelectedIndexChanged);
            // 
            // lblSelectSupplierYUpdated
            // 
            this.lblSelectSupplierYUpdated.AutoSize = true;
            this.lblSelectSupplierYUpdated.Location = new System.Drawing.Point(6, 119);
            this.lblSelectSupplierYUpdated.Name = "lblSelectSupplierYUpdated";
            this.lblSelectSupplierYUpdated.Size = new System.Drawing.Size(126, 13);
            this.lblSelectSupplierYUpdated.TabIndex = 5;
            this.lblSelectSupplierYUpdated.Text = "If yes, select the supplier:";
            this.lblSelectSupplierYUpdated.Click += new System.EventHandler(this.lblSelectSupplierYUpdated_Click);
            // 
            // rbtnComingFromSupplierNUpdated
            // 
            this.rbtnComingFromSupplierNUpdated.AutoSize = true;
            this.rbtnComingFromSupplierNUpdated.Location = new System.Drawing.Point(248, 89);
            this.rbtnComingFromSupplierNUpdated.Name = "rbtnComingFromSupplierNUpdated";
            this.rbtnComingFromSupplierNUpdated.Size = new System.Drawing.Size(39, 17);
            this.rbtnComingFromSupplierNUpdated.TabIndex = 4;
            this.rbtnComingFromSupplierNUpdated.TabStop = true;
            this.rbtnComingFromSupplierNUpdated.Text = "No";
            this.rbtnComingFromSupplierNUpdated.UseVisualStyleBackColor = true;
            this.rbtnComingFromSupplierNUpdated.CheckedChanged += new System.EventHandler(this.rbtnComingFromSupplierNUpdated_CheckedChanged);
            // 
            // rbtnComingFromSupplierYUpdated
            // 
            this.rbtnComingFromSupplierYUpdated.AutoSize = true;
            this.rbtnComingFromSupplierYUpdated.Location = new System.Drawing.Point(199, 89);
            this.rbtnComingFromSupplierYUpdated.Name = "rbtnComingFromSupplierYUpdated";
            this.rbtnComingFromSupplierYUpdated.Size = new System.Drawing.Size(43, 17);
            this.rbtnComingFromSupplierYUpdated.TabIndex = 4;
            this.rbtnComingFromSupplierYUpdated.TabStop = true;
            this.rbtnComingFromSupplierYUpdated.Text = "Yes";
            this.rbtnComingFromSupplierYUpdated.UseVisualStyleBackColor = true;
            this.rbtnComingFromSupplierYUpdated.CheckedChanged += new System.EventHandler(this.rbtnComingFromSupplierYUpdated_CheckedChanged);
            // 
            // lblComingFromSupplierQUpdated
            // 
            this.lblComingFromSupplierQUpdated.AutoSize = true;
            this.lblComingFromSupplierQUpdated.Location = new System.Drawing.Point(6, 91);
            this.lblComingFromSupplierQUpdated.Name = "lblComingFromSupplierQUpdated";
            this.lblComingFromSupplierQUpdated.Size = new System.Drawing.Size(179, 13);
            this.lblComingFromSupplierQUpdated.TabIndex = 3;
            this.lblComingFromSupplierQUpdated.Text = "Does this item come from a supplier?";
            this.lblComingFromSupplierQUpdated.Click += new System.EventHandler(this.lblComingFromSupplierQUpdated_Click);
            // 
            // lblHowMnay
            // 
            this.lblHowMnay.AutoSize = true;
            this.lblHowMnay.Location = new System.Drawing.Point(28, 54);
            this.lblHowMnay.Name = "lblHowMnay";
            this.lblHowMnay.Size = new System.Drawing.Size(195, 13);
            this.lblHowMnay.TabIndex = 2;
            this.lblHowMnay.Text = "*How many stocks does this item have?";
            this.lblHowMnay.Click += new System.EventHandler(this.lblHowMnay_Click);
            // 
            // lblListingStockQuantityUpdated
            // 
            this.lblListingStockQuantityUpdated.AutoSize = true;
            this.lblListingStockQuantityUpdated.Location = new System.Drawing.Point(28, 32);
            this.lblListingStockQuantityUpdated.Name = "lblListingStockQuantityUpdated";
            this.lblListingStockQuantityUpdated.Size = new System.Drawing.Size(79, 13);
            this.lblListingStockQuantityUpdated.TabIndex = 1;
            this.lblListingStockQuantityUpdated.Text = "Listing in Stock";
            this.lblListingStockQuantityUpdated.Click += new System.EventHandler(this.lblListingStockQuantityUpdated_Click);
            // 
            // nudListingStockQuantityUpdated
            // 
            this.nudListingStockQuantityUpdated.Location = new System.Drawing.Point(261, 30);
            this.nudListingStockQuantityUpdated.Name = "nudListingStockQuantityUpdated";
            this.nudListingStockQuantityUpdated.Size = new System.Drawing.Size(45, 20);
            this.nudListingStockQuantityUpdated.TabIndex = 0;
            this.nudListingStockQuantityUpdated.ValueChanged += new System.EventHandler(this.nudListingStockQuantityUpdated_ValueChanged);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(240, 324);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(93, 24);
            this.btnUpdate.TabIndex = 9;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(12, 415);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(138, 23);
            this.btnReturn.TabIndex = 10;
            this.btnReturn.Text = "Return to Main Menu";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // stckChkrInventoryListingUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.lblListingIdentificationUpdated);
            this.Controls.Add(this.lblListingIDUpdated);
            this.Controls.Add(this.txtListingNameUpdated);
            this.Controls.Add(this.lblListingNameUpdated);
            this.Controls.Add(this.gboxStockCheckUpdated);
            this.Controls.Add(this.lblUpdateSelectListing);
            this.Controls.Add(this.cboxUpdateSelectListing);
            this.Controls.Add(this.dataGridView1);
            this.Name = "stckChkrInventoryListingUpdate";
            this.Text = "stckChkrInventoryListingUpdate";
            this.Load += new System.EventHandler(this.stckChkrInventoryListingUpdate_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.gboxStockCheckUpdated.ResumeLayout(false);
            this.gboxStockCheckUpdated.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudListingStockQuantityUpdated)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox cboxUpdateSelectListing;
        private System.Windows.Forms.Label lblUpdateSelectListing;
        private System.Windows.Forms.TextBox lblListingIdentificationUpdated;
        private System.Windows.Forms.Label lblListingIDUpdated;
        private System.Windows.Forms.TextBox txtListingNameUpdated;
        private System.Windows.Forms.Label lblListingNameUpdated;
        private System.Windows.Forms.GroupBox gboxStockCheckUpdated;
        private System.Windows.Forms.ComboBox cboxSupplierListUpdated;
        private System.Windows.Forms.Label lblSelectSupplierYUpdated;
        private System.Windows.Forms.RadioButton rbtnComingFromSupplierNUpdated;
        private System.Windows.Forms.RadioButton rbtnComingFromSupplierYUpdated;
        private System.Windows.Forms.Label lblComingFromSupplierQUpdated;
        private System.Windows.Forms.Label lblHowMnay;
        private System.Windows.Forms.Label lblListingStockQuantityUpdated;
        private System.Windows.Forms.NumericUpDown nudListingStockQuantityUpdated;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnReturn;
    }
}