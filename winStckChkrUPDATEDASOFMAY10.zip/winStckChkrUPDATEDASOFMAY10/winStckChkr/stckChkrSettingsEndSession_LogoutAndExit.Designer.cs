﻿namespace winStckChkr
{
    partial class stckChkrSettingsEndSession_LogoutAndExit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnLAE_No = new System.Windows.Forms.Button();
            this.btnLAE_Yes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(333, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "This will log you out of the application and end the session. Proceed?";
            // 
            // btnLAE_No
            // 
            this.btnLAE_No.Location = new System.Drawing.Point(245, 84);
            this.btnLAE_No.Name = "btnLAE_No";
            this.btnLAE_No.Size = new System.Drawing.Size(97, 21);
            this.btnLAE_No.TabIndex = 1;
            this.btnLAE_No.Text = "No";
            this.btnLAE_No.UseVisualStyleBackColor = true;
            this.btnLAE_No.Click += new System.EventHandler(this.btnLAE_No_Click);
            // 
            // btnLAE_Yes
            // 
            this.btnLAE_Yes.Location = new System.Drawing.Point(142, 84);
            this.btnLAE_Yes.Name = "btnLAE_Yes";
            this.btnLAE_Yes.Size = new System.Drawing.Size(97, 21);
            this.btnLAE_Yes.TabIndex = 1;
            this.btnLAE_Yes.Text = "Yes";
            this.btnLAE_Yes.UseVisualStyleBackColor = true;
            this.btnLAE_Yes.Click += new System.EventHandler(this.btnLAE_Yes_Click);
            // 
            // stckChkrSettingsEndSession_LogoutAndExit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(354, 117);
            this.Controls.Add(this.btnLAE_Yes);
            this.Controls.Add(this.btnLAE_No);
            this.Controls.Add(this.label1);
            this.Name = "stckChkrSettingsEndSession_LogoutAndExit";
            this.Text = "Logout and Exit";
            this.Load += new System.EventHandler(this.stckChkrSettingsEndSession_LogoutAndExit_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLAE_No;
        private System.Windows.Forms.Button btnLAE_Yes;
    }
}