﻿namespace winStckChkr
{
    partial class stckChkrSettingsEndSession_Exit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnNoExit = new System.Windows.Forms.Button();
            this.btnYesExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(63, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Are you sure you want to exit?";
            // 
            // btnNoExit
            // 
            this.btnNoExit.Location = new System.Drawing.Point(200, 116);
            this.btnNoExit.Name = "btnNoExit";
            this.btnNoExit.Size = new System.Drawing.Size(75, 23);
            this.btnNoExit.TabIndex = 1;
            this.btnNoExit.Text = "No";
            this.btnNoExit.UseVisualStyleBackColor = true;
            this.btnNoExit.Click += new System.EventHandler(this.btnNoExit_Click);
            // 
            // btnYesExit
            // 
            this.btnYesExit.Location = new System.Drawing.Point(119, 116);
            this.btnYesExit.Name = "btnYesExit";
            this.btnYesExit.Size = new System.Drawing.Size(75, 23);
            this.btnYesExit.TabIndex = 1;
            this.btnYesExit.Text = "Yes";
            this.btnYesExit.UseVisualStyleBackColor = true;
            this.btnYesExit.Click += new System.EventHandler(this.btnYesExit_Click);
            // 
            // stckChkrSettingsEndSession_Exit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(287, 151);
            this.Controls.Add(this.btnYesExit);
            this.Controls.Add(this.btnNoExit);
            this.Controls.Add(this.label1);
            this.Name = "stckChkrSettingsEndSession_Exit";
            this.Text = "stckChkrSettingsEndSession_Exit";
            this.Load += new System.EventHandler(this.stckChkrSettingsEndSession_Exit_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnNoExit;
        private System.Windows.Forms.Button btnYesExit;
    }
}