﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winStckChkr
{
    public partial class winStckChkrMainMenu : Form
    {
        public winStckChkrMainMenu()
        {
            InitializeComponent();
        }

        // Small helper to open a form modally and return to this main menu afterwards.
        private void OpenModal(Func<Form> createForm)
        {
            // Hide this main menu while the child form is active, and ensure the main menu
            // is restored even if the child throws an exception or is closed unexpectedly.
            this.Hide();
            try
            {
                using (var form = createForm())
                {
                    form.StartPosition = FormStartPosition.CenterScreen;
                    // Show dialog with this as owner so focus and modality behave correctly.
                    form.ShowDialog(this);
                }
            }
            finally
            {
                // Restore the main menu visibility and activate it.
                // If the application is exiting, Show() will be ignored.
                this.Show();
                this.Activate();
            }
        }

        // Event handlers for menu items and buttons
        private void winStckChkrMainMenu_Load(object sender, EventArgs e)
        {
        }

        // Inventory menu item click event handler
        private void tsddBtnInventory_Click(object sender, EventArgs e)
        {
        }

        private void createListingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrInventoryListingCreate());
        }

        private void removeListingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrInventoryListingRemove());
        }

        private void updateListingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrInventoryListingUpdate());
        }

        private void addItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrInventoryItemAdd());
        }

        private void removeItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrInventoryItemRemove());
        }

        private void updateItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrInventoryItemUpdate());
        }

        private void checkForUpdatesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrInventoryUpdates());
        }

        // Suppliers menu item click event handler
        private void tsddBtnSuppliers_Click(object sender, EventArgs e)
        {
        }

        private void addSupplierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrSuppliersAdd());
        }

        private void removeSupplierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrSuppliersRemove());
        }

        private void updateSupplierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrSuppliersUpdate());
        }

        // Transactions menu item click event handler
        private void tsddBtnTransactions_Click(object sender, EventArgs e)
        {
        }

        private void balanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrTransactionsBalance());
        }

        private void auditingReportingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrTransactionsAuditReport());
        }

        // Settings menu item click event handler
        private void tsddBtnSettings_Click(object sender, EventArgs e)
        {
        }

        private void userAccountSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrSettingsUAS());
        }

        private void aboutOurAppToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrSettingsAboutApp());
        }

        private void aboutOurEULAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrSettingsAboutEULA());
        }

        // End Session menu item click event handler
        private void lockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrSettingsEndSession_Lock());
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrSettingsEndSession_Logout());
        }

        private void logoutAndExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrSettingsEndSession_LogoutAndExit());
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenModal(() => new stckChkrSettingsEndSession_Exit());
        }

        // Check from Suppliers
        private void lblCheckFromSupplier_Click(object sender, EventArgs e)
        {
        }

        private void cBoxSupplier_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void btnRefreshList_Click(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
    }
}
