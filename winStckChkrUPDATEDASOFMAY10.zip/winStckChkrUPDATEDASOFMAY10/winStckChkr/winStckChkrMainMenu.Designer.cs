﻿namespace winStckChkr
{
    partial class winStckChkrMainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(winStckChkrMainMenu));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsddBtnInventory = new System.Windows.Forms.ToolStripDropDownButton();
            this.createListingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeListingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateListingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checkForUpdatesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsddBtnSuppliers = new System.Windows.Forms.ToolStripDropDownButton();
            this.addSupplierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeSupplierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateSupplierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsddBtnTransactions = new System.Windows.Forms.ToolStripDropDownButton();
            this.balanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.auditingReportingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsddBtnSettings = new System.Windows.Forms.ToolStripDropDownButton();
            this.userAccountSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutOurAppToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutOurEULAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.endSessionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lockToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutAndExitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.btnRefreshList = new System.Windows.Forms.Button();
            this.cBoxSupplier = new System.Windows.Forms.ComboBox();
            this.lblCheckFromSupplier = new System.Windows.Forms.Label();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsddBtnInventory,
            this.toolStripSeparator1,
            this.tsddBtnSuppliers,
            this.toolStripSeparator2,
            this.tsddBtnTransactions,
            this.toolStripSeparator3,
            this.tsddBtnSettings,
            this.toolStripSeparator4,
            this.toolStripLabel1,
            this.toolStripTextBox1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(800, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsddBtnInventory
            // 
            this.tsddBtnInventory.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsddBtnInventory.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createListingToolStripMenuItem,
            this.removeListingToolStripMenuItem,
            this.updateListingToolStripMenuItem,
            this.addItemToolStripMenuItem,
            this.removeItemToolStripMenuItem,
            this.updateItemToolStripMenuItem,
            this.checkForUpdatesToolStripMenuItem});
            this.tsddBtnInventory.Image = ((System.Drawing.Image)(resources.GetObject("tsddBtnInventory.Image")));
            this.tsddBtnInventory.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsddBtnInventory.Name = "tsddBtnInventory";
            this.tsddBtnInventory.Size = new System.Drawing.Size(70, 22);
            this.tsddBtnInventory.Text = "Inventory";
            this.tsddBtnInventory.Click += new System.EventHandler(this.tsddBtnInventory_Click);
            // 
            // createListingToolStripMenuItem
            // 
            this.createListingToolStripMenuItem.Name = "createListingToolStripMenuItem";
            this.createListingToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.createListingToolStripMenuItem.Text = "Create Listing";
            this.createListingToolStripMenuItem.Click += new System.EventHandler(this.createListingToolStripMenuItem_Click);
            // 
            // removeListingToolStripMenuItem
            // 
            this.removeListingToolStripMenuItem.Name = "removeListingToolStripMenuItem";
            this.removeListingToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.removeListingToolStripMenuItem.Text = "Remove Listing";
            this.removeListingToolStripMenuItem.Click += new System.EventHandler(this.removeListingToolStripMenuItem_Click);
            // 
            // updateListingToolStripMenuItem
            // 
            this.updateListingToolStripMenuItem.Name = "updateListingToolStripMenuItem";
            this.updateListingToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.updateListingToolStripMenuItem.Text = "Update Listing";
            this.updateListingToolStripMenuItem.Click += new System.EventHandler(this.updateListingToolStripMenuItem_Click);
            // 
            // addItemToolStripMenuItem
            // 
            this.addItemToolStripMenuItem.Name = "addItemToolStripMenuItem";
            this.addItemToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.addItemToolStripMenuItem.Text = "Add Item";
            this.addItemToolStripMenuItem.Click += new System.EventHandler(this.addItemToolStripMenuItem_Click);
            // 
            // removeItemToolStripMenuItem
            // 
            this.removeItemToolStripMenuItem.Name = "removeItemToolStripMenuItem";
            this.removeItemToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.removeItemToolStripMenuItem.Text = "Remove Item";
            this.removeItemToolStripMenuItem.Click += new System.EventHandler(this.removeItemToolStripMenuItem_Click);
            // 
            // updateItemToolStripMenuItem
            // 
            this.updateItemToolStripMenuItem.Name = "updateItemToolStripMenuItem";
            this.updateItemToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.updateItemToolStripMenuItem.Text = "Update Item";
            this.updateItemToolStripMenuItem.Click += new System.EventHandler(this.updateItemToolStripMenuItem_Click);
            // 
            // checkForUpdatesToolStripMenuItem
            // 
            this.checkForUpdatesToolStripMenuItem.Name = "checkForUpdatesToolStripMenuItem";
            this.checkForUpdatesToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.checkForUpdatesToolStripMenuItem.Text = "Check for Updates";
            this.checkForUpdatesToolStripMenuItem.Click += new System.EventHandler(this.checkForUpdatesToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsddBtnSuppliers
            // 
            this.tsddBtnSuppliers.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsddBtnSuppliers.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addSupplierToolStripMenuItem,
            this.removeSupplierToolStripMenuItem,
            this.updateSupplierToolStripMenuItem});
            this.tsddBtnSuppliers.Image = ((System.Drawing.Image)(resources.GetObject("tsddBtnSuppliers.Image")));
            this.tsddBtnSuppliers.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsddBtnSuppliers.Name = "tsddBtnSuppliers";
            this.tsddBtnSuppliers.Size = new System.Drawing.Size(68, 22);
            this.tsddBtnSuppliers.Text = "Suppliers";
            this.tsddBtnSuppliers.Click += new System.EventHandler(this.tsddBtnSuppliers_Click);
            // 
            // addSupplierToolStripMenuItem
            // 
            this.addSupplierToolStripMenuItem.Name = "addSupplierToolStripMenuItem";
            this.addSupplierToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.addSupplierToolStripMenuItem.Text = "Add Supplier";
            this.addSupplierToolStripMenuItem.Click += new System.EventHandler(this.addSupplierToolStripMenuItem_Click);
            // 
            // removeSupplierToolStripMenuItem
            // 
            this.removeSupplierToolStripMenuItem.Name = "removeSupplierToolStripMenuItem";
            this.removeSupplierToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.removeSupplierToolStripMenuItem.Text = "Remove Supplier";
            this.removeSupplierToolStripMenuItem.Click += new System.EventHandler(this.removeSupplierToolStripMenuItem_Click);
            // 
            // updateSupplierToolStripMenuItem
            // 
            this.updateSupplierToolStripMenuItem.Name = "updateSupplierToolStripMenuItem";
            this.updateSupplierToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.updateSupplierToolStripMenuItem.Text = "Update Supplier";
            this.updateSupplierToolStripMenuItem.Click += new System.EventHandler(this.updateSupplierToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tsddBtnTransactions
            // 
            this.tsddBtnTransactions.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsddBtnTransactions.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.balanceToolStripMenuItem,
            this.auditingReportingToolStripMenuItem});
            this.tsddBtnTransactions.Image = ((System.Drawing.Image)(resources.GetObject("tsddBtnTransactions.Image")));
            this.tsddBtnTransactions.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsddBtnTransactions.Name = "tsddBtnTransactions";
            this.tsddBtnTransactions.Size = new System.Drawing.Size(86, 22);
            this.tsddBtnTransactions.Text = "Transactions";
            this.tsddBtnTransactions.Click += new System.EventHandler(this.tsddBtnTransactions_Click);
            // 
            // balanceToolStripMenuItem
            // 
            this.balanceToolStripMenuItem.Name = "balanceToolStripMenuItem";
            this.balanceToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.balanceToolStripMenuItem.Text = "Balance";
            this.balanceToolStripMenuItem.Click += new System.EventHandler(this.balanceToolStripMenuItem_Click);
            // 
            // auditingReportingToolStripMenuItem
            // 
            this.auditingReportingToolStripMenuItem.Name = "auditingReportingToolStripMenuItem";
            this.auditingReportingToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.auditingReportingToolStripMenuItem.Text = "Auditing/Reporting";
            this.auditingReportingToolStripMenuItem.Click += new System.EventHandler(this.auditingReportingToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // tsddBtnSettings
            // 
            this.tsddBtnSettings.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsddBtnSettings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userAccountSettingsToolStripMenuItem,
            this.aboutOurAppToolStripMenuItem,
            this.aboutOurEULAToolStripMenuItem,
            this.endSessionToolStripMenuItem});
            this.tsddBtnSettings.Image = ((System.Drawing.Image)(resources.GetObject("tsddBtnSettings.Image")));
            this.tsddBtnSettings.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsddBtnSettings.Name = "tsddBtnSettings";
            this.tsddBtnSettings.Size = new System.Drawing.Size(62, 22);
            this.tsddBtnSettings.Text = "Settings";
            this.tsddBtnSettings.Click += new System.EventHandler(this.tsddBtnSettings_Click);
            // 
            // userAccountSettingsToolStripMenuItem
            // 
            this.userAccountSettingsToolStripMenuItem.Name = "userAccountSettingsToolStripMenuItem";
            this.userAccountSettingsToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.userAccountSettingsToolStripMenuItem.Text = "User Account Settings";
            this.userAccountSettingsToolStripMenuItem.Click += new System.EventHandler(this.userAccountSettingsToolStripMenuItem_Click);
            // 
            // aboutOurAppToolStripMenuItem
            // 
            this.aboutOurAppToolStripMenuItem.Name = "aboutOurAppToolStripMenuItem";
            this.aboutOurAppToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.aboutOurAppToolStripMenuItem.Text = "About our App";
            this.aboutOurAppToolStripMenuItem.Click += new System.EventHandler(this.aboutOurAppToolStripMenuItem_Click);
            // 
            // aboutOurEULAToolStripMenuItem
            // 
            this.aboutOurEULAToolStripMenuItem.Name = "aboutOurEULAToolStripMenuItem";
            this.aboutOurEULAToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.aboutOurEULAToolStripMenuItem.Text = "About our EULA";
            this.aboutOurEULAToolStripMenuItem.Click += new System.EventHandler(this.aboutOurEULAToolStripMenuItem_Click);
            // 
            // endSessionToolStripMenuItem
            // 
            this.endSessionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lockToolStripMenuItem,
            this.logoutToolStripMenuItem,
            this.logoutAndExitToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.endSessionToolStripMenuItem.Name = "endSessionToolStripMenuItem";
            this.endSessionToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.endSessionToolStripMenuItem.Text = "End Session";
            // 
            // lockToolStripMenuItem
            // 
            this.lockToolStripMenuItem.Name = "lockToolStripMenuItem";
            this.lockToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.lockToolStripMenuItem.Text = "Lock";
            this.lockToolStripMenuItem.Click += new System.EventHandler(this.lockToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // logoutAndExitToolStripMenuItem
            // 
            this.logoutAndExitToolStripMenuItem.Name = "logoutAndExitToolStripMenuItem";
            this.logoutAndExitToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.logoutAndExitToolStripMenuItem.Text = "Logout and Exit";
            this.logoutAndExitToolStripMenuItem.Click += new System.EventHandler(this.logoutAndExitToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(97, 22);
            this.toolStripLabel1.Text = "Search Listing ID:";
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 25);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 428);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(283, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Programmed by Team Janleloy, 2026. All Rights Reserved.";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(290, 73);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(498, 295);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(12, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(257, 32);
            this.label2.TabIndex = 3;
            this.label2.Text = "Welcome to StckChkr! All your items and products are stored for when you will nee" +
    "d it the most!";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnRefreshList
            // 
            this.btnRefreshList.Location = new System.Drawing.Point(635, 44);
            this.btnRefreshList.Name = "btnRefreshList";
            this.btnRefreshList.Size = new System.Drawing.Size(75, 23);
            this.btnRefreshList.TabIndex = 4;
            this.btnRefreshList.Text = "Refresh List";
            this.btnRefreshList.UseVisualStyleBackColor = true;
            this.btnRefreshList.Click += new System.EventHandler(this.btnRefreshList_Click);
            // 
            // cBoxSupplier
            // 
            this.cBoxSupplier.FormattingEnabled = true;
            this.cBoxSupplier.Location = new System.Drawing.Point(425, 46);
            this.cBoxSupplier.Name = "cBoxSupplier";
            this.cBoxSupplier.Size = new System.Drawing.Size(185, 21);
            this.cBoxSupplier.TabIndex = 5;
            this.cBoxSupplier.SelectedIndexChanged += new System.EventHandler(this.cBoxSupplier_SelectedIndexChanged);
            // 
            // lblCheckFromSupplier
            // 
            this.lblCheckFromSupplier.AutoSize = true;
            this.lblCheckFromSupplier.Location = new System.Drawing.Point(316, 49);
            this.lblCheckFromSupplier.Name = "lblCheckFromSupplier";
            this.lblCheckFromSupplier.Size = new System.Drawing.Size(103, 13);
            this.lblCheckFromSupplier.TabIndex = 6;
            this.lblCheckFromSupplier.Text = "Check from supplier:";
            this.lblCheckFromSupplier.Click += new System.EventHandler(this.lblCheckFromSupplier_Click);
            // 
            // winStckChkrMainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblCheckFromSupplier);
            this.Controls.Add(this.cBoxSupplier);
            this.Controls.Add(this.btnRefreshList);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "winStckChkrMainMenu";
            this.Text = "Main Menu";
            this.Load += new System.EventHandler(this.winStckChkrMainMenu_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnRefreshList;
        private System.Windows.Forms.ComboBox cBoxSupplier;
        private System.Windows.Forms.Label lblCheckFromSupplier;
        private System.Windows.Forms.ToolStripDropDownButton tsddBtnInventory;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripDropDownButton tsddBtnSuppliers;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripDropDownButton tsddBtnTransactions;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripDropDownButton tsddBtnSettings;
        private System.Windows.Forms.ToolStripMenuItem createListingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeListingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateListingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem checkForUpdatesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addSupplierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeSupplierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateSupplierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem balanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem auditingReportingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userAccountSettingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutOurAppToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutOurEULAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem endSessionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lockToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutAndExitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
    }
}