﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winStckChkr
{
    public partial class stckChkrInventoryListingRemove : Form
    {
        public stckChkrInventoryListingRemove()
        {
            InitializeComponent();

            // tab index
            cboxSelectListingRemove.TabIndex = 0;
            btnRemoveListing.TabIndex = 1;
    
                // Ensure the user can navigate through the controls using the Tab key.
                cboxSelectListingRemove.TabStop = true; // ComboBox should be tabbable
                btnRemoveListing.TabStop = true; // Button should be tabbable
        }

        private void stckChkrInventoryListingRemove_Load(object sender, EventArgs e)
        {

        }

        private void lblSelectListingRemove_Click(object sender, EventArgs e)
        {

        }

        private void cboxSelectListingRemove_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
