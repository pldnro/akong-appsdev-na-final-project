﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winStckChkr
{
    public partial class stckChkrInventoryListingUpdate : Form
    {
        public stckChkrInventoryListingUpdate()
        {
            InitializeComponent();

            // tab index
            cboxUpdateSelectListing.TabIndex = 0;
                dataGridView1.TabIndex = 1;
                txtListingNameUpdated.TabIndex = 2;
                lblListingIdentificationUpdated.TabIndex = 3;
                nudListingStockQuantityUpdated.TabIndex = 4;
                rbtnComingFromSupplierYUpdated.TabIndex = 5;
                rbtnComingFromSupplierNUpdated.TabIndex = 6;
                cboxSupplierListUpdated.TabIndex = 7;
                btnUpdate.TabIndex = 8;
                btnReturn.TabIndex = 9;
    
                // Ensure the user can navigate through the controls using the Tab key.
                cboxUpdateSelectListing.TabStop = true; // ComboBox should be tabbable
                dataGridView1.TabStop = true; // DataGridView should be tabbable
                txtListingNameUpdated.AcceptsTab = false;
                lblListingIdentificationUpdated.AcceptsTab = false;
                nudListingStockQuantityUpdated.TabStop = true; // NumericUpDown should be tabbable
                rbtnComingFromSupplierYUpdated.TabStop = true; // RadioButton should be tabbable
                rbtnComingFromSupplierNUpdated.TabStop = true; // RadioButton should be tabbable
                cboxSupplierListUpdated.TabStop = true; // ComboBox should be tabbable
                btnUpdate.TabStop = true; // Button should be tabbable
                btnReturn.TabStop = true; // Button should be tabbable
        }

        // Form Load
        private void stckChkrInventoryListingUpdate_Load(object sender, EventArgs e)
        {

        }

        // Lets the user select what listing they want to update
        private void lblUpdateSelectListing_Click(object sender, EventArgs e)
        {

        }

        // Combo box must read the database of listings
        private void cboxUpdateSelectListing_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        // Display the listings from the database in the datagridview (ie: Listing Name, Listing ID, Items within the listing)
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        // Lets the user update the listing name and listing ID only
        private void lblListingNameUpdated_Click(object sender, EventArgs e)
        {

        }

        private void txtListingNameUpdated_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblListingIDUpdated_Click(object sender, EventArgs e)
        {

        }

        private void lblListingIdentificationUpdated_TextChanged(object sender, EventArgs e)
        {

        }

        // Groupbox to update the quantity if the listing has stock to update
        private void gboxStockCheckUpdated_Enter(object sender, EventArgs e)
        {

        }

        private void lblListingStockQuantityUpdated_Click(object sender, EventArgs e)
        {

        }

        private void nudListingStockQuantityUpdated_ValueChanged(object sender, EventArgs e)
        {

        }

        private void lblHowMnay_Click(object sender, EventArgs e)
        {

        }

        // User can update if the listing is coming from a supplier or not, if it is coming from a supplier
        // then they can select the supplier from the list of suppliers in the database
        private void lblComingFromSupplierQUpdated_Click(object sender, EventArgs e)
        {

        }

        private void rbtnComingFromSupplierYUpdated_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbtnComingFromSupplierNUpdated_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void lblSelectSupplierYUpdated_Click(object sender, EventArgs e)
        {

        }

        private void cboxSupplierListUpdated_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

        }

        // Go back to Main Menu form
        private void btnReturn_Click(object sender, EventArgs e)
        {

        }
    }
}
