﻿namespace winStckChkr
{
    partial class stckChkrInventoryItemAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAddItemName = new System.Windows.Forms.Label();
            this.txtAddItemName = new System.Windows.Forms.TextBox();
            this.lblAddItemID = new System.Windows.Forms.Label();
            this.txtAddItemID = new System.Windows.Forms.TextBox();
            this.cboxAddToListing = new System.Windows.Forms.ComboBox();
            this.lblAddToListing = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblAddStockCount = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnReturn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAddItemName
            // 
            this.lblAddItemName.AutoSize = true;
            this.lblAddItemName.Location = new System.Drawing.Point(27, 34);
            this.lblAddItemName.Name = "lblAddItemName";
            this.lblAddItemName.Size = new System.Drawing.Size(61, 13);
            this.lblAddItemName.TabIndex = 0;
            this.lblAddItemName.Text = "Item Name:";
            this.lblAddItemName.Click += new System.EventHandler(this.lblAddItemName_Click);
            // 
            // txtAddItemName
            // 
            this.txtAddItemName.Location = new System.Drawing.Point(179, 31);
            this.txtAddItemName.Name = "txtAddItemName";
            this.txtAddItemName.Size = new System.Drawing.Size(176, 20);
            this.txtAddItemName.TabIndex = 1;
            this.txtAddItemName.TextChanged += new System.EventHandler(this.txtAddItemName_TextChanged);
            // 
            // lblAddItemID
            // 
            this.lblAddItemID.AutoSize = true;
            this.lblAddItemID.Location = new System.Drawing.Point(27, 60);
            this.lblAddItemID.Name = "lblAddItemID";
            this.lblAddItemID.Size = new System.Drawing.Size(44, 13);
            this.lblAddItemID.TabIndex = 0;
            this.lblAddItemID.Text = "Item ID:";
            this.lblAddItemID.Click += new System.EventHandler(this.lblAddItemID_Click);
            // 
            // txtAddItemID
            // 
            this.txtAddItemID.Location = new System.Drawing.Point(179, 57);
            this.txtAddItemID.Name = "txtAddItemID";
            this.txtAddItemID.Size = new System.Drawing.Size(176, 20);
            this.txtAddItemID.TabIndex = 1;
            this.txtAddItemID.TextChanged += new System.EventHandler(this.txtAddItemID_TextChanged);
            // 
            // cboxAddToListing
            // 
            this.cboxAddToListing.FormattingEnabled = true;
            this.cboxAddToListing.Location = new System.Drawing.Point(179, 108);
            this.cboxAddToListing.Name = "cboxAddToListing";
            this.cboxAddToListing.Size = new System.Drawing.Size(176, 21);
            this.cboxAddToListing.TabIndex = 2;
            this.cboxAddToListing.SelectedIndexChanged += new System.EventHandler(this.cboxAddToListing_SelectedIndexChanged);
            // 
            // lblAddToListing
            // 
            this.lblAddToListing.AutoSize = true;
            this.lblAddToListing.Location = new System.Drawing.Point(27, 111);
            this.lblAddToListing.Name = "lblAddToListing";
            this.lblAddToListing.Size = new System.Drawing.Size(74, 13);
            this.lblAddToListing.TabIndex = 3;
            this.lblAddToListing.Text = "Add to Listing:";
            this.lblAddToListing.Click += new System.EventHandler(this.lblAddToListing_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(30, 184);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(325, 208);
            this.dataGridView1.TabIndex = 4;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // lblAddStockCount
            // 
            this.lblAddStockCount.AutoSize = true;
            this.lblAddStockCount.Location = new System.Drawing.Point(27, 84);
            this.lblAddStockCount.Name = "lblAddStockCount";
            this.lblAddStockCount.Size = new System.Drawing.Size(69, 13);
            this.lblAddStockCount.TabIndex = 5;
            this.lblAddStockCount.Text = "Stock Count:";
            this.lblAddStockCount.Click += new System.EventHandler(this.lblAddStockCount_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(314, 82);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(41, 20);
            this.numericUpDown1.TabIndex = 6;
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(280, 135);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 9;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(30, 415);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(75, 23);
            this.btnReturn.TabIndex = 10;
            this.btnReturn.Text = "Return";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // stckChkrInventoryItemAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(386, 450);
            this.Controls.Add(this.btnReturn);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.lblAddStockCount);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblAddToListing);
            this.Controls.Add(this.cboxAddToListing);
            this.Controls.Add(this.txtAddItemID);
            this.Controls.Add(this.lblAddItemID);
            this.Controls.Add(this.txtAddItemName);
            this.Controls.Add(this.lblAddItemName);
            this.Name = "stckChkrInventoryItemAdd";
            this.Text = "stckChkrInventoryItemAdd";
            this.Load += new System.EventHandler(this.stckChkrInventoryItemAdd_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAddItemName;
        private System.Windows.Forms.TextBox txtAddItemName;
        private System.Windows.Forms.Label lblAddItemID;
        private System.Windows.Forms.TextBox txtAddItemID;
        private System.Windows.Forms.ComboBox cboxAddToListing;
        private System.Windows.Forms.Label lblAddToListing;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblAddStockCount;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnReturn;
    }
}