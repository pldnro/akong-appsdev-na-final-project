﻿namespace winStckChkr
{
    partial class stckChkrInventoryListingRemove
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRemoveListing = new System.Windows.Forms.Button();
            this.lblSelectListingRemove = new System.Windows.Forms.Label();
            this.cboxSelectListingRemove = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnRemoveListing
            // 
            this.btnRemoveListing.Location = new System.Drawing.Point(204, 98);
            this.btnRemoveListing.Name = "btnRemoveListing";
            this.btnRemoveListing.Size = new System.Drawing.Size(128, 30);
            this.btnRemoveListing.TabIndex = 0;
            this.btnRemoveListing.Text = "Remove Listing";
            this.btnRemoveListing.UseVisualStyleBackColor = true;
            // 
            // lblSelectListingRemove
            // 
            this.lblSelectListingRemove.AutoSize = true;
            this.lblSelectListingRemove.Location = new System.Drawing.Point(40, 53);
            this.lblSelectListingRemove.Name = "lblSelectListingRemove";
            this.lblSelectListingRemove.Size = new System.Drawing.Size(73, 13);
            this.lblSelectListingRemove.TabIndex = 1;
            this.lblSelectListingRemove.Text = "Select Listing:";
            this.lblSelectListingRemove.Click += new System.EventHandler(this.lblSelectListingRemove_Click);
            // 
            // cboxSelectListingRemove
            // 
            this.cboxSelectListingRemove.FormattingEnabled = true;
            this.cboxSelectListingRemove.Location = new System.Drawing.Point(119, 50);
            this.cboxSelectListingRemove.Name = "cboxSelectListingRemove";
            this.cboxSelectListingRemove.Size = new System.Drawing.Size(155, 21);
            this.cboxSelectListingRemove.TabIndex = 2;
            this.cboxSelectListingRemove.SelectedIndexChanged += new System.EventHandler(this.cboxSelectListingRemove_SelectedIndexChanged);
            // 
            // stckChkrInventoryListingRemove
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 140);
            this.Controls.Add(this.cboxSelectListingRemove);
            this.Controls.Add(this.lblSelectListingRemove);
            this.Controls.Add(this.btnRemoveListing);
            this.Name = "stckChkrInventoryListingRemove";
            this.Text = "stckChkrInventoryListingRemove";
            this.Load += new System.EventHandler(this.stckChkrInventoryListingRemove_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRemoveListing;
        private System.Windows.Forms.Label lblSelectListingRemove;
        private System.Windows.Forms.ComboBox cboxSelectListingRemove;
    }
}