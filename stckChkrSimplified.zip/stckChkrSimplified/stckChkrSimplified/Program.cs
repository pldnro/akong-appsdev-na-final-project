﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stckChkrSimplified
{
    // Add a stub for StatsStore if it doesn't exist
    internal static class StatsStore
    {
        private static readonly object _lock = new object();
        private static readonly Dictionary<string,int> _stats = new Dictionary<string,int>();

        public static void IncrementStat(string statName)
        {
            if (string.IsNullOrEmpty(statName)) return;
            lock (_lock)
            {
                if (_stats.ContainsKey(statName))
                {
                    _stats[statName]++;
                }
                else
                {
                    _stats[statName] = 1;
                }
            }
        }

        public static Dictionary<string,int> GetAllStats()
        {
            lock (_lock)
            {
                return new Dictionary<string,int>(_stats);
            }
        }
    }

    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Track a clean session open
            try
            {
                StatsStore.IncrementStat("SessionsOpened");
            }
            catch
            {
                // ignore stats failures; app should still run
            }

            Application.Run(new stckChkrMenu());
        }
    }
}
