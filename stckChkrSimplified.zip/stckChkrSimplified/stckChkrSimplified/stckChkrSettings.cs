﻿using System;
using System.Windows.Forms;

namespace stckChkrSimplified
{
    public partial class stckChkrSettings : Form
    {
        private int _secretClickCount;
        private const int SecretClicksRequired = 10;

        public stckChkrSettings()
        {
            InitializeComponent();

            // Wire up buttons that the designer did not attach handlers for
            btnGoBack.Click += BtnGoBack_Click;
            btnExit.Click += BtnExit_Click;
            // pictureBoxSecretMessage click is wired in designer to pictureBoxSecretMessage_Click
        }

        private void stckChkrSettings_Load(object sender, EventArgs e)
        {
            // Hide the secret message until the user completes the task
            if (lblSecretMessage2 != null)
            {
                lblSecretMessage2.Visible = false;
            }

            _secretClickCount = 0;
        }

        // Clicking the image 10 times will reveal lblSecretMessage2_Click, which will show the hidden message.
        private void pictureBoxSecretMessage_Click(object sender, EventArgs e)
        {
            // Defensive: ensure control exists
            if (pictureBoxSecretMessage == null || lblSecretMessage2 == null) return;

            _secretClickCount++;

            // Optional: give subtle feedback when nearing the reveal (not required)
            if (_secretClickCount >= SecretClicksRequired)
            {
                lblSecretMessage2.Visible = true;
                // prevent further clicks from re-triggering
                pictureBoxSecretMessage.Enabled = false;
            }
        }

        private void lblSecretMessage2_Click(object sender, EventArgs e)
        {
            // No special behavior required; keep clickable if designer expects it.
            // For now toggle visibility as a small, non-destructive interaction.
            if (lblSecretMessage2 == null) return;
            lblSecretMessage2.Visible = !lblSecretMessage2.Visible;
        }

        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            // Close Settings so the main menu (which hid when opening settings) will be shown by its FormClosed handler.
            this.Close();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            // Do not close Settings. Open the logout confirmation form.
            try
            {
                using (var logout = new stckChkrLogout())
                {
                    // Show as modal so the user must respond to logout choice before returning to Settings
                    logout.StartPosition = FormStartPosition.CenterParent;
                    logout.ShowDialog(this);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Unable to open logout dialog: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
