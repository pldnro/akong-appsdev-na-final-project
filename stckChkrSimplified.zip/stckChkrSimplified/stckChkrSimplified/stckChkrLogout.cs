﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stckChkrSimplified
{
    public partial class stckChkrLogout : Form
    {
        public stckChkrLogout()
        {
            InitializeComponent();
        }

        private void stckChkrLogout_Load(object sender, EventArgs e)
        {
            // No-op for now. Keep form initialization here if needed later.
        }

        // yes button = close all forms, end session
        private void button1_Click(object sender, EventArgs e)
        {
            // Terminate the application and close all open forms cleanly.
            // Application.Exit will stop the message loop and close forms.
            try
            {
                Application.Exit();
            }
            catch (Exception ex)
            {
                // Defensive fallback: show error and attempt to close this form.
                MessageBox.Show(this, $"Failed to exit application: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        // no button = bring person back to stckChkrSettings
        private void button2_Click(object sender, EventArgs e)
        {
            // Open the settings form and close this logout form.
            try
            {
                var settingsForm = new stckChkrSettings
                {
                    StartPosition = FormStartPosition.CenterScreen
                };
                settingsForm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Unable to open Settings: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Close this dialog so the user returns to Settings.
            this.Close();
        }
    }
}
