﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Windows.Forms;

namespace stckChkrSimplified
{
    public partial class stckChkrInventory : Form
    {
        // Path to the Access .mdb (per user's specification)
        private readonly string _dbPath = @"C:\Users\nneop\source\repos\stckChkrSimplified\stckChkrSimplified.mdb";
        private readonly string _connectionString;

        public stckChkrInventory()
        {
            InitializeComponent();

            // Build the Jet connection string for .mdb
            _connectionString = $"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={_dbPath};Persist Security Info=False;";

            // Wire up event handlers (designer did not have handlers assigned)
            btnCreateListing.Click += BtnCreateListing_Click;
            btnIMadd.Click += BtnIMadd_Click;
            btnIMedit.Click += BtnIMedit_Click;
            btnIMupdate.Click += BtnIMupdate_Click;
            btnIMremove.Click += BtnIMremove_Click;
            btnLMedit.Click += BtnLMedit_Click;
            btnLMsave.Click += BtnLMsave_Click;
            btnLMremove.Click += BtnLMremove_Click;
            btnLMupdate.Click += BtnLMupdate_Click;
            cBoxAddToListing.SelectedIndexChanged += CBoxAddToListing_SelectedIndexChanged;
            // Added: open combo on Enter so arrow keys can navigate immediately
            cBoxAddToListing.KeyDown += CBoxAddToListing_KeyDown;
            dgvListingWithItems.SelectionChanged += DgvListingWithItems_SelectionChanged;
            dgvListingWithItems.CellClick += DgvListingWithItems_CellClick;
            btnGoBack.Click += BtnGoBack_Click;
            this.Load += stckChkrInventory_Load;

            // Initial control state - most controls disabled until a listing is shown in the grid
            if (btnLMsave != null) btnLMsave.Enabled = false;
            if (txtItemID != null) txtItemID.ReadOnly = true; // Item ID is display-only
            if (btnIMupdate != null) btnIMupdate.Enabled = false;
        }

        // Form
        private void stckChkrInventory_Load(object sender, EventArgs e)
        {
            // Show only the overlay while the form initializes
            if (pictureBox1 != null)
            {
                pictureBox1.Visible = true;
                pictureBox1.BringToFront();
            }

            if (dgvListingWithItems != null)
            {
                dgvListingWithItems.Visible = false;
            }

            // Populate available listing tables into the combo box on load
            PopulateListingComboBox();

            // Apply initial UI state based on whether user listings exist
            ApplyUiVisibilityAndState();
        }

        // Create a new listing table and refresh the grid to show it (no MessageBox)
        private void BtnCreateListing_Click(object sender, EventArgs e)
        {
            var rawName = txtListingName.Text?.Trim();
            if (string.IsNullOrWhiteSpace(rawName))
            {
                // Do nothing if no name provided
                return;
            }

            var tableName = SanitizeTableName(rawName);

            var alreadyExists = TableExists(tableName);

            CreateTableIfNotExists(tableName);

            // Register listing in metadata so it receives a stable numeric ID
            RegisterListingIfMissing(tableName);

            // Refresh combo box and auto-select the newly created table so the grid shows it
            PopulateListingComboBox();
            cBoxAddToListing.SelectedItem = tableName;
            LoadTableIntoGrid(tableName);

            // Clear the user's input after creating the listing
            if (txtListingName != null)
                txtListingName.Clear();

            // Count only when a new table was actually created
            if (!alreadyExists)
            {
                try { StatsStore.IncrementStat("ListingsCreated"); } catch { }
            }

            ApplyUiVisibilityAndState();
        }

        // Add an item to the selected listing or to "Unlisted" if none chosen
        private void BtnIMadd_Click(object sender, EventArgs e)
        {
            var itemName = txtItemName.Text?.Trim();
            // Item ID is display-only; we generate it
            string itemId = null;

            // Determine target listing
            var targetListing = cBoxAddToListing.SelectedItem as string;
            if (string.IsNullOrWhiteSpace(targetListing))
            {
                targetListing = "Unlisted";
            }

            targetListing = SanitizeTableName(targetListing);

            // Ensure the target table exists (with Quantity column)
            CreateTableIfNotExists(targetListing);
            EnsureTableHasQuantityColumn(targetListing);

            // Insert the item with quantity
            var quantity = (int)(nudItemQuantity?.Value ?? 0);

            // Validate quantity: must be at least 1
            if (quantity < 1)
            {
                MessageBox.Show(this, "Please enter a quantity of at least 1.", "Invalid quantity", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (nudItemQuantity != null) nudItemQuantity.Focus();
                return;
            }

            InsertItemIntoTable(targetListing, itemId, itemName, quantity);

            // Record item added
            try { StatsStore.IncrementStat("ItemsAdded"); } catch { }

            // Refresh grid to show the inserted item
            LoadTableIntoGrid(targetListing);

            // Optionally clear item input fields (keeps UX smooth)
            txtItemName.Clear();
            // txtItemID is display-only so clear too
            txtItemID.Clear();
            nudItemQuantity.Value = 0;

            ApplyUiVisibilityAndState();
        }

        // When user selects a listing in the combo box, load that table
        private void CBoxAddToListing_SelectedIndexChanged(object sender, EventArgs e)
        {
            var tableName = cBoxAddToListing.SelectedItem as string;
            if (!string.IsNullOrWhiteSpace(tableName))
            {
                LoadTableIntoGrid(tableName);
            }

            // When a listing is chosen, listing modifier buttons become available
            UpdateListingModifierButtons();
            ApplyUiVisibilityAndState();
        }

        // New: pressing Enter while combo has focus opens it so arrow keys navigate
        private void CBoxAddToListing_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (cBoxAddToListing != null && cBoxAddToListing.Enabled)
                {
                    cBoxAddToListing.DroppedDown = true;
                    // Prevent ding / avoid treating Enter as other action
                    e.Handled = true;
                    e.SuppressKeyPress = true;
                }
            }
        }

        // Go back - close this form (menu logic handled elsewhere)
        private void BtnGoBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region Listing modifier handlers

        // Enter listing edit mode
        private void BtnLMedit_Click(object sender, EventArgs e)
        {
            // Disable edit button, enable save button
            btnLMedit.Enabled = false;
            btnLMsave.Enabled = true;

            // Lock item modification and creation while renaming
            btnCreateListing.Enabled = false;
            btnIMadd.Enabled = false;
            btnIMremove.Enabled = false;
            btnIMedit.Enabled = false;
            btnIMupdate.Enabled = false;

            // Allow user to edit txtListingName
            txtListingName.Enabled = true;
            txtListingName.Focus();
        }

        // Save listing rename
        private void BtnLMsave_Click(object sender, EventArgs e)
        {
            var currentListing = cBoxAddToListing.SelectedItem as string;
            if (string.IsNullOrWhiteSpace(currentListing))
            {
                // Nothing selected; restore buttons
                ExitListingEditMode();
                return;
            }

            var newNameRaw = txtListingName.Text?.Trim();
            var newName = SanitizeTableName(newNameRaw);
            if (string.IsNullOrWhiteSpace(newName) || string.Equals(newName, currentListing, StringComparison.Ordinal))
            {
                // No meaningful change; restore and exit edit mode
                ExitListingEditMode();
                return;
            }

            // Perform rename by copying data into a new table then dropping old table (safer for Jet)
            var safeOld = $"[{currentListing}]";
            var safeNew = $"[{newName}]";

            using (var conn = new OleDbConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();

                // If new table already exists, abort rename
                var restrictions = new string[4];
                restrictions[2] = newName;
                var schema = conn.GetSchema("Tables", restrictions);
                if (schema.Rows.Count > 0)
                {
                    MessageBox.Show(this, $"A listing named '{newName}' already exists.", "Rename failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    ExitListingEditMode();
                    return;
                }

                // Copy table structure+data
                cmd.CommandText = $"SELECT * INTO {safeNew} FROM {safeOld}";
                cmd.ExecuteNonQuery();

                // Ensure Quantity column exists on new table
                try
                {
                    cmd.CommandText = $"ALTER TABLE {safeNew} ADD COLUMN [Quantity] INTEGER";
                    cmd.ExecuteNonQuery();
                }
                catch { /* ignore if already exists or not supported */ }

                // Drop old table
                cmd.CommandText = $"DROP TABLE {safeOld}";
                cmd.ExecuteNonQuery();
            }

            // Refresh combo and select new name
            PopulateListingComboBox();
            cBoxAddToListing.SelectedItem = newName;

            // Count rename as an update
            try { StatsStore.IncrementStat("ListingsUpdated"); } catch { }

            ExitListingEditMode();
            ApplyUiVisibilityAndState();
        }

        private void BtnLMremove_Click(object sender, EventArgs e)
        {
            var currentListing = cBoxAddToListing.SelectedItem as string;
            if (string.IsNullOrWhiteSpace(currentListing)) return;

            var result = MessageBox.Show(this,
                $"Deleting listing '{currentListing}' will remove all its items from the database. Proceed?",
                "Confirm delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result != DialogResult.Yes) return;

            // If there are items in the table, move them to Unlisted first (to avoid data loss)
            try
            {
                MoveTableContentsToUnlisted(currentListing);
            }
            catch
            {
                // ignore move failure here; we'll still try to drop to keep UI responsive
            }

            // Unbind and dispose any in-memory table that might hold references
            if (dgvListingWithItems.DataSource is DataTable dt)
            {
                dgvListingWithItems.DataSource = null;
                dt.Dispose();
            }
            else
            {
                dgvListingWithItems.DataSource = null;
            }

            // Optionally force finalizers to run to clear any lingering COM/OLE objects
            GC.Collect();
            GC.WaitForPendingFinalizers();

            // Perform drop using a fresh connection
            using (var conn = new OleDbConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = $"DROP TABLE [{SanitizeTableName(currentListing)}]";
                cmd.ExecuteNonQuery();
            }

            // Record listing deletion
            try { StatsStore.IncrementStat("ListingsRemoved"); } catch { }

            PopulateListingComboBox();
            dgvListingWithItems.DataSource = null;
            pictureBox1.Visible = true;
            pictureBox1.BringToFront();

            ApplyUiVisibilityAndState();
        }

        // Optional explicit "update" button for listing modifier - keep to match designer (rename)
        private void BtnLMupdate_Click(object sender, EventArgs e)
        {
            // We treat Update same as Save for listing rename here
            BtnLMsave_Click(sender, e);
        }

        private void ExitListingEditMode()
        {
            btnLMedit.Enabled = true;
            btnLMsave.Enabled = false;

            btnCreateListing.Enabled = true;
            btnIMadd.Enabled = true;
            btnIMremove.Enabled = true;
            btnIMedit.Enabled = true;
            btnIMupdate.Enabled = false;

            txtListingName.Enabled = true;
        }

        #endregion

        #region Item modifier handlers

        // When a row is selected in the grid
        private void DgvListingWithItems_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvListingWithItems?.SelectedRows?.Count > 0)
            {
                // Populate item fields from selected row
                var row = dgvListingWithItems.SelectedRows[0];
                if (row != null)
                {
                    if (dgvListingWithItems.Columns.Contains("ItemID"))
                        txtItemID.Text = row.Cells["ItemID"].Value?.ToString() ?? string.Empty;
                    if (dgvListingWithItems.Columns.Contains("ItemName"))
                        txtItemName.Text = row.Cells["ItemName"].Value?.ToString() ?? string.Empty;
                    if (dgvListingWithItems.Columns.Contains("Quantity"))
                    {
                        int q;
                        int.TryParse(row.Cells["Quantity"].Value?.ToString() ?? "0", out q);
                        nudItemQuantity.Value = Math.Min(nudItemQuantity.Maximum, Math.Max(nudItemQuantity.Minimum, q));
                    }
                }

                // Default selection behavior: enable relevant buttons if a listing/table is loaded
                // Enabling specifics (ItemName vs ItemID) are handled in CellClick
                btnIMadd.Enabled = false;
                btnIMedit.Enabled = true;
                btnIMremove.Enabled = true;
                btnIMupdate.Enabled = true;
            }
            else
            {
                // Nothing selected - enable add, disable other item buttons
                btnIMadd.Enabled = true;
                btnIMedit.Enabled = false;
                btnIMremove.Enabled = false;
                btnIMupdate.Enabled = false;

                txtItemID.Clear();
                txtItemName.Clear();
                nudItemQuantity.Value = 0;
            }

            ApplyUiVisibilityAndState();
        }

        // Detect which column the user clicked so we can enable/disable item modifier buttons per spec
        private void DgvListingWithItems_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

            var col = dgvListingWithItems.Columns[e.ColumnIndex];
            if (string.Equals(col.Name, "ItemName", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(col.HeaderText, "ItemName", StringComparison.OrdinalIgnoreCase))
            {
                // Clicked ItemName -> enable edit/remove/update, disable Add
                btnIMadd.Enabled = false;
                btnIMremove.Enabled = true;
                btnIMedit.Enabled = true;
                btnIMupdate.Enabled = true;
            }
            else if (string.Equals(col.Name, "ItemID", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(col.HeaderText, "ItemID", StringComparison.OrdinalIgnoreCase))
            {
                // Clicked ItemID -> disable all item modifier buttons
                btnIMadd.Enabled = false;
                btnIMremove.Enabled = false;
                btnIMedit.Enabled = false;
                btnIMupdate.Enabled = false;
            }
            else
            {
                // Other columns behave like selection changed
                btnIMadd.Enabled = false;
                btnIMremove.Enabled = true;
                btnIMedit.Enabled = true;
                btnIMupdate.Enabled = true;
            }

            ApplyUiVisibilityAndState();
        }

        private void BtnIMedit_Click(object sender, EventArgs e)
        {
            // Enter item edit mode: lock listing controls and creation
            btnCreateListing.Enabled = false;
            btnLMedit.Enabled = false;
            btnLMsave.Enabled = false;
            btnLMremove.Enabled = false;
            btnLMupdate.Enabled = false;
            cBoxAddToListing.Enabled = false;

            // Allow editing item name and quantity; ID remains read-only/display-only
            txtItemName.Enabled = true;
            nudItemQuantity.Enabled = true;

            // Per spec: IMedit disabled while editing; IMupdate and IMremove enabled
            btnIMedit.Enabled = false;
            btnIMupdate.Enabled = true;
            btnIMremove.Enabled = true;

            ApplyUiVisibilityAndState();
        }

        private void BtnIMupdate_Click(object sender, EventArgs e)
        {
            // Update the item in the selected listing table
            var currentListing = cBoxAddToListing.SelectedItem as string;
            if (string.IsNullOrWhiteSpace(currentListing))
                return;

            var itemId = txtItemID.Text?.Trim();
            if (string.IsNullOrWhiteSpace(itemId))
                return;

            var newName = txtItemName.Text?.Trim();
            var newQty = (int)(nudItemQuantity?.Value ?? 0);

            var safeTable = $"[{SanitizeTableName(currentListing)}]";

            using (var conn = new OleDbConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = $"UPDATE {safeTable} SET [ItemName]=?, [Quantity]=? WHERE [ItemID]=?";
                cmd.Parameters.AddWithValue("p1", (object)newName ?? DBNull.Value);
                cmd.Parameters.AddWithValue("p2", newQty);
                cmd.Parameters.AddWithValue("p3", itemId);
                cmd.ExecuteNonQuery();
            }

            // Record item update
            try { StatsStore.IncrementStat("ItemsUpdated"); } catch { }

            // Refresh grid and exit edit mode
            LoadTableIntoGrid(currentListing);
            // restore controls
            btnCreateListing.Enabled = true;
            btnLMedit.Enabled = true;
            btnLMremove.Enabled = true;
            cBoxAddToListing.Enabled = true;
            btnIMadd.Enabled = true;
            btnIMedit.Enabled = false;
            btnIMupdate.Enabled = false;
            btnIMremove.Enabled = false;

            ApplyUiVisibilityAndState();
        }

        private void BtnIMremove_Click(object sender, EventArgs e)
        {
            var currentListing = cBoxAddToListing.SelectedItem as string;
            if (string.IsNullOrWhiteSpace(currentListing))
                return;

            var itemId = txtItemID.Text?.Trim();
            if (string.IsNullOrWhiteSpace(itemId))
                return;

            using (var conn = new OleDbConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = $"DELETE FROM [{SanitizeTableName(currentListing)}] WHERE [ItemID]=?";
                cmd.Parameters.AddWithValue("p1", itemId);
                cmd.ExecuteNonQuery();
            }

            // After removal, reassign ItemIDs sequentially per spec
            ReassignItemIds(currentListing);

            // Record item removed
            try { StatsStore.IncrementStat("ItemsRemoved"); } catch { }

            LoadTableIntoGrid(currentListing);
            ApplyUiVisibilityAndState();
        }

        #endregion

        #region Database helpers

        // Create the table if it does not already exist
        private void CreateTableIfNotExists(string tableName)
        {
            if (string.IsNullOrWhiteSpace(tableName))
            {
                return;
            }

            using (var conn = new OleDbConnection(_connectionString))
            {
                conn.Open();

                // Check schema for the table name (Access stores table names in TABLE_NAME)
                var restrictions = new string[4];
                // restrictions[2] is the table name filter
                restrictions[2] = tableName;

                var schema = conn.GetSchema("Tables", restrictions);
                if (schema.Rows.Count > 0)
                {
                    // Table already exists - ensure Quantity column present
                    EnsureTableHasQuantityColumn(tableName);
                    return;
                }

                // Create table with ItemID and ItemName and Quantity as integer
                var safeTable = $"[{tableName}]";
                using (var cmd = conn.CreateCommand())
                {
                    // Using TEXT for ItemID and ItemName, INTEGER for Quantity
                    cmd.CommandText = $"CREATE TABLE {safeTable} ([ItemID] TEXT(50), [ItemName] TEXT(255), [Quantity] INTEGER)";
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private bool TableExists(string tableName)
        {
            if (string.IsNullOrWhiteSpace(tableName)) return false;
            try
            {
                using (var conn = new OleDbConnection(_connectionString))
                {
                    conn.Open();
                    var restrictions = new string[4];
                    restrictions[2] = tableName;
                    var schema = conn.GetSchema("Tables", restrictions);
                    return schema.Rows.Count > 0;
                }
            }
            catch
            {
                return false;
            }
        }

        // Ensure the specified table has a Quantity column (adds it if missing)
        private void EnsureTableHasQuantityColumn(string tableName)
        {
            if (string.IsNullOrWhiteSpace(tableName)) return;
            var safeTable = $"[{tableName}]";

            using (var conn = new OleDbConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                try
                {
                    // Try to select the Quantity column; if it fails, add the column
                    cmd.CommandText = $"SELECT TOP 1 [Quantity] FROM {safeTable}";
                    using (var reader = cmd.ExecuteReader()) { /* if succeeds, column exists */ }
                }
                catch
                {
                    try
                    {
                        cmd.CommandText = $"ALTER TABLE {safeTable} ADD COLUMN [Quantity] INTEGER";
                        cmd.ExecuteNonQuery();
                    }
                    catch
                    {
                        // ignore if cannot add
                    }
                }
            }
        }

        // Insert an item into the specified table
        private void InsertItemIntoTable(string tableName, string itemId, string itemName, int quantity)
        {
            if (string.IsNullOrWhiteSpace(tableName))
            {
                return;
            }

            var safeTable = $"[{tableName}]";

            // Ensure Quantity column exists
            EnsureTableHasQuantityColumn(tableName);

            // Generate ItemID if not provided
            if (string.IsNullOrWhiteSpace(itemId))
            {
                itemId = GenerateNextItemId(tableName);
                if (txtItemID != null)
                    txtItemID.Text = itemId;
            }

            using (var conn = new OleDbConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = $"INSERT INTO {safeTable} ([ItemID], [ItemName], [Quantity]) VALUES (?, ?, ?)";
                cmd.Parameters.AddWithValue("p1", (object)itemId ?? DBNull.Value);
                cmd.Parameters.AddWithValue("p2", (object)itemName ?? DBNull.Value);
                cmd.Parameters.AddWithValue("p3", quantity);
                cmd.ExecuteNonQuery();
            }
        }

        // Generate next ItemID by finding the current maximum numeric suffix in the table and incrementing it.
        private string GenerateNextItemId(string tableName)
        {
            var listingId = GetListingNumericId(tableName);
            long maxSeq = 0;
            var safeTableName = SanitizeTableName(tableName);
            var safeTable = $"[{safeTableName}]";

            using (var conn = new OleDbConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                try
                {
                    cmd.CommandText = $"SELECT [ItemID] FROM {safeTable}";
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            if (reader.IsDBNull(0)) continue;
                            var id = reader.GetString(0);
                            if (string.IsNullOrWhiteSpace(id)) continue;
                            var idx = id.LastIndexOf('-');
                            if (idx < 0 || idx == id.Length - 1) continue;
                            var seqPart = id.Substring(idx + 1);
                            if (long.TryParse(seqPart, out var val) && val > maxSeq) maxSeq = val;
                        }
                    }
                }
                catch
                {
                    maxSeq = 0;
                }
            }

            var next = maxSeq + 1;
            return $"{listingId}-{next:0000000}";
        }

        private void EnsureListingsMetaTableExists()
        {
            using (var conn = new OleDbConnection(_connectionString))
            {
                conn.Open();

                var restrictions = new string[4];
                restrictions[2] = "ListingsMeta";
                var schema = conn.GetSchema("Tables", restrictions);
                if (schema.Rows.Count > 0) return;

                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "CREATE TABLE [ListingsMeta] ([ListingName] TEXT(255), [ListingId] INTEGER)";
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private int RegisterListingIfMissing(string listingName)
        {
            if (string.IsNullOrWhiteSpace(listingName)) throw new ArgumentNullException(nameof(listingName));

            EnsureListingsMetaTableExists();

            using (var conn = new OleDbConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();

                cmd.CommandText = "SELECT [ListingId] FROM [ListingsMeta] WHERE [ListingName]=?";
                cmd.Parameters.AddWithValue("p1", listingName);
                var res = cmd.ExecuteScalar();
                if (res != null && res != DBNull.Value) return Convert.ToInt32(res);

                int assigned;
                if (string.Equals(listingName, "Unlisted", StringComparison.OrdinalIgnoreCase))
                {
                    assigned = 0;
                }
                else
                {
                    cmd.Parameters.Clear();
                    cmd.CommandText = "SELECT MAX([ListingId]) FROM [ListingsMeta]";
                    var maxObj = cmd.ExecuteScalar();
                    if (maxObj == null || maxObj == DBNull.Value)
                        assigned = 1;
                    else
                    {
                        var max = Convert.ToInt32(maxObj);
                        assigned = max >= 0 ? max + 1 : 1;
                    }
                }

                cmd.Parameters.Clear();
                cmd.CommandText = "INSERT INTO [ListingsMeta] ([ListingName], [ListingId]) VALUES (?, ?)";
                cmd.Parameters.AddWithValue("p1", listingName);
                cmd.Parameters.AddWithValue("p2", assigned);
                cmd.ExecuteNonQuery();

                return assigned;
            }
        }

        private int GetListingNumericId(string tableName)
        {
            if (string.IsNullOrWhiteSpace(tableName)) return 1;
            try
            {
                EnsureListingsMetaTableExists();

                using (var conn = new OleDbConnection(_connectionString))
                using (var cmd = conn.CreateCommand())
                {
                    conn.Open();
                    cmd.CommandText = "SELECT [ListingId] FROM [ListingsMeta] WHERE [ListingName]=?";
                    cmd.Parameters.AddWithValue("p1", tableName);
                    var res = cmd.ExecuteScalar();
                    if (res != null && res != DBNull.Value) return Convert.ToInt32(res);
                }
            }
            catch { }

            if (string.Equals(tableName, "Unlisted", StringComparison.OrdinalIgnoreCase)) return 0;

            for (int i = 0; i < cBoxAddToListing.Items.Count; i++)
            {
                var item = cBoxAddToListing.Items[i] as string;
                if (string.Equals(item, tableName, StringComparison.OrdinalIgnoreCase)) return i + 1;
            }

            return 1;
        }

        private void MoveTableContentsToUnlisted(string tableName)
        {
            if (string.IsNullOrWhiteSpace(tableName)) return;
            if (string.Equals(tableName, "Unlisted", StringComparison.OrdinalIgnoreCase)) return;

            var safeTable = $"[{SanitizeTableName(tableName)}]";

            var items = new DataTable();
            using (var conn = new OleDbConnection(_connectionString))
            using (var adapter = new OleDbDataAdapter($"SELECT [ItemName], [Quantity] FROM {safeTable}", conn))
            {
                adapter.Fill(items);
            }

            if (items.Rows.Count == 0) return;

            CreateTableIfNotExists("Unlisted");
            EnsureTableHasQuantityColumn("Unlisted");

            foreach (DataRow r in items.Rows)
            {
                var name = r["ItemName"]?.ToString();
                int qty = 0;
                if (int.TryParse(r["Quantity"]?.ToString() ?? "0", out var q)) qty = q;

                InsertItemIntoTable("Unlisted", null, name, qty);
            }
        }

        private void LoadTableIntoGrid(string tableName)
        {
            if (string.IsNullOrWhiteSpace(tableName))
            {
                // show overlay and clear grid
                if (pictureBox1 != null)
                {
                    pictureBox1.Visible = true;
                    pictureBox1.BringToFront();
                }

                if (dgvListingWithItems != null)
                {
                    dgvListingWithItems.DataSource = null;
                    dgvListingWithItems.Visible = false;
                }

                ApplyUiVisibilityAndState();
                return;
            }

            var safeTable = $"[{tableName}]";

            try
            {
                // Ensure table has Quantity column
                EnsureTableHasQuantityColumn(tableName);

                using (var conn = new OleDbConnection(_connectionString))
                using (var adapter = new OleDbDataAdapter($"SELECT [ItemID], [ItemName], [Quantity] FROM {safeTable}", conn))
                {
                    var dt = new DataTable();
                    adapter.Fill(dt);
                    dgvListingWithItems.DataSource = dt;

                    // Hide overlay and show grid after load completes
                    if (pictureBox1 != null)
                    {
                        pictureBox1.Visible = false;
                    }

                    if (dgvListingWithItems != null)
                    {
                        dgvListingWithItems.Visible = true;
                    }
                }
            }
            catch
            {
                // If the table cannot be read for any reason, show overlay and empty grid (avoid MessageBox per user)
                if (dgvListingWithItems != null)
                {
                    dgvListingWithItems.DataSource = null;
                    dgvListingWithItems.Visible = false;
                }

                if (pictureBox1 != null)
                {
                    pictureBox1.Visible = true;
                    pictureBox1.BringToFront();
                }
            }

            ApplyUiVisibilityAndState();
        }

        private void PopulateListingComboBox()
        {
            // Ensure metadata and register Unlisted
            EnsureListingsMetaTableExists();
            RegisterListingIfMissing("Unlisted");

            // Register any existing tables (ensures metadata contains all user tables)
            using (var conn = new OleDbConnection(_connectionString))
            {
                conn.Open();
                var schema = conn.GetSchema("Tables");

                var userTables =
                    schema.AsEnumerable()
                          .Where(r => string.Equals(r.Field<string>("TABLE_TYPE"), "TABLE", StringComparison.OrdinalIgnoreCase))
                          .Select(r => r.Field<string>("TABLE_NAME"))
                          .Where(n => !string.IsNullOrWhiteSpace(n))
                          .ToList();

                // Register discovered tables into metadata (no-op if already present)
                foreach (var t in userTables)
                {
                    RegisterListingIfMissing(t);
                }

                // Remove orphan ListingsMeta entries for tables that no longer exist.
                try
                {
                    // Read all listing names from metadata
                    var metaNames = new System.Collections.Generic.List<string>();
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = "SELECT [ListingName] FROM [ListingsMeta]";
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                if (reader.IsDBNull(0)) continue;
                                metaNames.Add(reader.GetString(0));
                            }
                        }
                    }

                    foreach (var name in metaNames)
                    {
                        // keep Unlisted (ensure table exists) and remove other orphans
                        if (userTables.Any(u => string.Equals(u, name, StringComparison.OrdinalIgnoreCase)))
                        {
                            continue; // table exists, keep metadata
                        }

                        if (string.Equals(name, "Unlisted", StringComparison.OrdinalIgnoreCase))
                        {
                            // If Unlisted metadata exists but table does not, create the table
                            CreateTableIfNotExists("Unlisted");
                            continue;
                        }

                        // Delete orphan metadata row
                        using (var del = conn.CreateCommand())
                        {
                            del.CommandText = "DELETE FROM [ListingsMeta] WHERE [ListingName]=?";
                            del.Parameters.AddWithValue("p1", name);
                            try
                            {
                                del.ExecuteNonQuery();
                            }
                            catch
                            {
                                // ignore deletion failure and continue
                            }
                        }
                    }
                }
                catch
                {
                    // ignore cleanup failures
                }

                // Now read metadata ordered by ListingId for stable ordering and populate combo
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "SELECT [ListingName] FROM [ListingsMeta] ORDER BY [ListingId]";
                    using (var reader = cmd.ExecuteReader())
                    {
                        cBoxAddToListing.Items.Clear();
                        while (reader.Read())
                        {
                            if (reader.IsDBNull(0)) continue;
                            var name = reader.GetString(0);
                            cBoxAddToListing.Items.Add(name);
                        }
                    }
                }
            }

            UpdateListingModifierButtons();
        }

        // Simple sanitizer for table names: remove ']' chars and trim.
        // We keep spaces and most characters so the user's display names are preserved in the DB by using brackets when referencing.
        private static string SanitizeTableName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return name;
            }

            return name.Replace("]", string.Empty).Trim();
        }

        /// <summary>
        /// Reassigns ItemIDs in the specified listing table to be sequential, starting from 1, in the format {listingId}-{sequence:0000000}.
        /// </summary>
        private void ReassignItemIds(string tableName)
        {
            if (string.IsNullOrWhiteSpace(tableName))
                return;

            var safeTable = $"[{SanitizeTableName(tableName)}]";
            var listingId = GetListingNumericId(tableName);

            using (var conn = new OleDbConnection(_connectionString))
            {
                conn.Open();

                // Read all rows ordered by current ItemID (or ItemName as fallback)
                var items = new DataTable();
                using (var adapter = new OleDbDataAdapter($"SELECT [ItemName], [Quantity] FROM {safeTable} ORDER BY [ItemID]", conn))
                {
                    adapter.Fill(items);
                }

                // Remove all rows
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = $"DELETE FROM {safeTable}";
                    cmd.ExecuteNonQuery();
                }

                // Re-insert with new sequential ItemIDs
                int seq = 1;
                foreach (DataRow row in items.Rows)
                {
                    var newId = $"{listingId}-{seq:0000000}";
                    var name = row["ItemName"]?.ToString();
                    var qty = row["Quantity"] is int q ? q : int.TryParse(row["Quantity"]?.ToString(), out var parsed) ? parsed : 0;

                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = $"INSERT INTO {safeTable} ([ItemID], [ItemName], [Quantity]) VALUES (?, ?, ?)";
                        cmd.Parameters.AddWithValue("p1", newId);
                        cmd.Parameters.AddWithValue("p2", name ?? string.Empty);
                        cmd.Parameters.AddWithValue("p3", qty);
                        cmd.ExecuteNonQuery();
                    }
                    seq++;
                }
            }
        }

        /// <summary>
        /// Updates the visibility and enabled state of UI controls based on the current application state.
        /// </summary>
        private void ApplyUiVisibilityAndState()
        {
            // Example logic: enable/disable controls based on whether a listing is selected and items exist.
            bool hasListing = cBoxAddToListing.SelectedItem != null && !string.IsNullOrWhiteSpace(cBoxAddToListing.SelectedItem as string);
            bool hasRows = dgvListingWithItems.DataSource is DataTable dt && dt.Rows.Count > 0;

            btnIMadd.Enabled = hasListing;
            btnIMedit.Enabled = hasListing && hasRows && dgvListingWithItems.SelectedRows.Count > 0;
            btnIMremove.Enabled = hasListing && hasRows && dgvListingWithItems.SelectedRows.Count > 0;
            btnIMupdate.Enabled = hasListing && hasRows && dgvListingWithItems.SelectedRows.Count > 0;
            btnLMedit.Enabled = hasListing;
            btnLMremove.Enabled = hasListing && !string.Equals(cBoxAddToListing.SelectedItem as string, "Unlisted", StringComparison.OrdinalIgnoreCase);
            btnLMsave.Enabled = false; // Only enabled during edit mode
            btnLMupdate.Enabled = false; // Only enabled during edit mode
            btnCreateListing.Enabled = true;
            txtListingName.Enabled = true;
            txtItemName.Enabled = true;
            nudItemQuantity.Enabled = true;
        }

        // Add this method anywhere inside the stckChkrInventory class (preferably near other UI state helpers)
        private void UpdateListingModifierButtons()
        {
            // Example logic: enable/disable listing modifier buttons based on current selection
            bool hasListing = cBoxAddToListing.SelectedItem != null && !string.IsNullOrWhiteSpace(cBoxAddToListing.SelectedItem as string);
            btnLMedit.Enabled = hasListing;
            btnLMremove.Enabled = hasListing && !string.Equals(cBoxAddToListing.SelectedItem as string, "Unlisted", StringComparison.OrdinalIgnoreCase);
            // Save and Update are only enabled during edit mode, handled elsewhere
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // You can add any logic you want here, or leave it empty if not needed
        }

        // Add this method to your stckChkrInventory class
        private void nudItemQuantity_ValueChanged(object sender, EventArgs e)
        {
            // You can add logic here if you want to handle the value change event.
            // For now, this is just a placeholder to resolve the CS1061 error.
        }

        private void lblQuantity_Click(object sender, EventArgs e)
        {
            // You can add any logic you want here, or leave it empty if not needed
        }
        #endregion

        // C#
        private void DropTableExclusive(string tableName)
        {
            var safe = $"[{SanitizeTableName(tableName)}]";
            // Use connection string variant that disables pooling for DDL to avoid lingering locks
            var ddlConnString = _connectionString + "OLE DB Services=-4;";

            const int maxAttempts = 5;
            const int delayMs = 250;

            for (int attempt = 1; attempt <= maxAttempts; attempt++)
            {
                try
                {
                    using (var conn = new OleDbConnection(ddlConnString))
                    using (var cmd = conn.CreateCommand())
                    {
                        conn.Open();
                        cmd.CommandText = $"DROP TABLE {safe}";
                        cmd.ExecuteNonQuery();
                    }
                    return; // success
                }
                catch (OleDbException ex) when (IsLockError(ex))
                {
                    // log ex.Message / attempt; then wait and retry
                    System.Threading.Thread.Sleep(delayMs);
                    // last attempt will bubble up
                    if (attempt == maxAttempts) throw;
                }
            }
        }

        private static bool IsLockError(OleDbException ex)
        {
            // Jet/ACE common text: "could not lock table"
            return ex.Message?.IndexOf("could not lock table", StringComparison.OrdinalIgnoreCase) >= 0;
        }
    }
}