﻿namespace stckChkrSimplified
{
    partial class stckChkrSuppliers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSupplierName = new System.Windows.Forms.Label();
            this.lblSupplierItem = new System.Windows.Forms.Label();
            this.lblItemOnStock = new System.Windows.Forms.Label();
            this.nudItemOnStock = new System.Windows.Forms.NumericUpDown();
            this.txtSupplierName = new System.Windows.Forms.TextBox();
            this.txtSupplierItem = new System.Windows.Forms.TextBox();
            this.cBoxYes = new System.Windows.Forms.CheckBox();
            this.cBoxNo = new System.Windows.Forms.CheckBox();
            this.lblSupplierListQ = new System.Windows.Forms.Label();
            this.lblIfYesListing = new System.Windows.Forms.Label();
            this.lblIfNo = new System.Windows.Forms.Label();
            this.cmbLocateListing = new System.Windows.Forms.ComboBox();
            this.cBoxAllowViewListY = new System.Windows.Forms.CheckBox();
            this.cBoxAllowViewListN = new System.Windows.Forms.CheckBox();
            this.lblListingName = new System.Windows.Forms.Label();
            this.txtListingName = new System.Windows.Forms.TextBox();
            this.lblAllowViewListQ = new System.Windows.Forms.Label();
            this.cBoxCreateListing = new System.Windows.Forms.CheckBox();
            this.cBoxNoListing = new System.Windows.Forms.CheckBox();
            this.lblNote = new System.Windows.Forms.Label();
            this.btnAddSupplier = new System.Windows.Forms.Button();
            this.btnGoBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudItemOnStock)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSupplierName
            // 
            this.lblSupplierName.AutoSize = true;
            this.lblSupplierName.Location = new System.Drawing.Point(35, 30);
            this.lblSupplierName.Name = "lblSupplierName";
            this.lblSupplierName.Size = new System.Drawing.Size(79, 13);
            this.lblSupplierName.TabIndex = 0;
            this.lblSupplierName.Text = "Supplier Name:";
            this.lblSupplierName.Click += new System.EventHandler(this.lblSupplierName_Click);
            // 
            // lblSupplierItem
            // 
            this.lblSupplierItem.AutoSize = true;
            this.lblSupplierItem.Location = new System.Drawing.Point(35, 56);
            this.lblSupplierItem.Name = "lblSupplierItem";
            this.lblSupplierItem.Size = new System.Drawing.Size(71, 13);
            this.lblSupplierItem.TabIndex = 0;
            this.lblSupplierItem.Text = "Supplier Item:";
            this.lblSupplierItem.Click += new System.EventHandler(this.lblSupplierItem_Click);
            // 
            // lblItemOnStock
            // 
            this.lblItemOnStock.AutoSize = true;
            this.lblItemOnStock.Location = new System.Drawing.Point(35, 81);
            this.lblItemOnStock.Name = "lblItemOnStock";
            this.lblItemOnStock.Size = new System.Drawing.Size(76, 13);
            this.lblItemOnStock.TabIndex = 0;
            this.lblItemOnStock.Text = "Item on Stock:";
            this.lblItemOnStock.Click += new System.EventHandler(this.lblItemOnStock_Click);
            // 
            // nudItemOnStock
            // 
            this.nudItemOnStock.Location = new System.Drawing.Point(215, 79);
            this.nudItemOnStock.Name = "nudItemOnStock";
            this.nudItemOnStock.Size = new System.Drawing.Size(120, 20);
            this.nudItemOnStock.TabIndex = 1;
            this.nudItemOnStock.ValueChanged += new System.EventHandler(this.nudItemOnStock_ValueChanged);
            // 
            // txtSupplierName
            // 
            this.txtSupplierName.Location = new System.Drawing.Point(144, 27);
            this.txtSupplierName.Name = "txtSupplierName";
            this.txtSupplierName.Size = new System.Drawing.Size(191, 20);
            this.txtSupplierName.TabIndex = 2;
            this.txtSupplierName.TextChanged += new System.EventHandler(this.txtSupplierName_TextChanged);
            // 
            // txtSupplierItem
            // 
            this.txtSupplierItem.Location = new System.Drawing.Point(144, 53);
            this.txtSupplierItem.Name = "txtSupplierItem";
            this.txtSupplierItem.Size = new System.Drawing.Size(191, 20);
            this.txtSupplierItem.TabIndex = 2;
            this.txtSupplierItem.TextChanged += new System.EventHandler(this.txtSupplierItem_TextChanged);
            // 
            // cBoxYes
            // 
            this.cBoxYes.AutoSize = true;
            this.cBoxYes.Location = new System.Drawing.Point(245, 115);
            this.cBoxYes.Name = "cBoxYes";
            this.cBoxYes.Size = new System.Drawing.Size(44, 17);
            this.cBoxYes.TabIndex = 3;
            this.cBoxYes.Text = "Yes";
            this.cBoxYes.UseVisualStyleBackColor = true;
            this.cBoxYes.CheckedChanged += new System.EventHandler(this.cBoxYes_CheckedChanged);
            // 
            // cBoxNo
            // 
            this.cBoxNo.AutoSize = true;
            this.cBoxNo.Location = new System.Drawing.Point(295, 115);
            this.cBoxNo.Name = "cBoxNo";
            this.cBoxNo.Size = new System.Drawing.Size(40, 17);
            this.cBoxNo.TabIndex = 3;
            this.cBoxNo.Text = "No";
            this.cBoxNo.UseVisualStyleBackColor = true;
            this.cBoxNo.CheckedChanged += new System.EventHandler(this.cBoxNo_CheckedChanged);
            // 
            // lblSupplierListQ
            // 
            this.lblSupplierListQ.AutoSize = true;
            this.lblSupplierListQ.Location = new System.Drawing.Point(35, 116);
            this.lblSupplierListQ.Name = "lblSupplierListQ";
            this.lblSupplierListQ.Size = new System.Drawing.Size(160, 13);
            this.lblSupplierListQ.TabIndex = 0;
            this.lblSupplierListQ.Text = "Does the supplier have a listing?";
            this.lblSupplierListQ.Click += new System.EventHandler(this.lblSupplierListQ_Click);
            // 
            // lblIfYesListing
            // 
            this.lblIfYesListing.AutoSize = true;
            this.lblIfYesListing.Location = new System.Drawing.Point(35, 148);
            this.lblIfYesListing.Name = "lblIfYesListing";
            this.lblIfYesListing.Size = new System.Drawing.Size(117, 13);
            this.lblIfYesListing.TabIndex = 0;
            this.lblIfYesListing.Text = "If yes, locate the listing:";
            this.lblIfYesListing.Click += new System.EventHandler(this.lblIfYesListing_Click);
            // 
            // lblIfNo
            // 
            this.lblIfNo.AutoSize = true;
            this.lblIfNo.Location = new System.Drawing.Point(35, 168);
            this.lblIfNo.Name = "lblIfNo";
            this.lblIfNo.Size = new System.Drawing.Size(181, 13);
            this.lblIfNo.TabIndex = 0;
            this.lblIfNo.Text = "If no, do you want to create a listing?";
            this.lblIfNo.Click += new System.EventHandler(this.lblIfNo_Click);
            // 
            // cmbLocateListing
            // 
            this.cmbLocateListing.FormattingEnabled = true;
            this.cmbLocateListing.Location = new System.Drawing.Point(215, 145);
            this.cmbLocateListing.Name = "cmbLocateListing";
            this.cmbLocateListing.Size = new System.Drawing.Size(120, 21);
            this.cmbLocateListing.TabIndex = 4;
            this.cmbLocateListing.SelectedIndexChanged += new System.EventHandler(this.cmbLocateListing_SelectedIndexChanged);
            // 
            // cBoxAllowViewListY
            // 
            this.cBoxAllowViewListY.AutoSize = true;
            this.cBoxAllowViewListY.Location = new System.Drawing.Point(245, 293);
            this.cBoxAllowViewListY.Name = "cBoxAllowViewListY";
            this.cBoxAllowViewListY.Size = new System.Drawing.Size(44, 17);
            this.cBoxAllowViewListY.TabIndex = 3;
            this.cBoxAllowViewListY.Text = "Yes";
            this.cBoxAllowViewListY.UseVisualStyleBackColor = true;
            this.cBoxAllowViewListY.CheckedChanged += new System.EventHandler(this.cBoxAllowViewListY_CheckedChanged);
            // 
            // cBoxAllowViewListN
            // 
            this.cBoxAllowViewListN.AutoSize = true;
            this.cBoxAllowViewListN.Location = new System.Drawing.Point(295, 293);
            this.cBoxAllowViewListN.Name = "cBoxAllowViewListN";
            this.cBoxAllowViewListN.Size = new System.Drawing.Size(40, 17);
            this.cBoxAllowViewListN.TabIndex = 3;
            this.cBoxAllowViewListN.Text = "No";
            this.cBoxAllowViewListN.UseVisualStyleBackColor = true;
            this.cBoxAllowViewListN.CheckedChanged += new System.EventHandler(this.cBoxAllowViewListN_CheckedChanged);
            // 
            // lblListingName
            // 
            this.lblListingName.AutoSize = true;
            this.lblListingName.Location = new System.Drawing.Point(35, 219);
            this.lblListingName.Name = "lblListingName";
            this.lblListingName.Size = new System.Drawing.Size(71, 13);
            this.lblListingName.TabIndex = 0;
            this.lblListingName.Text = "Listing Name:";
            this.lblListingName.Click += new System.EventHandler(this.lblListingName_Click);
            // 
            // txtListingName
            // 
            this.txtListingName.Location = new System.Drawing.Point(144, 216);
            this.txtListingName.Name = "txtListingName";
            this.txtListingName.Size = new System.Drawing.Size(191, 20);
            this.txtListingName.TabIndex = 2;
            this.txtListingName.TextChanged += new System.EventHandler(this.txtListingName_TextChanged);
            // 
            // lblAllowViewListQ
            // 
            this.lblAllowViewListQ.AutoSize = true;
            this.lblAllowViewListQ.Location = new System.Drawing.Point(35, 294);
            this.lblAllowViewListQ.Name = "lblAllowViewListQ";
            this.lblAllowViewListQ.Size = new System.Drawing.Size(177, 13);
            this.lblAllowViewListQ.TabIndex = 0;
            this.lblAllowViewListQ.Text = "Allow other users to see your listing?";
            this.lblAllowViewListQ.Click += new System.EventHandler(this.lblAllowViewListQ_Click);
            // 
            // cBoxCreateListing
            // 
            this.cBoxCreateListing.AutoSize = true;
            this.cBoxCreateListing.Location = new System.Drawing.Point(245, 168);
            this.cBoxCreateListing.Name = "cBoxCreateListing";
            this.cBoxCreateListing.Size = new System.Drawing.Size(44, 17);
            this.cBoxCreateListing.TabIndex = 3;
            this.cBoxCreateListing.Text = "Yes";
            this.cBoxCreateListing.UseVisualStyleBackColor = true;
            this.cBoxCreateListing.CheckedChanged += new System.EventHandler(this.cBoxCreateListing_CheckedChanged);
            // 
            // cBoxNoListing
            // 
            this.cBoxNoListing.AutoSize = true;
            this.cBoxNoListing.Location = new System.Drawing.Point(295, 168);
            this.cBoxNoListing.Name = "cBoxNoListing";
            this.cBoxNoListing.Size = new System.Drawing.Size(40, 17);
            this.cBoxNoListing.TabIndex = 3;
            this.cBoxNoListing.Text = "No";
            this.cBoxNoListing.UseVisualStyleBackColor = true;
            this.cBoxNoListing.CheckedChanged += new System.EventHandler(this.cBoxNoListing_CheckedChanged);
            // 
            // lblNote
            // 
            this.lblNote.Location = new System.Drawing.Point(35, 239);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(300, 36);
            this.lblNote.TabIndex = 5;
            this.lblNote.Text = "Note: The Supplier Item will automatically be added to the supplier\'s listing.";
            this.lblNote.Click += new System.EventHandler(this.lblNote_Click);
            // 
            // btnAddSupplier
            // 
            this.btnAddSupplier.Location = new System.Drawing.Point(240, 350);
            this.btnAddSupplier.Name = "btnAddSupplier";
            this.btnAddSupplier.Size = new System.Drawing.Size(95, 22);
            this.btnAddSupplier.TabIndex = 6;
            this.btnAddSupplier.Text = "Add Supplier";
            this.btnAddSupplier.UseVisualStyleBackColor = true;
            this.btnAddSupplier.Click += new System.EventHandler(this.btnAddSupplier_Click);
            // 
            // btnGoBack
            // 
            this.btnGoBack.Location = new System.Drawing.Point(12, 415);
            this.btnGoBack.Name = "btnGoBack";
            this.btnGoBack.Size = new System.Drawing.Size(76, 23);
            this.btnGoBack.TabIndex = 7;
            this.btnGoBack.Text = "Go back";
            this.btnGoBack.UseVisualStyleBackColor = true;
            this.btnGoBack.Click += new System.EventHandler(this.btnGoBack_Click);
            // 
            // stckChkrSuppliers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(371, 450);
            this.Controls.Add(this.btnGoBack);
            this.Controls.Add(this.btnAddSupplier);
            this.Controls.Add(this.lblNote);
            this.Controls.Add(this.cmbLocateListing);
            this.Controls.Add(this.cBoxNoListing);
            this.Controls.Add(this.cBoxCreateListing);
            this.Controls.Add(this.cBoxAllowViewListN);
            this.Controls.Add(this.cBoxAllowViewListY);
            this.Controls.Add(this.cBoxNo);
            this.Controls.Add(this.cBoxYes);
            this.Controls.Add(this.txtSupplierItem);
            this.Controls.Add(this.txtListingName);
            this.Controls.Add(this.txtSupplierName);
            this.Controls.Add(this.nudItemOnStock);
            this.Controls.Add(this.lblIfNo);
            this.Controls.Add(this.lblIfYesListing);
            this.Controls.Add(this.lblSupplierListQ);
            this.Controls.Add(this.lblItemOnStock);
            this.Controls.Add(this.lblAllowViewListQ);
            this.Controls.Add(this.lblListingName);
            this.Controls.Add(this.lblSupplierItem);
            this.Controls.Add(this.lblSupplierName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "stckChkrSuppliers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "stckChkrSuppliers";
            this.Load += new System.EventHandler(this.stckChkrSuppliers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudItemOnStock)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSupplierName;
        private System.Windows.Forms.Label lblSupplierItem;
        private System.Windows.Forms.Label lblItemOnStock;
        private System.Windows.Forms.NumericUpDown nudItemOnStock;
        private System.Windows.Forms.TextBox txtSupplierName;
        private System.Windows.Forms.TextBox txtSupplierItem;
        private System.Windows.Forms.CheckBox cBoxYes;
        private System.Windows.Forms.CheckBox cBoxNo;
        private System.Windows.Forms.Label lblSupplierListQ;
        private System.Windows.Forms.Label lblIfYesListing;
        private System.Windows.Forms.Label lblIfNo;
        private System.Windows.Forms.ComboBox cmbLocateListing;
        private System.Windows.Forms.CheckBox cBoxAllowViewListY;
        private System.Windows.Forms.CheckBox cBoxAllowViewListN;
        private System.Windows.Forms.Label lblListingName;
        private System.Windows.Forms.TextBox txtListingName;
        private System.Windows.Forms.Label lblAllowViewListQ;
        private System.Windows.Forms.CheckBox cBoxCreateListing;
        private System.Windows.Forms.CheckBox cBoxNoListing;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.Button btnAddSupplier;
        private System.Windows.Forms.Button btnGoBack;
    }
}