﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace stckChkrSimplified
{
    public partial class stckChkrMenu : Form
    {
        public stckChkrMenu()
        {
            InitializeComponent();
        }

        private void stckChkrMenu_Load(object sender, EventArgs e)
        {
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            var inventoryForm = new stckChkrInventory();
            OpenExclusiveForm(inventoryForm);
        }

        private void btnSupplier_Click(object sender, EventArgs e)
        {
            var suppliersForm = new stckChkrSuppliers();
            OpenExclusiveForm(suppliersForm);
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            var settingsForm = new stckChkrSettings();
            OpenExclusiveForm(settingsForm);
        }

        /// <summary>
        /// Ensures the requested form opens immediately and without interference from other open top-level forms.
        /// Closes other open forms (except this menu) before showing the requested child form.
        /// </summary>
        private void OpenExclusiveForm(Form child)
        {
            if (child == null) return;

            // Hide menu immediately to avoid visual overlap while closing other forms.
            this.Visible = false;

            // Capture open forms to close (can't modify Application.OpenForms while enumerating it directly).
            var toClose = new List<Form>();
            foreach (Form f in Application.OpenForms)
            {
                if (f == this) continue;
                if (f == child) continue;
                toClose.Add(f);
            }

            // Close collected forms synchronously.
            foreach (var f in toClose)
            {
                try
                {
                    // If a form is a modal dialog (Owned by something), Close still works; ignore exceptions.
                    f.FormClosed -= RestoreMenuOnChildClosed; // avoid accidental duplicate handlers
                    f.Close();
                }
                catch
                {
                    // ignore and continue closing others
                }
            }

            // Ensure we restore the menu when the child closes.
            child.FormClosed += RestoreMenuOnChildClosed;

            // Show the requested form centered on screen.
            child.StartPosition = FormStartPosition.CenterScreen;
            child.Show();

            // If the child is visible, keep menu hidden; otherwise restore menu visibility.
            if (!child.Visible)
            {
                this.Visible = true;
            }
        }

        private void RestoreMenuOnChildClosed(object sender, FormClosedEventArgs e)
        {
            // Show the menu when the child form closes.
            if (!this.IsDisposed && !this.Visible)
            {
                this.Show();
            }
        }
    }
}
