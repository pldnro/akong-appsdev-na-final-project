﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Windows.Forms;

namespace stckChkrSimplified
{
    public partial class stckChkrSuppliers : Form
    {
        private readonly string _dbPath = @"C:\Users\nneop\source\repos\stckChkrSimplified\stckChkrSimplified.mdb";
        private readonly string _connectionString;
        private const string SupplierColumnName = "Supplier Name";
        private string _initialSupplierName;
        private string _initialSupplierItem;
        private int _initialItemOnStock;
        private bool _initialCBoxYes;
        private bool _initialCBoxNo;
        private bool _initialCreateListing;
        private bool _initialNoListing;
        private bool _initialAllowViewYes;

        public stckChkrSuppliers()
        {
            InitializeComponent();

            _connectionString = $"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={_dbPath};Persist Security Info=False;";            

            // Wire up events not wired in designer
            txtListingName.TextChanged += txtListingName_TextChanged;
            cmbLocateListing.SelectedIndexChanged += cmbLocateListing_SelectedIndexChanged;

            // Provide hover help for the allow-view label
            lblAllowViewListQ.MouseHover += lblAllowViewListQ_MouseHover;
        }

        private void stckChkrSuppliers_Load(object sender, EventArgs e)
        {
            // Read all controls on load into local fields (per requirement)
            ReadFormControlsOnLoad();

            // Initial UI state
            lblIfYesListing.Visible = false;
            cmbLocateListing.Visible = false;

            lblIfNo.Visible = false;
            cBoxCreateListing.Visible = false;
            cBoxNoListing.Visible = false;

            lblListingName.Visible = false;
            txtListingName.Visible = false;
            lblNote.Visible = false;

            lblAllowViewListQ.Visible = false;
            cBoxAllowViewListY.Visible = false;
            cBoxAllowViewListN.Visible = false;

            btnAddSupplier.Enabled = false;

            // Pre-populate listings so combo is ready if user chooses Yes
            PopulateListingComboBox();
        }

        private void ReadFormControlsOnLoad()
        {
            _initialSupplierName = txtSupplierName?.Text ?? string.Empty;
            _initialSupplierItem = txtSupplierItem?.Text ?? string.Empty;
            _initialItemOnStock = (int)(nudItemOnStock?.Value ?? 0);
            _initialCBoxYes = cBoxYes?.Checked ?? false;
            _initialCBoxNo = cBoxNo?.Checked ?? false;
            _initialCreateListing = cBoxCreateListing?.Checked ?? false;
            _initialNoListing = cBoxNoListing?.Checked ?? false;
            _initialAllowViewYes = cBoxAllowViewListY?.Checked ?? false;
        }

        // Supplier Information
        private void lblSupplierName_Click(object sender, EventArgs e) { }

        private void txtSupplierName_TextChanged(object sender, EventArgs e)
        {
            UpdateAddButtonState();
        }

        private void lblSupplierItem_Click(object sender, EventArgs e) { }

        private void txtSupplierItem_TextChanged(object sender, EventArgs e)
        {
            UpdateAddButtonState();
        }

        private void lblItemOnStock_Click(object sender, EventArgs e) { }

        private void nudItemOnStock_ValueChanged(object sender, EventArgs e)
        {
            UpdateAddButtonState();
        }

        // Does the supplier have an item?
        private void lblSupplierListQ_Click(object sender, EventArgs e) { }

        private void cBoxYes_CheckedChanged(object sender, EventArgs e)
        {
            if (cBoxYes.Checked)
            {
                cBoxNo.Checked = false;

                lblIfYesListing.Visible = true;
                cmbLocateListing.Visible = true;
                PopulateListingComboBox();

                // hide create-new-list UI
                cBoxCreateListing.Visible = false;
                cBoxNoListing.Visible = false;
                lblListingName.Visible = false;
                txtListingName.Visible = false;
                lblNote.Visible = false;
                lblAllowViewListQ.Visible = false;
                cBoxAllowViewListY.Visible = false;
                cBoxAllowViewListN.Visible = false;
            }
            else
            {
                lblIfYesListing.Visible = false;
                cmbLocateListing.Visible = false;
            }

            UpdateAddButtonState();
        }

        private void cBoxNo_CheckedChanged(object sender, EventArgs e)
        {
            if (cBoxNo.Checked)
            {
                cBoxYes.Checked = false;

                lblIfNo.Visible = true;
                cBoxCreateListing.Visible = true;
                cBoxNoListing.Visible = true;

                lblIfYesListing.Visible = false;
                cmbLocateListing.Visible = false;
            }
            else
            {
                lblIfNo.Visible = false;
                cBoxCreateListing.Visible = false;
                cBoxNoListing.Visible = false;
            }

            UpdateAddButtonState();
        }

        // If user selects yes, show listing options
        private void lblIfYesListing_Click(object sender, EventArgs e) { }

        private void cmbLocateListing_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateAddButtonState();
        }

        // If user selects no, allow user to create listing
        private void lblIfNo_Click(object sender, EventArgs e) { }

        // Checkbox Yes or No for creating listing
        private void cBoxCreateListing_CheckedChanged(object sender, EventArgs e)
        {
            if (cBoxCreateListing.Checked)
            {
                cBoxNoListing.Checked = false;
                lblListingName.Visible = true;
                txtListingName.Visible = true;
                lblNote.Visible = true;

                lblAllowViewListQ.Visible = true;
                cBoxAllowViewListY.Visible = true;
                cBoxAllowViewListN.Visible = true;

                // hide locate controls
                lblIfYesListing.Visible = false;
                cmbLocateListing.Visible = false;

                btnAddSupplier.Enabled = false;
            }
            else
            {
                lblListingName.Visible = false;
                txtListingName.Visible = false;
                lblNote.Visible = false;
            }
        }

        private void cBoxNoListing_CheckedChanged(object sender, EventArgs e)
        {
            if (cBoxNoListing.Checked)
            {
                cBoxCreateListing.Checked = false;

                // hide listing name inputs
                lblListingName.Visible = false;
                txtListingName.Visible = false;
                lblNote.Visible = false;

                // show allow view question
                lblAllowViewListQ.Visible = true;
                cBoxAllowViewListY.Visible = true;
                cBoxAllowViewListN.Visible = true;

                // enable add if supplier fields ok
                UpdateAddButtonState();
            }
            else
            {
                // when unchecked, hide allow view unless other path shows it
                if (!cBoxCreateListing.Checked)
                {
                    lblAllowViewListQ.Visible = false;
                    cBoxAllowViewListY.Visible = false;
                    cBoxAllowViewListN.Visible = false;
                }
            }
        }

        // Create Listing Information
        private void lblListingName_Click(object sender, EventArgs e) { }

        private void txtListingName_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtListingName.Text)) return;

            var safeName = SanitizeTableName(txtListingName.Text);
            if (TableExists(safeName))
            {
                MessageBox.Show(this, $"A listing named '{safeName}' already exists. Choose a different name.", "Name exists", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtListingName.Clear();
                txtListingName.Focus();
                btnAddSupplier.Enabled = false;
                return;
            }

            // If listing name entered and supplier fields valid, enable add
            UpdateAddButtonState();
        }

        private void lblNote_Click(object sender, EventArgs e) { }

        // Asks user if they want their listing to be found in the listing section of the program
        private void lblAllowViewListQ_Click(object sender, EventArgs e) { }

        private void lblAllowViewListQ_MouseHover(object sender, EventArgs e)
        {
            // Show explanation on hover as requested
            MessageBox.Show(this,
                "If yes, your listing will be visible, and anyone can add items in your listing inventory. If no, your listing will not be visible, and no one can add items to your listing inventory.",
                "Listing visibility", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void cBoxAllowViewListY_CheckedChanged(object sender, EventArgs e)
        {
            if (cBoxAllowViewListY.Checked) cBoxAllowViewListN.Checked = false;
        }

        private void cBoxAllowViewListN_CheckedChanged(object sender, EventArgs e)
        {
            if (cBoxAllowViewListN.Checked) cBoxAllowViewListY.Checked = false;
        }

        // Adds the supplier and listing information to the program
        private void btnAddSupplier_Click(object sender, EventArgs e)
        {
            // Validate required supplier fields
            if (!AreSupplierFieldsValid())
            {
                MessageBox.Show(this, "Please fill Supplier Name, Supplier Item and a quantity greater than zero.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var supplierName = txtSupplierName.Text.Trim();
            var supplierItem = txtSupplierItem.Text.Trim();
            var qty = (int)nudItemOnStock.Value;

            try
            {
                if (cBoxYes.Checked)
                {
                    // Add into existing listing selected
                    var listing = cmbLocateListing.SelectedItem as string;
                    if (string.IsNullOrWhiteSpace(listing))
                    {
                        MessageBox.Show(this, "Please select a listing.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    AddSupplierColumnIfMissing(listing);
                    var itemId = GenerateNextItemId(listing);
                    InsertItemIntoTable(listing, itemId, supplierItem, qty, supplierName);

                    // Record supplier add
                    try { StatsStore.IncrementStat("SuppliersAdded"); } catch { }

                    MessageBox.Show(this, "Supplier item added to selected listing.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (cBoxNo.Checked)
                {
                    if (cBoxCreateListing.Checked)
                    {
                        // Create new listing then insert
                        var newListing = SanitizeTableName(txtListingName.Text?.Trim());
                        if (string.IsNullOrWhiteSpace(newListing))
                        {
                            MessageBox.Show(this, "Please enter a listing name.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        if (TableExists(newListing))
                        {
                            MessageBox.Show(this, $"A listing named '{newListing}' already exists. Choose a different name.", "Name exists", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        CreateTableIfNotExists(newListing);

                        // Register listing so ID sequence stays consistent with Inventory
                        RegisterListingIfMissing(newListing);

                        // Optionally register in ListingsMeta if user allowed visibility (redundant with RegisterListingIfMissing but kept for semantics)
                        if (cBoxAllowViewListY.Checked)
                        {
                            // Ensure it's present and visible to others via ListingsMeta
                            RegisterListingIfMissing(newListing);
                        }

                        AddSupplierColumnIfMissing(newListing);
                        var itemIdNew = GenerateNextItemId(newListing);
                        InsertItemIntoTable(newListing, itemIdNew, supplierItem, qty, supplierName);

                        // Record supplier add
                        try { StatsStore.IncrementStat("SuppliersAdded"); } catch { }

                        MessageBox.Show(this, "New listing created and supplier item added.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else if (cBoxNoListing.Checked)
                    {
                        // Supplier chooses not to fill a listing name: create a listing named after Supplier and insert there
                        var newListing = SanitizeTableName(supplierName);
                        if (string.IsNullOrWhiteSpace(newListing))
                        {
                            MessageBox.Show(this, "Supplier name is not valid for a listing. Please provide a valid supplier name.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }

                        // Create table named after supplier and register listing ID
                        CreateTableIfNotExists(newListing);
                        RegisterListingIfMissing(newListing);

                        AddSupplierColumnIfMissing(newListing);
                        var itemIdNew = GenerateNextItemId(newListing);
                        InsertItemIntoTable(newListing, itemIdNew, supplierItem, qty, supplierName);

                        // Record supplier add
                        try { StatsStore.IncrementStat("SuppliersAdded"); } catch { }

                        MessageBox.Show(this, "Supplier listing created and item added.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show(this, "Please choose whether to create a listing or not.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show(this, "Please indicate whether the supplier has a listing (Yes/No).", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Reset form after success
                ResetFormState();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Failed to add supplier item: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Return to main menu
        private void btnGoBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // ---- Helpers ----

        private void ResetFormState()
        {
            txtSupplierName.Clear();
            txtSupplierItem.Clear();
            nudItemOnStock.Value = 0;

            cBoxYes.Checked = false;
            cBoxNo.Checked = false;
            cBoxCreateListing.Checked = false;
            cBoxNoListing.Checked = false;
            cBoxAllowViewListY.Checked = false;
            cBoxAllowViewListN.Checked = false;

            txtListingName.Clear();
            cmbLocateListing.Items.Clear();

            stckChkrSuppliers_Load(this, EventArgs.Empty);
        }

        private bool AreSupplierFieldsValid()
        {
            return !string.IsNullOrWhiteSpace(txtSupplierName.Text)
                   && !string.IsNullOrWhiteSpace(txtSupplierItem.Text)
                   && nudItemOnStock.Value > 0;
        }

        private void UpdateAddButtonState()
        {
            // base validation
            if (!AreSupplierFieldsValid())
            {
                btnAddSupplier.Enabled = false;
                return;
            }

            if (cBoxYes.Checked)
            {
                btnAddSupplier.Enabled = cmbLocateListing.SelectedItem != null;
            }
            else if (cBoxNo.Checked)
            {
                if (cBoxCreateListing.Checked)
                {
                    btnAddSupplier.Enabled = !string.IsNullOrWhiteSpace(txtListingName.Text);
                }
                else if (cBoxNoListing.Checked)
                {
                    btnAddSupplier.Enabled = true;
                }
                else
                {
                    btnAddSupplier.Enabled = false;
                }
            }
            else
            {
                btnAddSupplier.Enabled = false;
            }
        }

        private void PopulateListingComboBox()
        {
            cmbLocateListing.Items.Clear();
            try
            {
                using (var conn = new OleDbConnection(_connectionString))
                {
                    conn.Open();
                    var schema = conn.GetSchema("Tables");
                    var userTables =
                        schema.AsEnumerable()
                              .Where(r => string.Equals(r.Field<string>("TABLE_TYPE"), "TABLE", StringComparison.OrdinalIgnoreCase))
                              .Select(r => r.Field<string>("TABLE_NAME"))
                              .Where(n => !string.IsNullOrWhiteSpace(n))
                              .ToList();

                    // Optionally exclude ListingsMeta
                    userTables = userTables.Where(n => !string.Equals(n, "ListingsMeta", StringComparison.OrdinalIgnoreCase)).ToList();

                    foreach (var t in userTables)
                    {
                        cmbLocateListing.Items.Add(t);
                    }
                }
            }
            catch
            {
                // ignore - keep combo empty
            }
        }

        private bool TableExists(string tableName)
        {
            if (string.IsNullOrWhiteSpace(tableName)) return false;
            try
            {
                using (var conn = new OleDbConnection(_connectionString))
                {
                    conn.Open();
                    var restrictions = new string[4];
                    restrictions[2] = tableName;
                    var schema = conn.GetSchema("Tables", restrictions);
                    return schema.Rows.Count > 0;
                }
            }
            catch
            {
                return false;
            }
        }

        private static string SanitizeTableName(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return name;
            return name.Replace("]", string.Empty).Trim();
        }

        private void CreateTableIfNotExists(string tableName)
        {
            if (string.IsNullOrWhiteSpace(tableName)) return;
            var safe = $"[{SanitizeTableName(tableName)}]";
            using (var conn = new OleDbConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                var restrictions = new string[4];
                restrictions[2] = tableName;
                var schema = conn.GetSchema("Tables", restrictions);
                if (schema.Rows.Count > 0)
                {
                    // Ensure Quantity column exists
                    try
                    {
                        cmd.CommandText = $"SELECT TOP 1 [Quantity] FROM {safe}";
                        using (var r = cmd.ExecuteReader()) { }
                    }
                    catch
                    {
                        try
                        {
                            cmd.CommandText = $"ALTER TABLE {safe} ADD COLUMN [Quantity] INTEGER";
                            cmd.ExecuteNonQuery();
                        }
                        catch { }
                    }
                    return;
                }

                cmd.CommandText = $"CREATE TABLE {safe} ([ItemID] TEXT(50), [ItemName] TEXT(255), [Quantity] INTEGER)";
                cmd.ExecuteNonQuery();
            }
        }

        private void AddSupplierColumnIfMissing(string tableName)
        {
            if (string.IsNullOrWhiteSpace(tableName)) return;
            var safe = $"[{SanitizeTableName(tableName)}]";
            using (var conn = new OleDbConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                try
                {
                    cmd.CommandText = $"SELECT TOP 1 [{SupplierColumnName}] FROM {safe}";
                    using (var reader = cmd.ExecuteReader()) { }
                }
                catch
                {
                    try
                    {
                        cmd.CommandText = $"ALTER TABLE {safe} ADD COLUMN [{SupplierColumnName}] TEXT(255)";
                        cmd.ExecuteNonQuery();
                    }
                    catch
                    {
                        // ignore
                    }
                }
            }
        }

        private void InsertItemIntoTable(string tableName, string itemId, string itemName, int quantity, string supplierName)
        {
            if (string.IsNullOrWhiteSpace(tableName)) return;
            var safe = $"[{SanitizeTableName(tableName)}]";

            using (var conn = new OleDbConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();

                // Build insert depending on whether Supplier column exists
                bool hasSupplierColumn;
                try
                {
                    var restrictions = new string[4];
                    restrictions[2] = tableName;
                    var schema = conn.GetSchema("Columns", restrictions);
                    hasSupplierColumn = schema.AsEnumerable().Any(r => string.Equals(r.Field<string>("COLUMN_NAME"), SupplierColumnName, StringComparison.OrdinalIgnoreCase));
                }
                catch
                {
                    hasSupplierColumn = false;
                }

                if (hasSupplierColumn)
                {
                    cmd.CommandText = $"INSERT INTO {safe} ([ItemID], [ItemName], [Quantity], [{SupplierColumnName}]) VALUES (?, ?, ?, ?)";
                    cmd.Parameters.AddWithValue("p1", (object)itemId ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("p2", (object)itemName ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("p3", quantity);
                    cmd.Parameters.AddWithValue("p4", (object)supplierName ?? DBNull.Value);
                }
                else
                {
                    cmd.CommandText = $"INSERT INTO {safe} ([ItemID], [ItemName], [Quantity]) VALUES (?, ?, ?)";
                    cmd.Parameters.AddWithValue("p1", (object)itemId ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("p2", (object)itemName ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("p3", quantity);
                }

                cmd.ExecuteNonQuery();
            }
        }

        // ---- ListingsMeta helpers ----
        private void EnsureListingsMetaTableExists()
        {
            using (var conn = new OleDbConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                var restrictions = new string[4];
                restrictions[2] = "ListingsMeta";
                var schema = conn.GetSchema("Tables", restrictions);
                if (schema.Rows.Count > 0) return;

                cmd.CommandText = "CREATE TABLE [ListingsMeta] ([ListingName] TEXT(255), [ListingId] INTEGER)";
                cmd.ExecuteNonQuery();
            }
        }

        private int RegisterListingIfMissing(string listingName)
        {
            if (string.IsNullOrWhiteSpace(listingName)) throw new ArgumentNullException(nameof(listingName));
            EnsureListingsMetaTableExists();

            using (var conn = new OleDbConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();

                cmd.CommandText = "SELECT [ListingId] FROM [ListingsMeta] WHERE [ListingName]=?";
                cmd.Parameters.AddWithValue("p1", listingName);
                var res = cmd.ExecuteScalar();
                if (res != null && res != DBNull.Value) return Convert.ToInt32(res);

                int assigned;
                cmd.Parameters.Clear();
                cmd.CommandText = "SELECT MAX([ListingId]) FROM [ListingsMeta]";
                var maxObj = cmd.ExecuteScalar();
                if (maxObj == null || maxObj == DBNull.Value)
                    assigned = 1;
                else
                {
                    var max = Convert.ToInt32(maxObj);
                    assigned = max >= 0 ? max + 1 : 1;
                }

                cmd.Parameters.Clear();
                cmd.CommandText = "INSERT INTO [ListingsMeta] ([ListingName], [ListingId]) VALUES (?, ?)";
                cmd.Parameters.AddWithValue("p1", listingName);
                cmd.Parameters.AddWithValue("p2", assigned);
                cmd.ExecuteNonQuery();

                return assigned;
            }
        }

        private int GetListingNumericId(string tableName)
        {
            if (string.IsNullOrWhiteSpace(tableName)) return 1;
            try
            {
                EnsureListingsMetaTableExists();

                using (var conn = new OleDbConnection(_connectionString))
                using (var cmd = conn.CreateCommand())
                {
                    conn.Open();
                    cmd.CommandText = "SELECT [ListingId] FROM [ListingsMeta] WHERE [ListingName]=?";
                    cmd.Parameters.AddWithValue("p1", tableName);
                    var res = cmd.ExecuteScalar();
                    if (res != null && res != DBNull.Value) return Convert.ToInt32(res);
                }
            }
            catch { }

            if (string.Equals(tableName, "Unlisted", StringComparison.OrdinalIgnoreCase)) return 0;

            for (int i = 0; i < cmbLocateListing.Items.Count; i++)
            {
                var item = cmbLocateListing.Items[i] as string;
                if (string.Equals(item, tableName, StringComparison.OrdinalIgnoreCase)) return i + 1;
            }

            return 1;
        }

        private string GenerateNextItemId(string tableName)
        {
            var listingId = GetListingNumericId(tableName);
            long maxSeq = 0;
            var safeTableName = SanitizeTableName(tableName);
            var safeTable = $"[{safeTableName}]";

            using (var conn = new OleDbConnection(_connectionString))
            using (var cmd = conn.CreateCommand())
            {
                conn.Open();
                try
                {
                    cmd.CommandText = $"SELECT [ItemID] FROM {safeTable}";
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            if (reader.IsDBNull(0)) continue;
                            var id = reader.GetString(0);
                            if (string.IsNullOrWhiteSpace(id)) continue;
                            var idx = id.LastIndexOf('-');
                            if (idx < 0 || idx == id.Length - 1) continue;
                            var seqPart = id.Substring(idx + 1);
                            if (long.TryParse(seqPart, out var val) && val > maxSeq) maxSeq = val;
                        }
                    }
                }
                catch
                {
                    maxSeq = 0;
                }
            }

            var next = maxSeq + 1;
            return $"{listingId}-{next:0000000}";
        }

        // ---- end helpers ----
    }
}
