﻿namespace stckChkrSimplified
{
    partial class stckChkrInventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnIMadd = new System.Windows.Forms.Button();
            this.btnIMedit = new System.Windows.Forms.Button();
            this.btnIMupdate = new System.Windows.Forms.Button();
            this.btnIMremove = new System.Windows.Forms.Button();
            this.dgvListingWithItems = new System.Windows.Forms.DataGridView();
            this.btnGoBack = new System.Windows.Forms.Button();
            this.lblListingName = new System.Windows.Forms.Label();
            this.txtItemName = new System.Windows.Forms.TextBox();
            this.lblAddToListing = new System.Windows.Forms.Label();
            this.cBoxAddToListing = new System.Windows.Forms.ComboBox();
            this.lblItemName = new System.Windows.Forms.Label();
            this.txtListingName = new System.Windows.Forms.TextBox();
            this.lblItemID = new System.Windows.Forms.Label();
            this.txtItemID = new System.Windows.Forms.TextBox();
            this.btnCreateListing = new System.Windows.Forms.Button();
            this.lblItemModifier = new System.Windows.Forms.Label();
            this.btnLMedit = new System.Windows.Forms.Button();
            this.btnLMupdate = new System.Windows.Forms.Button();
            this.btnLMremove = new System.Windows.Forms.Button();
            this.lblListingModifier = new System.Windows.Forms.Label();
            this.btnLMsave = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.nudItemQuantity = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.dgvListingWithItems)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudItemQuantity)).BeginInit();
            this.SuspendLayout();
            // 
            // btnIMadd
            // 
            this.btnIMadd.Location = new System.Drawing.Point(7, 361);
            this.btnIMadd.Name = "btnIMadd";
            this.btnIMadd.Size = new System.Drawing.Size(75, 23);
            this.btnIMadd.TabIndex = 0;
            this.btnIMadd.Text = "Add";
            this.btnIMadd.UseVisualStyleBackColor = true;
            // 
            // btnIMedit
            // 
            this.btnIMedit.Location = new System.Drawing.Point(169, 361);
            this.btnIMedit.Name = "btnIMedit";
            this.btnIMedit.Size = new System.Drawing.Size(75, 23);
            this.btnIMedit.TabIndex = 0;
            this.btnIMedit.Text = "Edit";
            this.btnIMedit.UseVisualStyleBackColor = true;
            // 
            // btnIMupdate
            // 
            this.btnIMupdate.Location = new System.Drawing.Point(250, 361);
            this.btnIMupdate.Name = "btnIMupdate";
            this.btnIMupdate.Size = new System.Drawing.Size(75, 23);
            this.btnIMupdate.TabIndex = 0;
            this.btnIMupdate.Text = "Update";
            this.btnIMupdate.UseVisualStyleBackColor = true;
            // 
            // btnIMremove
            // 
            this.btnIMremove.Location = new System.Drawing.Point(88, 361);
            this.btnIMremove.Name = "btnIMremove";
            this.btnIMremove.Size = new System.Drawing.Size(75, 23);
            this.btnIMremove.TabIndex = 0;
            this.btnIMremove.Text = "Remove";
            this.btnIMremove.UseVisualStyleBackColor = true;
            // 
            // dgvListingWithItems
            // 
            this.dgvListingWithItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvListingWithItems.Location = new System.Drawing.Point(331, 12);
            this.dgvListingWithItems.Name = "dgvListingWithItems";
            this.dgvListingWithItems.Size = new System.Drawing.Size(457, 426);
            this.dgvListingWithItems.TabIndex = 1;
            // 
            // btnGoBack
            // 
            this.btnGoBack.Location = new System.Drawing.Point(15, 415);
            this.btnGoBack.Name = "btnGoBack";
            this.btnGoBack.Size = new System.Drawing.Size(75, 23);
            this.btnGoBack.TabIndex = 4;
            this.btnGoBack.Text = "Go back";
            this.btnGoBack.UseVisualStyleBackColor = true;
            // 
            // lblListingName
            // 
            this.lblListingName.AutoSize = true;
            this.lblListingName.Location = new System.Drawing.Point(11, 51);
            this.lblListingName.Name = "lblListingName";
            this.lblListingName.Size = new System.Drawing.Size(71, 13);
            this.lblListingName.TabIndex = 5;
            this.lblListingName.Text = "Listing Name:";
            // 
            // txtItemName
            // 
            this.txtItemName.Location = new System.Drawing.Point(117, 121);
            this.txtItemName.Name = "txtItemName";
            this.txtItemName.Size = new System.Drawing.Size(182, 20);
            this.txtItemName.TabIndex = 6;
            // 
            // lblAddToListing
            // 
            this.lblAddToListing.AutoSize = true;
            this.lblAddToListing.Location = new System.Drawing.Point(9, 202);
            this.lblAddToListing.Name = "lblAddToListing";
            this.lblAddToListing.Size = new System.Drawing.Size(74, 13);
            this.lblAddToListing.TabIndex = 8;
            this.lblAddToListing.Text = "Add to Listing:";
            // 
            // cBoxAddToListing
            // 
            this.cBoxAddToListing.FormattingEnabled = true;
            this.cBoxAddToListing.Location = new System.Drawing.Point(117, 199);
            this.cBoxAddToListing.Name = "cBoxAddToListing";
            this.cBoxAddToListing.Size = new System.Drawing.Size(181, 21);
            this.cBoxAddToListing.TabIndex = 9;
            // 
            // lblItemName
            // 
            this.lblItemName.AutoSize = true;
            this.lblItemName.Location = new System.Drawing.Point(12, 124);
            this.lblItemName.Name = "lblItemName";
            this.lblItemName.Size = new System.Drawing.Size(61, 13);
            this.lblItemName.TabIndex = 10;
            this.lblItemName.Text = "Item Name:";
            // 
            // txtListingName
            // 
            this.txtListingName.Location = new System.Drawing.Point(117, 48);
            this.txtListingName.Name = "txtListingName";
            this.txtListingName.Size = new System.Drawing.Size(182, 20);
            this.txtListingName.TabIndex = 6;
            // 
            // lblItemID
            // 
            this.lblItemID.AutoSize = true;
            this.lblItemID.Location = new System.Drawing.Point(12, 150);
            this.lblItemID.Name = "lblItemID";
            this.lblItemID.Size = new System.Drawing.Size(44, 13);
            this.lblItemID.TabIndex = 10;
            this.lblItemID.Text = "Item ID:";
            // 
            // txtItemID
            // 
            this.txtItemID.Enabled = false;
            this.txtItemID.Location = new System.Drawing.Point(117, 147);
            this.txtItemID.Name = "txtItemID";
            this.txtItemID.Size = new System.Drawing.Size(182, 20);
            this.txtItemID.TabIndex = 6;
            // 
            // btnCreateListing
            // 
            this.btnCreateListing.Location = new System.Drawing.Point(173, 74);
            this.btnCreateListing.Name = "btnCreateListing";
            this.btnCreateListing.Size = new System.Drawing.Size(126, 23);
            this.btnCreateListing.TabIndex = 11;
            this.btnCreateListing.Text = "Create Listing";
            this.btnCreateListing.UseVisualStyleBackColor = true;
            // 
            // lblItemModifier
            // 
            this.lblItemModifier.AutoSize = true;
            this.lblItemModifier.Location = new System.Drawing.Point(6, 335);
            this.lblItemModifier.Name = "lblItemModifier";
            this.lblItemModifier.Size = new System.Drawing.Size(67, 13);
            this.lblItemModifier.TabIndex = 13;
            this.lblItemModifier.Text = "Item Modifier";
            // 
            // btnLMedit
            // 
            this.btnLMedit.Location = new System.Drawing.Point(169, 284);
            this.btnLMedit.Name = "btnLMedit";
            this.btnLMedit.Size = new System.Drawing.Size(75, 23);
            this.btnLMedit.TabIndex = 0;
            this.btnLMedit.Text = "Edit";
            this.btnLMedit.UseVisualStyleBackColor = true;
            // 
            // btnLMupdate
            // 
            this.btnLMupdate.Location = new System.Drawing.Point(250, 284);
            this.btnLMupdate.Name = "btnLMupdate";
            this.btnLMupdate.Size = new System.Drawing.Size(75, 23);
            this.btnLMupdate.TabIndex = 0;
            this.btnLMupdate.Text = "Update";
            this.btnLMupdate.UseVisualStyleBackColor = true;
            // 
            // btnLMremove
            // 
            this.btnLMremove.Location = new System.Drawing.Point(88, 284);
            this.btnLMremove.Name = "btnLMremove";
            this.btnLMremove.Size = new System.Drawing.Size(75, 23);
            this.btnLMremove.TabIndex = 0;
            this.btnLMremove.Text = "Remove";
            this.btnLMremove.UseVisualStyleBackColor = true;
            // 
            // lblListingModifier
            // 
            this.lblListingModifier.AutoSize = true;
            this.lblListingModifier.Location = new System.Drawing.Point(6, 261);
            this.lblListingModifier.Name = "lblListingModifier";
            this.lblListingModifier.Size = new System.Drawing.Size(77, 13);
            this.lblListingModifier.TabIndex = 14;
            this.lblListingModifier.Text = "Listing Modifier";
            // 
            // btnLMsave
            // 
            this.btnLMsave.Location = new System.Drawing.Point(7, 284);
            this.btnLMsave.Name = "btnLMsave";
            this.btnLMsave.Size = new System.Drawing.Size(75, 23);
            this.btnLMsave.TabIndex = 0;
            this.btnLMsave.Text = "Save";
            this.btnLMsave.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::stckChkrSimplified.Properties.Resources.point_at_yourself;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = global::stckChkrSimplified.Properties.Resources.point_at_yourself;
            this.pictureBox1.InitialImage = global::stckChkrSimplified.Properties.Resources.point_at_yourself;
            this.pictureBox1.Location = new System.Drawing.Point(331, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(457, 426);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Location = new System.Drawing.Point(11, 178);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(49, 13);
            this.lblQuantity.TabIndex = 16;
            this.lblQuantity.Text = "Quantity:";
            this.lblQuantity.Click += new System.EventHandler(this.lblQuantity_Click);
            // 
            // nudItemQuantity
            // 
            this.nudItemQuantity.Location = new System.Drawing.Point(117, 176);
            this.nudItemQuantity.Name = "nudItemQuantity";
            this.nudItemQuantity.Size = new System.Drawing.Size(182, 20);
            this.nudItemQuantity.TabIndex = 17;
            this.nudItemQuantity.ValueChanged += new System.EventHandler(this.nudItemQuantity_ValueChanged);
            // 
            // stckChkrInventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.nudItemQuantity);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblListingModifier);
            this.Controls.Add(this.lblItemModifier);
            this.Controls.Add(this.btnCreateListing);
            this.Controls.Add(this.lblItemID);
            this.Controls.Add(this.lblItemName);
            this.Controls.Add(this.cBoxAddToListing);
            this.Controls.Add(this.lblAddToListing);
            this.Controls.Add(this.txtListingName);
            this.Controls.Add(this.txtItemID);
            this.Controls.Add(this.txtItemName);
            this.Controls.Add(this.lblListingName);
            this.Controls.Add(this.btnGoBack);
            this.Controls.Add(this.dgvListingWithItems);
            this.Controls.Add(this.btnLMremove);
            this.Controls.Add(this.btnIMremove);
            this.Controls.Add(this.btnLMsave);
            this.Controls.Add(this.btnLMupdate);
            this.Controls.Add(this.btnLMedit);
            this.Controls.Add(this.btnIMupdate);
            this.Controls.Add(this.btnIMedit);
            this.Controls.Add(this.btnIMadd);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "stckChkrInventory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "stckChkrInventory";
            this.Load += new System.EventHandler(this.stckChkrInventory_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvListingWithItems)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudItemQuantity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIMadd;
        private System.Windows.Forms.Button btnIMedit;
        private System.Windows.Forms.Button btnIMupdate;
        private System.Windows.Forms.Button btnIMremove;
        private System.Windows.Forms.DataGridView dgvListingWithItems;
        private System.Windows.Forms.Button btnGoBack;
        private System.Windows.Forms.Label lblListingName;
        private System.Windows.Forms.TextBox txtItemName;
        private System.Windows.Forms.Label lblAddToListing;
        private System.Windows.Forms.ComboBox cBoxAddToListing;
        private System.Windows.Forms.Label lblItemName;
        private System.Windows.Forms.TextBox txtListingName;
        private System.Windows.Forms.Label lblItemID;
        private System.Windows.Forms.TextBox txtItemID;
        private System.Windows.Forms.Button btnCreateListing;
        private System.Windows.Forms.Label lblItemModifier;
        private System.Windows.Forms.Button btnLMedit;
        private System.Windows.Forms.Button btnLMupdate;
        private System.Windows.Forms.Button btnLMremove;
        private System.Windows.Forms.Label lblListingModifier;
        private System.Windows.Forms.Button btnLMsave;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.NumericUpDown nudItemQuantity;
    }
}