﻿namespace winStckChkr
{
    partial class winStckChkrRegister2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPageOf = new System.Windows.Forms.Label();
            this.btnRegister = new System.Windows.Forms.Button();
            this.txtRegisterPassword = new System.Windows.Forms.TextBox();
            this.lblRegisterPassword = new System.Windows.Forms.Label();
            this.txtRegisterEmail = new System.Windows.Forms.TextBox();
            this.lblLastname = new System.Windows.Forms.Label();
            this.lblRegisterEmail = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.txtRegisterUsername = new System.Windows.Forms.TextBox();
            this.gboxAccountInformation = new System.Windows.Forms.GroupBox();
            this.lblCorrectPasswordRetype = new System.Windows.Forms.Label();
            this.lblCorrectPassword = new System.Windows.Forms.Label();
            this.lblCorrectUsername = new System.Windows.Forms.Label();
            this.lblCorrectEmail = new System.Windows.Forms.Label();
            this.btnHidePassword = new System.Windows.Forms.Button();
            this.btnShowPassword = new System.Windows.Forms.Button();
            this.txtRegisterPasswordRetype = new System.Windows.Forms.TextBox();
            this.lblRegisterPasswordRetype = new System.Windows.Forms.Label();
            this.lblAccReq2 = new System.Windows.Forms.Label();
            this.lblAccReq1 = new System.Windows.Forms.Label();
            this.lblPasswordRetypeNotMatched = new System.Windows.Forms.Label();
            this.lblRegisterUsername = new System.Windows.Forms.Label();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.gboxAccountInformation.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPageOf
            // 
            this.lblPageOf.AutoSize = true;
            this.lblPageOf.Location = new System.Drawing.Point(11, 266);
            this.lblPageOf.Name = "lblPageOf";
            this.lblPageOf.Size = new System.Drawing.Size(62, 13);
            this.lblPageOf.TabIndex = 6;
            this.lblPageOf.Text = "Page 2 of 5";
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(260, 253);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(75, 23);
            this.btnRegister.TabIndex = 4;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // txtRegisterPassword
            // 
            this.txtRegisterPassword.Location = new System.Drawing.Point(144, 93);
            this.txtRegisterPassword.Name = "txtRegisterPassword";
            this.txtRegisterPassword.Size = new System.Drawing.Size(150, 20);
            this.txtRegisterPassword.TabIndex = 1;
            this.txtRegisterPassword.UseSystemPasswordChar = true;
            this.txtRegisterPassword.TextChanged += new System.EventHandler(this.txtRegisterPassword_TextChanged);
            // 
            // lblRegisterPassword
            // 
            this.lblRegisterPassword.AutoSize = true;
            this.lblRegisterPassword.Location = new System.Drawing.Point(15, 96);
            this.lblRegisterPassword.Name = "lblRegisterPassword";
            this.lblRegisterPassword.Size = new System.Drawing.Size(53, 13);
            this.lblRegisterPassword.TabIndex = 0;
            this.lblRegisterPassword.Text = "Password";
            // 
            // txtRegisterEmail
            // 
            this.txtRegisterEmail.Location = new System.Drawing.Point(144, 24);
            this.txtRegisterEmail.Name = "txtRegisterEmail";
            this.txtRegisterEmail.Size = new System.Drawing.Size(150, 20);
            this.txtRegisterEmail.TabIndex = 1;
            this.txtRegisterEmail.TextChanged += new System.EventHandler(this.txtRegisterEmail_TextChanged);
            // 
            // lblLastname
            // 
            this.lblLastname.AutoSize = true;
            this.lblLastname.Location = new System.Drawing.Point(15, 51);
            this.lblLastname.Name = "lblLastname";
            this.lblLastname.Size = new System.Drawing.Size(0, 13);
            this.lblLastname.TabIndex = 0;
            // 
            // lblRegisterEmail
            // 
            this.lblRegisterEmail.AutoSize = true;
            this.lblRegisterEmail.Location = new System.Drawing.Point(15, 27);
            this.lblRegisterEmail.Name = "lblRegisterEmail";
            this.lblRegisterEmail.Size = new System.Drawing.Size(32, 13);
            this.lblRegisterEmail.TabIndex = 0;
            this.lblRegisterEmail.Text = "Email";
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(179, 253);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 23);
            this.btnNext.TabIndex = 5;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // txtRegisterUsername
            // 
            this.txtRegisterUsername.Location = new System.Drawing.Point(144, 48);
            this.txtRegisterUsername.Name = "txtRegisterUsername";
            this.txtRegisterUsername.Size = new System.Drawing.Size(150, 20);
            this.txtRegisterUsername.TabIndex = 1;
            this.txtRegisterUsername.TextChanged += new System.EventHandler(this.txtRegisterUsername_TextChanged);
            // 
            // gboxAccountInformation
            // 
            this.gboxAccountInformation.Controls.Add(this.lblCorrectPasswordRetype);
            this.gboxAccountInformation.Controls.Add(this.lblCorrectPassword);
            this.gboxAccountInformation.Controls.Add(this.lblCorrectUsername);
            this.gboxAccountInformation.Controls.Add(this.lblCorrectEmail);
            this.gboxAccountInformation.Controls.Add(this.btnHidePassword);
            this.gboxAccountInformation.Controls.Add(this.btnShowPassword);
            this.gboxAccountInformation.Controls.Add(this.txtRegisterPasswordRetype);
            this.gboxAccountInformation.Controls.Add(this.txtRegisterPassword);
            this.gboxAccountInformation.Controls.Add(this.txtRegisterUsername);
            this.gboxAccountInformation.Controls.Add(this.lblRegisterPasswordRetype);
            this.gboxAccountInformation.Controls.Add(this.lblAccReq2);
            this.gboxAccountInformation.Controls.Add(this.lblAccReq1);
            this.gboxAccountInformation.Controls.Add(this.lblPasswordRetypeNotMatched);
            this.gboxAccountInformation.Controls.Add(this.lblRegisterPassword);
            this.gboxAccountInformation.Controls.Add(this.txtRegisterEmail);
            this.gboxAccountInformation.Controls.Add(this.lblLastname);
            this.gboxAccountInformation.Controls.Add(this.lblRegisterUsername);
            this.gboxAccountInformation.Controls.Add(this.lblRegisterEmail);
            this.gboxAccountInformation.Location = new System.Drawing.Point(14, 12);
            this.gboxAccountInformation.Name = "gboxAccountInformation";
            this.gboxAccountInformation.Size = new System.Drawing.Size(404, 235);
            this.gboxAccountInformation.TabIndex = 3;
            this.gboxAccountInformation.TabStop = false;
            this.gboxAccountInformation.Text = "Account Information";
            // 
            // lblCorrectPasswordRetype
            // 
            this.lblCorrectPasswordRetype.AutoSize = true;
            this.lblCorrectPasswordRetype.ForeColor = System.Drawing.Color.Lime;
            this.lblCorrectPasswordRetype.Location = new System.Drawing.Point(300, 122);
            this.lblCorrectPasswordRetype.Name = "lblCorrectPasswordRetype";
            this.lblCorrectPasswordRetype.Size = new System.Drawing.Size(15, 13);
            this.lblCorrectPasswordRetype.TabIndex = 3;
            this.lblCorrectPasswordRetype.Text = "✓";
            // 
            // lblCorrectPassword
            // 
            this.lblCorrectPassword.AutoSize = true;
            this.lblCorrectPassword.ForeColor = System.Drawing.Color.Lime;
            this.lblCorrectPassword.Location = new System.Drawing.Point(300, 96);
            this.lblCorrectPassword.Name = "lblCorrectPassword";
            this.lblCorrectPassword.Size = new System.Drawing.Size(15, 13);
            this.lblCorrectPassword.TabIndex = 3;
            this.lblCorrectPassword.Text = "✓";
            // 
            // lblCorrectUsername
            // 
            this.lblCorrectUsername.AutoSize = true;
            this.lblCorrectUsername.ForeColor = System.Drawing.Color.Lime;
            this.lblCorrectUsername.Location = new System.Drawing.Point(300, 51);
            this.lblCorrectUsername.Name = "lblCorrectUsername";
            this.lblCorrectUsername.Size = new System.Drawing.Size(15, 13);
            this.lblCorrectUsername.TabIndex = 3;
            this.lblCorrectUsername.Text = "✓";
            // 
            // lblCorrectEmail
            // 
            this.lblCorrectEmail.AutoSize = true;
            this.lblCorrectEmail.ForeColor = System.Drawing.Color.Lime;
            this.lblCorrectEmail.Location = new System.Drawing.Point(300, 27);
            this.lblCorrectEmail.Name = "lblCorrectEmail";
            this.lblCorrectEmail.Size = new System.Drawing.Size(15, 13);
            this.lblCorrectEmail.TabIndex = 3;
            this.lblCorrectEmail.Text = "✓";
            // 
            // btnHidePassword
            // 
            this.btnHidePassword.Location = new System.Drawing.Point(214, 145);
            this.btnHidePassword.Name = "btnHidePassword";
            this.btnHidePassword.Size = new System.Drawing.Size(129, 23);
            this.btnHidePassword.TabIndex = 2;
            this.btnHidePassword.Text = "Hide Password";
            this.btnHidePassword.UseVisualStyleBackColor = true;
            this.btnHidePassword.Click += new System.EventHandler(this.btnShowPassword_Click);
            // 
            // btnShowPassword
            // 
            this.btnShowPassword.Location = new System.Drawing.Point(84, 145);
            this.btnShowPassword.Name = "btnShowPassword";
            this.btnShowPassword.Size = new System.Drawing.Size(129, 23);
            this.btnShowPassword.TabIndex = 2;
            this.btnShowPassword.Text = "Show Password";
            this.btnShowPassword.UseVisualStyleBackColor = true;
            this.btnShowPassword.Click += new System.EventHandler(this.btnShowPassword_Click);
            // 
            // txtRegisterPasswordRetype
            // 
            this.txtRegisterPasswordRetype.Location = new System.Drawing.Point(144, 119);
            this.txtRegisterPasswordRetype.Name = "txtRegisterPasswordRetype";
            this.txtRegisterPasswordRetype.Size = new System.Drawing.Size(150, 20);
            this.txtRegisterPasswordRetype.TabIndex = 1;
            this.txtRegisterPasswordRetype.TextChanged += new System.EventHandler(this.txtRegisterPasswordRetype_TextChanged);
            // 
            // lblRegisterPasswordRetype
            // 
            this.lblRegisterPasswordRetype.AutoSize = true;
            this.lblRegisterPasswordRetype.Location = new System.Drawing.Point(15, 122);
            this.lblRegisterPasswordRetype.Name = "lblRegisterPasswordRetype";
            this.lblRegisterPasswordRetype.Size = new System.Drawing.Size(97, 13);
            this.lblRegisterPasswordRetype.TabIndex = 0;
            this.lblRegisterPasswordRetype.Text = "Re-enter Password";
            // 
            // lblAccReq2
            // 
            this.lblAccReq2.AutoSize = true;
            this.lblAccReq2.Location = new System.Drawing.Point(180, 208);
            this.lblAccReq2.Name = "lblAccReq2";
            this.lblAccReq2.Size = new System.Drawing.Size(218, 13);
            this.lblAccReq2.TabIndex = 0;
            this.lblAccReq2.Text = "ASCII characters (A-Z, a-z, 0-9) and symbols.";
            this.lblAccReq2.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblAccReq1
            // 
            this.lblAccReq1.AutoSize = true;
            this.lblAccReq1.Location = new System.Drawing.Point(211, 195);
            this.lblAccReq1.Name = "lblAccReq1";
            this.lblAccReq1.Size = new System.Drawing.Size(187, 13);
            this.lblAccReq1.TabIndex = 0;
            this.lblAccReq1.Text = "Username and password must contain";
            this.lblAccReq1.Click += new System.EventHandler(this.lblAccReq1_Click);
            // 
            // lblPasswordRetypeNotMatched
            // 
            this.lblPasswordRetypeNotMatched.AutoSize = true;
            this.lblPasswordRetypeNotMatched.ForeColor = System.Drawing.Color.Red;
            this.lblPasswordRetypeNotMatched.Location = new System.Drawing.Point(321, 122);
            this.lblPasswordRetypeNotMatched.Name = "lblPasswordRetypeNotMatched";
            this.lblPasswordRetypeNotMatched.Size = new System.Drawing.Size(71, 13);
            this.lblPasswordRetypeNotMatched.TabIndex = 0;
            this.lblPasswordRetypeNotMatched.Text = "Not matched!";
            this.lblPasswordRetypeNotMatched.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblRegisterUsername
            // 
            this.lblRegisterUsername.AutoSize = true;
            this.lblRegisterUsername.Location = new System.Drawing.Point(15, 51);
            this.lblRegisterUsername.Name = "lblRegisterUsername";
            this.lblRegisterUsername.Size = new System.Drawing.Size(55, 13);
            this.lblRegisterUsername.TabIndex = 0;
            this.lblRegisterUsername.Text = "Username";
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(98, 253);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(75, 23);
            this.btnPrevious.TabIndex = 5;
            this.btnPrevious.Text = "Previous";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // winStckChkrRegister2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(430, 288);
            this.Controls.Add(this.lblPageOf);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.gboxAccountInformation);
            this.Name = "winStckChkrRegister2";
            this.Text = "Create an Account Profile";
            this.gboxAccountInformation.ResumeLayout(false);
            this.gboxAccountInformation.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPageOf;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.TextBox txtRegisterPassword;
        private System.Windows.Forms.Label lblRegisterPassword;
        private System.Windows.Forms.TextBox txtRegisterEmail;
        private System.Windows.Forms.Label lblLastname;
        private System.Windows.Forms.Label lblRegisterEmail;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.TextBox txtRegisterUsername;
        private System.Windows.Forms.GroupBox gboxAccountInformation;
        private System.Windows.Forms.Label lblRegisterUsername;
        private System.Windows.Forms.Button btnShowPassword;
        private System.Windows.Forms.TextBox txtRegisterPasswordRetype;
        private System.Windows.Forms.Label lblRegisterPasswordRetype;
        private System.Windows.Forms.Label lblAccReq1;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Label lblCorrectUsername;
        private System.Windows.Forms.Label lblCorrectEmail;
        private System.Windows.Forms.Label lblAccReq2;
        private System.Windows.Forms.Label lblCorrectPasswordRetype;
        private System.Windows.Forms.Label lblCorrectPassword;
        private System.Windows.Forms.Label lblPasswordRetypeNotMatched;
        private System.Windows.Forms.Button btnHidePassword;
    }
}