﻿using System;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace winStckChkr
{
    public partial class frmRegister : Form
    {
        public frmRegister()
        {
            InitializeComponent();

            // Prefill saved registration state (do this before wiring handlers to avoid spurious updates)
            txtFirstname.Text = RegistrationState.FirstName;
            txtLastname.Text = RegistrationState.LastName;
            txtPhoneNum.Text = RegistrationState.Phone;
            rtxtAddress.Text = RegistrationState.Address;
            txtCustomSpecify.Text = RegistrationState.Gender;

            // Enforce desired tab order and allow Tab to move out of the RichTextBox.
            txtFirstname.TabIndex = 0;
            txtLastname.TabIndex = 1;
            txtPhoneNum.TabIndex = 2;
            rtxtAddress.TabIndex = 3;
            rbtnMale.TabIndex = 4;
            rbtnFemale.TabIndex = 5;
            rbtnCustom.TabIndex = 6;
            txtCustomSpecify.TabIndex = 7;

            // Prevent RichTextBox from capturing the Tab key so Tab moves to the next control.
            rtxtAddress.AcceptsTab = false;

            // Initially hide the custom-specify controls unless Custom is selected.
            txtCustomSpecify.Enabled = false;
            txtCustomSpecify.TabStop = false;
            txtCustomSpecify.Visible = false;
            lblCustomSpecify.Visible = false;

            // Radio buttons: allow left/right keys to navigate between them.
            rbtnMale.KeyDown += RadioButtons_OnArrowKey;
            rbtnFemale.KeyDown += RadioButtons_OnArrowKey;
            rbtnCustom.KeyDown += RadioButtons_OnArrowKey;

            // Keep txtCustomSpecify visible/enabled only when rbtnCustom is checked.
            rbtnCustom.CheckedChanged += (s, e) =>
            {
                var custom = rbtnCustom.Checked;
                txtCustomSpecify.Enabled = custom;
                txtCustomSpecify.TabStop = custom;
                txtCustomSpecify.Visible = custom;
                lblCustomSpecify.Visible = custom;

                if (custom)
                {
                    txtCustomSpecify.Focus();
                }
                else
                {
                    txtCustomSpecify.Text = string.Empty;
                }

                UpdateNextButtonState();
            };

            // Hook change events so the Next button updates live.
            txtFirstname.TextChanged += (s, e) => UpdateNextButtonState();
            txtLastname.TextChanged += (s, e) => UpdateNextButtonState();
            txtPhoneNum.TextChanged += (s, e) => UpdateNextButtonState();
            rtxtAddress.TextChanged += (s, e) => UpdateNextButtonState();
            txtCustomSpecify.TextChanged += (s, e) => UpdateNextButtonState();
            rbtnMale.CheckedChanged += (s, e) => UpdateNextButtonState();
            rbtnFemale.CheckedChanged += (s, e) => UpdateNextButtonState();

            // Ensure phone textbox accepts only numbers (keypress) and sanitize pasted input.
            txtPhoneNum.KeyPress += TxtPhoneNum_KeyPress;
            // Note: Designer already wires txtPhoneNum.TextChanged to txtPhoneNum_TextChanged;
            // that method now sanitizes non-digit characters and calls UpdateNextButtonState.

            // Make sure the visible register button remains non-interactable here (per request).
            btnRegister.Enabled = false;

            // Next should start disabled until validation passes.
            btnNext.Enabled = false;

            // Restore radio selection from RegistrationState (after handlers wired so CheckedChanged runs)
            if (string.Equals(RegistrationState.Gender, "Male", StringComparison.OrdinalIgnoreCase))
                rbtnMale.Checked = true;
            else if (string.Equals(RegistrationState.Gender, "Female", StringComparison.OrdinalIgnoreCase))
                rbtnFemale.Checked = true;
            else if (!string.IsNullOrWhiteSpace(RegistrationState.Gender))
                rbtnCustom.Checked = true;

            // Ensure Next button reflects current prefilled state.
            UpdateNextButtonState();

            // Focus the first field when the form loads.
            this.Load += (s, e) => txtFirstname.Focus();
        }

        private void RadioButtons_OnArrowKey(object sender, KeyEventArgs e)
        {
            // Navigate radio buttons with Left/Right arrows.
            if (e.KeyCode != Keys.Left && e.KeyCode != Keys.Right)
                return;

            RadioButton current = sender as RadioButton;
            if (current == null)
                return;

            // Define order: Male -> Female -> Custom
            RadioButton[] order = { rbtnMale, rbtnFemale, rbtnCustom };
            int idx = Array.IndexOf(order, current);
            if (idx < 0)
                return;

            if (e.KeyCode == Keys.Left)
            {
                idx = (idx - 1 + order.Length) % order.Length;
            }
            else // Keys.Right
            {
                idx = (idx + 1) % order.Length;
            }

            order[idx].Checked = true;
            order[idx].Focus();

            e.Handled = true;
        }

        private void UpdateNextButtonState()
        {
            // Required fields
            bool requiredFilled =
                !string.IsNullOrWhiteSpace(txtFirstname.Text) &&
                !string.IsNullOrWhiteSpace(txtLastname.Text) &&
                !string.IsNullOrWhiteSpace(txtPhoneNum.Text) &&
                !string.IsNullOrWhiteSpace(rtxtAddress.Text);

            if (!requiredFilled)
            {
                btnNext.Enabled = false;
                return;
            }

            // If Male or Female selected -> enable Next
            if (rbtnMale.Checked || rbtnFemale.Checked)
            {
                btnNext.Enabled = true;
                return;
            }

            // If Custom selected -> enable Next only when custom text is provided
            if (rbtnCustom.Checked)
            {
                btnNext.Enabled = !string.IsNullOrWhiteSpace(txtCustomSpecify.Text);
                return;
            }

            // No gender selected
            btnNext.Enabled = false;
        }

        // Ensure closing via the titlebar X doesn't produce unexpected behavior for callers.
        // Setting DialogResult when form is closed makes the caller's ShowDialog return predictably.
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (this.DialogResult == DialogResult.None)
                this.DialogResult = DialogResult.Cancel;
        }

        private void txtFirstname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLastname_TextChanged(object sender, EventArgs e)
        {

        }

        // Enforce numeric-only input for phone number.
        // Prevent non-digit keys at KeyPress and sanitize the Text on change (handles paste).
        private void TxtPhoneNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow control keys (backspace, delete, arrows) and digits only.
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtPhoneNum_TextChanged(object sender, EventArgs e)
        {
            var tb = txtPhoneNum;
            if (tb == null)
                return;

            string original = tb.Text;
            string digits = new string(original.Where(char.IsDigit).ToArray());

            if (original != digits)
            {
                int selStart = tb.SelectionStart;
                tb.Text = digits;
                // restore a sensible caret position
                tb.SelectionStart = Math.Min(selStart, tb.Text.Length);
            }

            // Ensure Next button state is updated when phone changes.
            UpdateNextButtonState();
        }

        private void rtxtAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void rbtnMale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbtnFemale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbtnCustom_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtCustomSpecify_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            // Validate before saving / navigating
            bool requiredFilled =
                !string.IsNullOrWhiteSpace(txtFirstname.Text) &&
                !string.IsNullOrWhiteSpace(txtLastname.Text) &&
                !string.IsNullOrWhiteSpace(txtPhoneNum.Text) &&
                !string.IsNullOrWhiteSpace(rtxtAddress.Text);

            if (!requiredFilled)
            {
                MessageBox.Show("Please fill First name, Last name, Phone number and Address.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validate gender selection
            if (!(rbtnMale.Checked || rbtnFemale.Checked || (rbtnCustom.Checked && !string.IsNullOrWhiteSpace(txtCustomSpecify.Text))))
            {
                MessageBox.Show("Please select a gender. If you selected Custom, please specify.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Save page data
                SavePersonalInfo();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to save data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Open the next registration page. Hide this form so it appears closed to the user,
            // show the next page modally, then close this form when the next page finishes.
            // This keeps the application's message loop intact (the original caller remains blocked on ShowDialog).
            this.Hide();

            using (var next = new winStckChkrRegister2())
            {
                // If the next form exposes a SetPreviousPageValidity method (older assistant versions did),
                // call it so page 2 knows page1 is valid. Use reflection to avoid compile-time dependency.
                try
                {
                    var m = next.GetType().GetMethod("SetPreviousPageValidity");
                    if (m != null)
                        m.Invoke(next, new object[] { true });
                }
                catch
                {
                    // ignore if not present
                }

                // Center the next form and show it modally.
                next.StartPosition = FormStartPosition.CenterScreen;
                next.ShowDialog(this.Owner ?? this);
            }

            // After next finishes, close this form to return control to caller (typically login).
            this.Close();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            // Intentionally left empty — button is non-interactable per requirements.
        }

        private void SavePersonalInfo()
        {
            // Build values
            string firstName = txtFirstname.Text.Trim();
            string lastName = txtLastname.Text.Trim();
            string phone = txtPhoneNum.Text.Trim();
            string address = rtxtAddress.Text.Trim();
            string gender = rbtnMale.Checked ? "Male" : rbtnFemale.Checked ? "Female" : (rbtnCustom.Checked ? txtCustomSpecify.Text.Trim() : string.Empty);

            // Persist into shared in-memory state so other pages reuse the values.
            RegistrationState.FirstName = firstName;
            RegistrationState.LastName = lastName;
            RegistrationState.Phone = phone;
            RegistrationState.Address = address;
            RegistrationState.Gender = gender;
            RegistrationState.Page1Completed = true;

            // Path to the .mdb file on Desktop
            string dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "stckChkrNew.mdb");
            if (!File.Exists(dbPath))
                throw new FileNotFoundException("You sure you didn't put that thing here? Look at: " + dbPath);

            // Use Jet provider for .mdb. NOTE: Jet provider requires matching process bitness (32-bit).
            string connStr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + dbPath + ";Persist Security Info=False;";

            using (var conn = new OleDbConnection(connStr))
            {
                conn.Open();

                // Ensure table exists. If not, create it.
                if (!TableExists(conn, "PersonalInfo"))
                {
                    string createSql = "CREATE TABLE PersonalInfo " +
                                       "(ID COUNTER PRIMARY KEY, FirstName TEXT(255), LastName TEXT(255), Phone TEXT(50), Address MEMO, Gender TEXT(50))";
                    using (var cmdCreate = new OleDbCommand(createSql, conn))
                    {
                        cmdCreate.ExecuteNonQuery();
                    }
                }

                // Insert using parameters (OleDb uses positional parameters '?').
                string insertSql = "INSERT INTO PersonalInfo (FirstName, LastName, Phone, Address, Gender) VALUES (?,?,?,?,?)";
                using (var cmd = new OleDbCommand(insertSql, conn))
                {
                    cmd.Parameters.AddWithValue("FirstName", firstName);
                    cmd.Parameters.AddWithValue("LastName", lastName);
                    cmd.Parameters.AddWithValue("Phone", phone);
                    cmd.Parameters.AddWithValue("Address", address);
                    cmd.Parameters.AddWithValue("Gender", gender);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        private bool TableExists(OleDbConnection conn, string tableName)
        {
            // Query schema for tables
            var restrictions = new string[4];
            restrictions[2] = tableName;
            var schema = conn.GetSchema("Tables", restrictions);
            return schema != null && schema.Rows.Count > 0;
        }
    }
}
