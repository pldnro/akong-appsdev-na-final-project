﻿namespace winStckChkr
{
    partial class frmRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gboxPersonalInformation = new System.Windows.Forms.GroupBox();
            this.txtCustomSpecify = new System.Windows.Forms.TextBox();
            this.lblCustomSpecify = new System.Windows.Forms.Label();
            this.rbtnCustom = new System.Windows.Forms.RadioButton();
            this.rbtnFemale = new System.Windows.Forms.RadioButton();
            this.rbtnMale = new System.Windows.Forms.RadioButton();
            this.lblGender = new System.Windows.Forms.Label();
            this.rtxtAddress = new System.Windows.Forms.RichTextBox();
            this.txtPhoneNum = new System.Windows.Forms.TextBox();
            this.txtLastname = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblPhoneNum = new System.Windows.Forms.Label();
            this.txtFirstname = new System.Windows.Forms.TextBox();
            this.lblLastname = new System.Windows.Forms.Label();
            this.lblFirstname = new System.Windows.Forms.Label();
            this.btnRegister = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.lblPageOf = new System.Windows.Forms.Label();
            this.gboxPersonalInformation.SuspendLayout();
            this.SuspendLayout();
            // 
            // gboxPersonalInformation
            // 
            this.gboxPersonalInformation.Controls.Add(this.txtCustomSpecify);
            this.gboxPersonalInformation.Controls.Add(this.lblCustomSpecify);
            this.gboxPersonalInformation.Controls.Add(this.rbtnCustom);
            this.gboxPersonalInformation.Controls.Add(this.rbtnFemale);
            this.gboxPersonalInformation.Controls.Add(this.rbtnMale);
            this.gboxPersonalInformation.Controls.Add(this.lblGender);
            this.gboxPersonalInformation.Controls.Add(this.rtxtAddress);
            this.gboxPersonalInformation.Controls.Add(this.txtPhoneNum);
            this.gboxPersonalInformation.Controls.Add(this.txtLastname);
            this.gboxPersonalInformation.Controls.Add(this.lblAddress);
            this.gboxPersonalInformation.Controls.Add(this.lblPhoneNum);
            this.gboxPersonalInformation.Controls.Add(this.txtFirstname);
            this.gboxPersonalInformation.Controls.Add(this.lblLastname);
            this.gboxPersonalInformation.Controls.Add(this.lblFirstname);
            this.gboxPersonalInformation.Location = new System.Drawing.Point(25, 12);
            this.gboxPersonalInformation.Name = "gboxPersonalInformation";
            this.gboxPersonalInformation.Size = new System.Drawing.Size(311, 217);
            this.gboxPersonalInformation.TabIndex = 0;
            this.gboxPersonalInformation.TabStop = false;
            this.gboxPersonalInformation.Text = "Personal Information";
            // 
            // txtCustomSpecify
            // 
            this.txtCustomSpecify.Location = new System.Drawing.Point(122, 187);
            this.txtCustomSpecify.Name = "txtCustomSpecify";
            this.txtCustomSpecify.Size = new System.Drawing.Size(172, 20);
            this.txtCustomSpecify.TabIndex = 6;
            this.txtCustomSpecify.TextChanged += new System.EventHandler(this.txtCustomSpecify_TextChanged);
            // 
            // lblCustomSpecify
            // 
            this.lblCustomSpecify.AutoSize = true;
            this.lblCustomSpecify.Location = new System.Drawing.Point(15, 190);
            this.lblCustomSpecify.Name = "lblCustomSpecify";
            this.lblCustomSpecify.Size = new System.Drawing.Size(92, 13);
            this.lblCustomSpecify.TabIndex = 5;
            this.lblCustomSpecify.Text = "If custom, specify:";
            // 
            // rbtnCustom
            // 
            this.rbtnCustom.AutoSize = true;
            this.rbtnCustom.Location = new System.Drawing.Point(238, 164);
            this.rbtnCustom.Name = "rbtnCustom";
            this.rbtnCustom.Size = new System.Drawing.Size(60, 17);
            this.rbtnCustom.TabIndex = 4;
            this.rbtnCustom.TabStop = true;
            this.rbtnCustom.Text = "Custom";
            this.rbtnCustom.UseVisualStyleBackColor = true;
            this.rbtnCustom.CheckedChanged += new System.EventHandler(this.rbtnCustom_CheckedChanged);
            // 
            // rbtnFemale
            // 
            this.rbtnFemale.AutoSize = true;
            this.rbtnFemale.Location = new System.Drawing.Point(173, 164);
            this.rbtnFemale.Name = "rbtnFemale";
            this.rbtnFemale.Size = new System.Drawing.Size(59, 17);
            this.rbtnFemale.TabIndex = 3;
            this.rbtnFemale.TabStop = true;
            this.rbtnFemale.Text = "Female";
            this.rbtnFemale.UseVisualStyleBackColor = true;
            this.rbtnFemale.CheckedChanged += new System.EventHandler(this.rbtnFemale_CheckedChanged);
            // 
            // rbtnMale
            // 
            this.rbtnMale.AutoSize = true;
            this.rbtnMale.Location = new System.Drawing.Point(119, 164);
            this.rbtnMale.Name = "rbtnMale";
            this.rbtnMale.Size = new System.Drawing.Size(48, 17);
            this.rbtnMale.TabIndex = 3;
            this.rbtnMale.TabStop = true;
            this.rbtnMale.Text = "Male";
            this.rbtnMale.UseVisualStyleBackColor = true;
            this.rbtnMale.CheckedChanged += new System.EventHandler(this.rbtnMale_CheckedChanged);
            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.Location = new System.Drawing.Point(15, 164);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(42, 13);
            this.lblGender.TabIndex = 2;
            this.lblGender.Text = "Gender";
            // 
            // rtxtAddress
            // 
            this.rtxtAddress.Location = new System.Drawing.Point(144, 100);
            this.rtxtAddress.Name = "rtxtAddress";
            this.rtxtAddress.Size = new System.Drawing.Size(150, 58);
            this.rtxtAddress.TabIndex = 1;
            this.rtxtAddress.Text = "";
            this.rtxtAddress.TextChanged += new System.EventHandler(this.rtxtAddress_TextChanged);
            // 
            // txtPhoneNum
            // 
            this.txtPhoneNum.Location = new System.Drawing.Point(144, 74);
            this.txtPhoneNum.Name = "txtPhoneNum";
            this.txtPhoneNum.Size = new System.Drawing.Size(150, 20);
            this.txtPhoneNum.TabIndex = 1;
            this.txtPhoneNum.TextChanged += new System.EventHandler(this.txtPhoneNum_TextChanged);
            // 
            // txtLastname
            // 
            this.txtLastname.Location = new System.Drawing.Point(144, 48);
            this.txtLastname.Name = "txtLastname";
            this.txtLastname.Size = new System.Drawing.Size(150, 20);
            this.txtLastname.TabIndex = 1;
            this.txtLastname.TextChanged += new System.EventHandler(this.txtLastname_TextChanged);
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(15, 103);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(45, 13);
            this.lblAddress.TabIndex = 0;
            this.lblAddress.Text = "Address";
            // 
            // lblPhoneNum
            // 
            this.lblPhoneNum.AutoSize = true;
            this.lblPhoneNum.Location = new System.Drawing.Point(15, 77);
            this.lblPhoneNum.Name = "lblPhoneNum";
            this.lblPhoneNum.Size = new System.Drawing.Size(78, 13);
            this.lblPhoneNum.TabIndex = 0;
            this.lblPhoneNum.Text = "Phone Number";
            // 
            // txtFirstname
            // 
            this.txtFirstname.Location = new System.Drawing.Point(144, 24);
            this.txtFirstname.Name = "txtFirstname";
            this.txtFirstname.Size = new System.Drawing.Size(150, 20);
            this.txtFirstname.TabIndex = 1;
            this.txtFirstname.TextChanged += new System.EventHandler(this.txtFirstname_TextChanged);
            // 
            // lblLastname
            // 
            this.lblLastname.AutoSize = true;
            this.lblLastname.Location = new System.Drawing.Point(15, 51);
            this.lblLastname.Name = "lblLastname";
            this.lblLastname.Size = new System.Drawing.Size(58, 13);
            this.lblLastname.TabIndex = 0;
            this.lblLastname.Text = "Last Name";
            // 
            // lblFirstname
            // 
            this.lblFirstname.AutoSize = true;
            this.lblFirstname.Location = new System.Drawing.Point(15, 27);
            this.lblFirstname.Name = "lblFirstname";
            this.lblFirstname.Size = new System.Drawing.Size(57, 13);
            this.lblFirstname.TabIndex = 0;
            this.lblFirstname.Text = "First Name";
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(261, 253);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(75, 23);
            this.btnRegister.TabIndex = 1;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(180, 253);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 23);
            this.btnNext.TabIndex = 1;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // lblPageOf
            // 
            this.lblPageOf.AutoSize = true;
            this.lblPageOf.Location = new System.Drawing.Point(12, 266);
            this.lblPageOf.Name = "lblPageOf";
            this.lblPageOf.Size = new System.Drawing.Size(62, 13);
            this.lblPageOf.TabIndex = 2;
            this.lblPageOf.Text = "Page 1 of 5";
            // 
            // frmRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 288);
            this.Controls.Add(this.lblPageOf);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.gboxPersonalInformation);
            this.Name = "frmRegister";
            this.Text = "Register an Account";
            this.gboxPersonalInformation.ResumeLayout(false);
            this.gboxPersonalInformation.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gboxPersonalInformation;
        private System.Windows.Forms.Label lblLastname;
        private System.Windows.Forms.Label lblFirstname;
        private System.Windows.Forms.RichTextBox rtxtAddress;
        private System.Windows.Forms.TextBox txtPhoneNum;
        private System.Windows.Forms.TextBox txtLastname;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblPhoneNum;
        private System.Windows.Forms.TextBox txtFirstname;
        private System.Windows.Forms.RadioButton rbtnFemale;
        private System.Windows.Forms.RadioButton rbtnMale;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Label lblPageOf;
        private System.Windows.Forms.TextBox txtCustomSpecify;
        private System.Windows.Forms.Label lblCustomSpecify;
        private System.Windows.Forms.RadioButton rbtnCustom;
    }
}