﻿using System;
using System.Data.OleDb;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using System.IO; // <-- Ensure IO is available

namespace winStckChkr
{
    public partial class winStckChkrRegister2 : Form
    {
        public winStckChkrRegister2()
        {
            InitializeComponent();

            // Ensure initial visual/interaction state
            btnNext.Enabled = false;
            btnRegister.Enabled = false;

            lblCorrectEmail.Visible = false;
            lblCorrectUsername.Visible = false;
            lblCorrectPassword.Visible = false;
            lblCorrectPasswordRetype.Visible = false;
            lblPasswordRetypeNotMatched.Visible = false;

            // Force tab order to match requested sequence:
            // txtRegisterEmail, txtRegisterUsername, txtRegisterPassword, txtRegisterPasswordRetype,
            // btnShowPassword, btnPrevious, btnNext, btnRegister
            // (Set here so Designer file remains untouched)
            txtRegisterEmail.TabIndex = 0;
            txtRegisterUsername.TabIndex = 1;
            txtRegisterPassword.TabIndex = 2;
            txtRegisterPasswordRetype.TabIndex = 3;
            btnShowPassword.TabIndex = 4;
            btnHidePassword.TabIndex = 5;
            btnPrevious.TabIndex = 6;
            btnNext.TabIndex = 7;
            btnRegister.TabIndex = 8;

            // Ensure the interactive controls in the sequence are focusable via Tab
            btnShowPassword.TabStop = true;
            btnPrevious.TabStop = true;
            btnNext.TabStop = true;
            btnRegister.TabStop = true;

            // Wire live validation handlers (Designer already wires these too; safe to attach)
            txtRegisterEmail.TextChanged += (s, e) => UpdateValidationState();
            txtRegisterUsername.TextChanged += (s, e) => UpdateValidationState();
            txtRegisterPassword.TextChanged += (s, e) => UpdateValidationState();
            txtRegisterPasswordRetype.TextChanged += (s, e) => UpdateValidationState();

            // Wire show/hide and previous handlers
            btnPrevious.Click += BtnPrevious_Click;

            // Wire explicit show/hide buttons (Designer may expose separate buttons)
            btnShowPassword.Click += BtnShowPassword_Click;
            btnHidePassword.Click += BtnHidePassword_Click;

            // Keep focus sensible
            this.Load += (s, e) =>
            {
                // Prefill from shared registration state so returning from previous page keeps user input.
                txtRegisterEmail.Text = RegistrationState.Email;
                txtRegisterUsername.Text = RegistrationState.Username;
                txtRegisterPassword.Text = RegistrationState.Password;
                txtRegisterPasswordRetype.Text = RegistrationState.PasswordRetype;

                // When opening from page 1, fields may already be filled — validate immediately.
                UpdateValidationState();

                // Start focus on the email field (first in requested sequence)
                // Setting ActiveControl + Focus ensures keyboard focus and initial tab start.
                this.ActiveControl = txtRegisterEmail;
                txtRegisterEmail.Focus();

                // Ensure password fields mask by default and button text is correct
                // If state says the box is masked set text accordingly, else show as visible.
                txtRegisterPassword.UseSystemPasswordChar = true;
                txtRegisterPasswordRetype.UseSystemPasswordChar = true;
                btnShowPassword.Text = "Show Password";
                // Ensure correct enabled state: Show enabled, Hide disabled on load
                if (btnShowPassword != null) btnShowPassword.Enabled = true;
                if (btnHidePassword != null) btnHidePassword.Enabled = false;
            };
        }

        private void BtnShowPassword_Click(object sender, EventArgs e)
        {
            // Explicitly show password characters and set button enabled states.
            SetPasswordVisibility(true);
        }

        private void BtnHidePassword_Click(object sender, EventArgs e)
        {
            // Explicitly hide password characters and set button enabled states.
            SetPasswordVisibility(false);
        }

        private void SetPasswordVisibility(bool visible)
        {
            // visible == true => show characters
            if (txtRegisterPassword != null) txtRegisterPassword.UseSystemPasswordChar = !visible;
            if (txtRegisterPasswordRetype != null) txtRegisterPasswordRetype.UseSystemPasswordChar = !visible;

            // Maintain the separate Show/Hide buttons' enabled state.
            if (btnShowPassword != null) btnShowPassword.Enabled = !visible;
            if (btnHidePassword != null) btnHidePassword.Enabled = visible;

            // IMPORTANT: per request, do not change the text of btnShowPassword here.
        }

        private void BtnPrevious_Click(object sender, EventArgs e)
        {
            // Persist current inputs into shared in-memory state so page1 will be prefilled when it reappears.
            RegistrationState.Email = txtRegisterEmail.Text.Trim();
            RegistrationState.Username = txtRegisterUsername.Text.Trim();
            RegistrationState.Password = txtRegisterPassword.Text;
            RegistrationState.PasswordRetype = txtRegisterPasswordRetype.Text;

            // Hide this form and open the register (page 1) form so the user can edit previous data.
            // Use ShowDialog so control returns here only after the user closes the page1 form.
            // After returning, close this page to avoid duplicate windows.
            this.Hide();

            using (var prev = new frmRegister())
            {
                prev.StartPosition = FormStartPosition.CenterScreen;
                prev.ShowDialog(this);
            }

            // When previous form closes, close this form as well (user returned to edit page1).
            // This keeps behaviour consistent with the navigation model used elsewhere.
            this.Close();
        }

        private static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            // Basic email validation adequate for common domains (not exhaustive).
            var pattern = @"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$";
            return Regex.IsMatch(email.Trim(), pattern, RegexOptions.IgnoreCase);
        }

        private static bool IsValidUsername(string username)
        {
            if (string.IsNullOrWhiteSpace(username))
                return false;

            // Allowed characters: A-Z a-z 0-9 and underscore (_), period (.), at (@), hyphen (-)
            var pattern = @"^[A-Za-z0-9_.@-]+$";
            return Regex.IsMatch(username.Trim(), pattern);
        }

        private void UpdateValidationState()
        {
            // Email
            bool emailFilled = !string.IsNullOrWhiteSpace(txtRegisterEmail.Text);
            bool emailValid = emailFilled && IsValidEmail(txtRegisterEmail.Text);
            lblCorrectEmail.Visible = emailValid;

            // Username
            bool usernameFilled = !string.IsNullOrWhiteSpace(txtRegisterUsername.Text);
            bool usernameValid = usernameFilled && IsValidUsername(txtRegisterUsername.Text);
            lblCorrectUsername.Visible = usernameValid;

            // Passwords
            bool pwdFilled = !string.IsNullOrEmpty(txtRegisterPassword.Text);
            bool retypeFilled = !string.IsNullOrEmpty(txtRegisterPasswordRetype.Text);
            bool passwordsMatch = pwdFilled && retypeFilled && txtRegisterPassword.Text == txtRegisterPasswordRetype.Text;

            lblCorrectPassword.Visible = pwdFilled;
            lblCorrectPasswordRetype.Visible = passwordsMatch;

            // Not matched label: only show when password filled and retype filled and they don't match.
            lblPasswordRetypeNotMatched.Visible = pwdFilled && retypeFilled && !passwordsMatch;

            // Determine btnNext enabled:
            // All fields filled, email valid, username valid, and passwords match.
            bool allFilled =
                emailFilled &&
                usernameFilled &&
                pwdFilled &&
                retypeFilled;

            btnNext.Enabled = allFilled && emailValid && usernameValid && passwordsMatch;

            // btnRegister remains disabled on this page until the full registration flow completes.
            btnRegister.Enabled = false;
        }

        private void txtRegisterEmail_TextChanged(object sender, EventArgs e)
        {
            UpdateValidationState();
        }

        private void txtRegisterUsername_TextChanged(object sender, EventArgs e)
        {
            UpdateValidationState();
        }

        private void txtRegisterPassword_TextChanged(object sender, EventArgs e)
        {
            UpdateValidationState();
        }

        private void txtRegisterPasswordRetype_TextChanged(object sender, EventArgs e)
        {
            UpdateValidationState();
        }

        private void btnShowPassword_Click(object sender, EventArgs e)
        {
            // Designer-forwarded handler: flip visibility if designer wired this.
            // Use the shared helper which enforces Show/Hide button states.
            SetPasswordVisibility(!txtRegisterPassword.UseSystemPasswordChar);
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            // Only proceed if enabled (defensive)
            if (!btnNext.Enabled)
                return;

            try
            {
                // Final save account info to DB
                SaveAccountInfo(txtRegisterEmail.Text.Trim(), txtRegisterUsername.Text.Trim(), txtRegisterPassword.Text);

                MessageBox.Show("Account info saved. Registration complete.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Close and signal success to caller
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to save account: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            // Remains non-interactable per requirements.
        }

        private static string ComputeSha256HashHex(string input)
        {
            using (var sha = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(input);
                var hash = sha.ComputeHash(bytes);
                var sb = new StringBuilder(hash.Length * 2);
                foreach (var b in hash)
                    sb.AppendFormat("{0:x2}", b);
                return sb.ToString();
            }
        }

        private void SaveAccountInfo(string email, string username, string passwordPlain)
        {
            // Persist into shared state so navigating back will show the same values.
            RegistrationState.Email = email;
            RegistrationState.Username = username;
            RegistrationState.Password = passwordPlain;
            RegistrationState.PasswordRetype = txtRegisterPasswordRetype.Text;

            // Path to the .mdb file on Desktop
            string dbPath = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "stckChkrNew.mdb");
            if (!System.IO.File.Exists(dbPath))
                throw new FileNotFoundException("Database file not found at: " + dbPath);

            string connStr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + dbPath + ";Persist Security Info=False;Mode=Share Deny None;";
            string passwordHash = ComputeSha256HashHex(passwordPlain);

            const int maxAttempts = 5;
            const int delayMs = 250;
            int attempt = 0;

            while (true)
            {
                try
                {
                    using (var conn = new OleDbConnection(connStr))
                    {
                        conn.Open();

                        if (!TableExists(conn, "Accounts"))
                        {
                            string createSql = "CREATE TABLE Accounts (ID COUNTER PRIMARY KEY, Email TEXT(255), Username TEXT(100), PasswordHash TEXT(128))";
                            using (var cmdCreate = new OleDbCommand(createSql, conn))
                            {
                                cmdCreate.ExecuteNonQuery();
                            }
                        }

                        // Check duplicate username
                        using (var cmdCheck = new OleDbCommand("SELECT COUNT(*) FROM Accounts WHERE Username = ?", conn))
                        {
                            cmdCheck.Parameters.AddWithValue("Username", username);
                            var result = cmdCheck.ExecuteScalar();
                            if (result != null && int.TryParse(result.ToString(), out int existing) && existing > 0)
                                throw new InvalidOperationException("The chosen username is already in use. Please pick another.");
                        }

                        string insertSql = "INSERT INTO Accounts (Email, Username, PasswordHash) VALUES (?,?,?)";
                        using (var cmd = new OleDbCommand(insertSql, conn))
                        {
                            cmd.Parameters.AddWithValue("Email", email);
                            cmd.Parameters.AddWithValue("Username", username);
                            cmd.Parameters.AddWithValue("PasswordHash", passwordHash);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    break;
                }
                catch (OleDbException ex)
                {
                    attempt++;
                    var msg = ex.Message ?? string.Empty;
                    bool isLockError = msg.IndexOf("already in use", StringComparison.OrdinalIgnoreCase) >= 0
                                       || msg.IndexOf("could not use", StringComparison.OrdinalIgnoreCase) >= 0
                                       || msg.IndexOf("file is in use", StringComparison.OrdinalIgnoreCase) >= 0;

                    if (attempt >= maxAttempts || !isLockError)
                        throw;

                    Thread.Sleep(delayMs);
                }
            }
        }

        private bool TableExists(OleDbConnection conn, string tableName)
        {
            var restrictions = new string[4];
            restrictions[2] = tableName;
            var schema = conn.GetSchema("Tables", restrictions);
            return schema != null && schema.Rows.Count > 0;
        }

        // Centralized toggle that affects the password textboxes but does NOT change the Show button text.
        private void TogglePasswordVisibility()
        {
            // Preserve existing behavior for callers that rely on TogglePasswordVisibility,
            // but do NOT alter the btnShowPassword.Text.
            SetPasswordVisibility(!txtRegisterPassword.UseSystemPasswordChar);
        }

        // Designer handlers (kept forwarding to shared logic)
        private void label1_Click(object sender, EventArgs e) { }
        private void lblAccReq1_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
    }

    // Simple in-memory state to persist registration inputs while navigating forms.
    internal static class RegistrationState
    {
        // Page 1 (personal)
        public static string FirstName { get; set; } = string.Empty;
        public static string LastName { get; set; } = string.Empty;
        public static string Phone { get; set; } = string.Empty;
        public static string Address { get; set; } = string.Empty;
        public static string Gender { get; set; } = string.Empty; // "Male", "Female", or custom text
        public static bool Page1Completed { get; set; } = false;

        // Page 2 (account)
        public static string Email { get; set; } = string.Empty;
        public static string Username { get; set; } = string.Empty;
        public static string Password { get; set; } = string.Empty;
        public static string PasswordRetype { get; set; } = string.Empty;
    }
}
